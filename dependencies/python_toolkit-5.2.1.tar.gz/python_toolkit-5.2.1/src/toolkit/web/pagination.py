import math
from typing import Union

from toolkit.errors import ErrorBase


class ErrorPagination(ErrorBase):
    code: int = 10200


class _PaginationQueryString:
    def __init__(self, page: int, page_size: int):
        self.page = page
        self.page_size = page_size

    def __str__(self):
        return f"?page={self.page}&pageSize={self.page_size}"


class PageBasePagination:
    """
    Handles pagination. The instance should be created by specifying where the
    user wants to go in terms of pagination.
    """

    max_page_size: int = 100

    def __init__(self, total_results: int, required_page: int, page_size: Union[int, None] = None):
        assert self.max_page_size > 0, "The page size can' be less than one"  # nosec

        self._required_page: int = required_page
        self._total_results = total_results if total_results > 0 else 0

        self._internal_page_size = self.max_page_size
        if page_size and page_size < self._internal_page_size:
            self._internal_page_size = page_size

    @property
    def total_pages(self):
        """
        The number of pages the full result set has.
        """
        return math.ceil(self._total_results / self._internal_page_size)

    @property
    def page(self) -> int:
        """
        Returns the current page. If there are no results, zero will be
         returned, it is assuming there are no results to show.
        """

        if not self._required_page:
            return 1

        if not self.total_pages:
            return 0

        if self._required_page > self.total_pages:
            raise ErrorPagination()

        if self._required_page < 1:
            return 1

        return self._required_page

    @property
    def page_size(self) -> int:
        """
        The page size for the response.
        """
        return self.limit

    @property
    def limit(self) -> int:
        """
        An alias for the page size.
        """
        return self._internal_page_size

    @property
    def offset(self) -> int:
        if not self._total_results:
            return 0
        return (self.page - 1) * self.limit

    @property
    def is_last_page(self) -> bool:
        return self.page + 1 > self.total_pages

    @property
    def is_first_page(self) -> bool:
        return self.page - 1 < 1

    @property
    def next_querystring(self):
        if self.is_last_page:
            return

        return str(_PaginationQueryString(self.page + 1, self.page_size))

    @property
    def previous_querystring(self):
        if self.is_first_page:
            return

        return str(_PaginationQueryString(self.page - 1, self.page_size))

    @property
    def data(self):
        return {
            "next": self.next_querystring,
            "previous": self.previous_querystring,
            "currentPage": self.page if self.page else None,
            "totalPages": self.total_pages if self.total_pages else None,
            "totalResults": self._total_results if self._total_results else None,
            "maxPageSize": self.max_page_size,
        }

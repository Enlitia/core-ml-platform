import abc
import dataclasses
from collections import defaultdict
from typing import Dict, Set, Type

from toolkit.errors import ErrorBase


class ErrorNotAnEvent(ErrorBase):
    code = 10000


@dataclasses.dataclass
class DomainEvent:
    """
    An event is something that has happened in the past.
    """

    pass


class EventProcessor(abc.ABC):
    """
    Receives an event and handles it.
    """

    @abc.abstractmethod
    def handle(self, domain_event: DomainEvent):
        """
        Commands the event processor to handle the event.
        """
        pass


_event_processors: Dict[str, Set[EventProcessor]] = defaultdict(set)


class DomainEventsMediator:
    """
    Connects emitted events to the handlers that want to listen a given event.
    """

    def emit(self, event: DomainEvent):
        """
        Emits an event in the event bus.
        """
        if not isinstance(event, DomainEvent):
            raise ErrorNotAnEvent()

        if event.__class__.__name__ not in _event_processors:
            return

        for processor in _event_processors[event.__class__.__name__]:
            processor.handle(event)

    @staticmethod
    def register_processor(domain_event: Type[DomainEvent], processor: EventProcessor):
        """
        Registers an event processor for a given domain event.
        """
        _event_processors[domain_event.__name__].add(processor)

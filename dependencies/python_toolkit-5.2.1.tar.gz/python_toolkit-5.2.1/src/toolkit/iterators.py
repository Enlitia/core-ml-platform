from itertools import islice
from typing import Any, Iterable, List, Type, TypeVar

T = TypeVar("T")


def batched(iterable: Iterable[T], n: int) -> Iterable[Iterable[T]]:
    """Equivalent to itertools.batched
    https://docs.python.org/3.12/library/itertools.html?highlight=batched#itertools.batched


    Args:
        iterable (Iterable[T]): iterable to create batches from
        n (int): batch size

    Raises:
        ValueError: If n < 1

    Returns:
        Iterable[Iterable[T]]: Iterable of batches

    Yields:
        Iterator[Iterable[Iterable[T]]]: Iterator of iterable of batches

    Example:
        batched('ABCDEFG', 3) --> ABC DEF G
    """
    if n < 1:
        raise ValueError("n must be at least one")
    it = iter(iterable)
    while batch := tuple(islice(it, n)):
        yield batch


def iter_to_csv(_list: Iterable[Any], sep: str = ",") -> str:
    """Makes a csv string from an iterable

    Args:
        _list (Iterable[Any]): Iterable to make csv
        sep (str, optional): Separator. Defaults to ",".

    Returns:
        str: CSV representation of `_list`
    """
    return sep.join([str(a) for a in _list])


K = TypeVar("K", str, int, float)


def csv_to_iter(csv: str, cast: Type[K] = str, sep: str = ",") -> Iterable[K]:  # type: ignore
    """Iterates through elements from a csv string

    Args:
        csv (str): CSV string
        cast (Type[K], optional): Type cast for each csv element. Defaults to str.
        sep (str, optional): CSV separator. Defaults to ",".

    Returns:
        Iterable[K]: Iterable of the csv elements

    Yields:
        Iterator[Iterable[K]]: Iterator of the csv elements
    """
    for elem in csv.split(sep):
        yield cast(elem)


def csv_to_list(csv: str, cast: Type[K] = str, sep: str = ",") -> List[K]:  # type: ignore
    """Transforms a csv into a list of elements

    Args:
        csv (str): CSV string
        cast (Type[K], optional): Type cast for each csv element. Defaults to str.
        sep (str, optional): CSV separator. Defaults to ",".

    Returns:
        List[K]: List of the csv elements
    """
    return list(csv_to_iter(csv, cast, sep))

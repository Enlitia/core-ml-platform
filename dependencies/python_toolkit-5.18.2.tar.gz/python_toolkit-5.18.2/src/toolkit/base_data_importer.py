import abc
from typing import Any

from toolkit.base_data_pipeline import BaseDataPipeline
from toolkit.logging import DataImportLabels


class BaseDataImporter(BaseDataPipeline, abc.ABC):
    """
    Abstract base class for all data importers.

    Pipeline: fetch (source) → process → store (database).
    Provides common functionality and structured logging for data import processes.
    """

    @abc.abstractmethod
    def _fetch(self) -> list[Any]:
        """
        Fetch data from the data source.

        Returns:
            The fetched data
        """
        pass

    @abc.abstractmethod
    def _process(self, raw_data: list[Any]) -> list[Any]:
        """
        Process the raw data into a format suitable for storage.

        Args:
            raw_data: The raw data from the data source

        Returns:
            The processed data
        """
        pass

    @abc.abstractmethod
    def _store(self, processed_data: list[Any]) -> None:
        """
        Store the processed data.

        Args:
            processed_data: The processed data to store
        """
        pass

    def execute(self) -> None:  # type: ignore[override]
        """Execute the data import pipeline: fetch → process → store."""
        record_count = 0

        self._logger.info("Execution started", action=DataImportLabels.EXECUTE.started)

        try:
            raw_data = self._run_step(DataImportLabels.FETCH, self._fetch)
            if not raw_data:
                return

            processed_data = self._run_step(DataImportLabels.PROCESS, self._process, raw_data)
            if not processed_data:
                return

            self._run_step(DataImportLabels.STORE, self._store, processed_data)
            record_count = len(processed_data)

        except Exception as e:
            self._logger.error(
                "Execution failed",
                action=DataImportLabels.EXECUTE.failed,
                error_type=type(e).__name__,
                error_message=str(e),
                exc_info=True,
            )
            raise

        else:
            self._logger.info(
                "Execution completed",
                action=DataImportLabels.EXECUTE.completed,
                record_count=record_count,
            )

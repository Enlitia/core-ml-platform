from dataclasses import dataclass
from enum import IntEnum, StrEnum
from typing import Any, Union

import httpx

from toolkit.http_client import BaseHTTPClient


class EDPSUEndpoints(StrEnum):
    """Endpoints for EDP SU API."""

    SOLAR_FORECAST = "/data-analytics/forecasting/solar-forecast"


class EDPSUMarket(IntEnum):
    """EDP SU market codes.
    Market session codes for solar forecast submissions.
    """

    MD = 0  # Day-ahead market (Mercado Diário)
    MI1 = 1  # Intraday market session 1
    MI2 = 2  # Intraday market session 2
    MI3 = 3  # Intraday market session 3

    @classmethod
    def to_list(cls) -> list[int]:
        """Return a list of all market code values."""
        return [market.value for market in cls]

    @classmethod
    def all_markets(cls) -> list["EDPSUMarket"]:
        """Return a list of all EDPSU Market enum members for iteration."""
        return list(cls)


@dataclass
class ForecastRequest:
    """Request body for solar forecast API call.

    Args:
        cpe: CPE identifier (e.g. "PT0002990133553296TA")
        ida: Market session code (0=MD, 1=MI1, 2=MI2, 3=MI3). Can be EDPSUMarket enum or int.
        days: List of days with their period data

    """

    cpe: str
    ida: Union[EDPSUMarket, int]
    days: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API request."""
        # Convert EDPSUMarket enum to int if necessary
        ida_value = self.ida.value if isinstance(self.ida, EDPSUMarket) else int(self.ida)

        # Validate that ida_value is one of the supported market codes
        if ida_value not in EDPSUMarket.to_list():
            raise ValueError(
                f"Invalid market code for 'ida': {ida_value}. Supported values are: {EDPSUMarket.to_list()}."
            )
        return {
            "cpe": self.cpe,
            "ida": ida_value,
            "days": self.days,
        }


class EDPSUError(Exception):
    """Base exception for EDPSU client errors."""

    pass


class EDPSUAPIError(EDPSUError):
    """Exception raised when EDP SU API returns an error response."""

    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        self.message = message or f"EDP SU API request failed with status {status_code}"
        super().__init__(self.message)


class EDPSURequestError(EDPSUError):
    """Exception raised when there's a problem making the request to EDP SU."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class EDPSUAPIClient(BaseHTTPClient):
    """
    EDP SU API client for fetching solar forecast data.
    Inherits from BaseHTTPClient and uses client ID/secret authentication via headers.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        **kwargs,
    ):
        """
        Initialize the EDP SU API client.

        Args:
            host: Full base URL for the EDP SU API
                  (e.g. "https://m01.api.sueletricidade.pt/sue/private-pre/v1"
                   or "https://api.sueletricidade.pt/sue/private/v1")
            client_id: Client ID for authentication
            client_secret: Client secret for authentication
            timeout: Request timeout in seconds (default: 300)
            logger: Logger instance
            **kwargs: Additional arguments passed to BaseHTTPClient
        """
        self._client_id = client_id
        self._client_secret = client_secret
        super().__init__(**kwargs)

    @property
    def _default_headers(self) -> dict[str, str]:
        """Default headers including EDP SU authentication."""
        return {
            "Content-Type": "application/json",
            "x-sue-client-id": self._client_id,
            "x-sue-client-secret": self._client_secret,
        }

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to EDP SU-specific exceptions."""
        return EDPSUAPIError(
            exc.response.status_code,
            f"HTTP {exc.response.status_code} error for {exc.request.method} {exc.request.url}: {exc.response.text}",
        )

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to EDP SU-specific exceptions."""
        return EDPSURequestError(str(exc), exc)

    def post_forecast(
        self,
        body: ForecastRequest,
    ) -> dict[str, Any]:
        """POST solar forecast data to EDP SU API.

        Args:
            body: Body with cpe, ida, and days with period data.

        Returns:
            API response JSON.

        Raises:
            EDPSUAPIError: If the API returns an error.
            EDPSURequestError: If the request fails.
        """
        return self.post(
            f"/{EDPSUEndpoints.SOLAR_FORECAST}",
            json=body.to_dict(),
        )

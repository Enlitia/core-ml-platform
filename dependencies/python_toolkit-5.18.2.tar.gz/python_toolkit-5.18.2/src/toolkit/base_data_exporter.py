import abc
from typing import Any

from toolkit.base_data_pipeline import BaseDataPipeline
from toolkit.logging import DataExportLabels


class BaseDataExporter(BaseDataPipeline, abc.ABC):
    """
    Abstract base class for all data exporters.

    Pipeline: load (database) → process → export (API / destination).
    Provides common functionality and structured logging for data export processes.
    """

    @abc.abstractmethod
    def _load(self) -> list[Any]:
        """
        Load data from the local storage (e.g. database).

        Returns:
            The loaded data
        """
        pass

    @abc.abstractmethod
    def _process(self, raw_data: list[Any]) -> list[Any]:
        """
        Process the raw data into a format suitable for the destination.

        Args:
            raw_data: The raw data from storage

        Returns:
            The processed data ready for export
        """
        pass

    @abc.abstractmethod
    def _export(self, processed_data: list[Any]) -> None:
        """
        Export the processed data to the destination (e.g. external API).

        Args:
            processed_data: The processed data to export
        """
        pass

    def execute(self) -> None:  # type: ignore[override]
        """Execute the data export pipeline: load → process → export."""
        record_count = 0

        self._logger.info("Execution started", action=DataExportLabels.EXECUTE.started)

        try:
            raw_data = self._run_step(DataExportLabels.LOAD, self._load)
            if not raw_data:
                return

            processed_data = self._run_step(DataExportLabels.PROCESS, self._process, raw_data)
            if not processed_data:
                return

            self._run_step(DataExportLabels.EXPORT, self._export, processed_data)
            record_count = len(processed_data)

        except Exception as e:
            self._logger.error(
                "Execution failed",
                action=DataExportLabels.EXECUTE.failed,
                error_type=type(e).__name__,
                error_message=str(e),
                exc_info=True,
            )
            raise

        else:
            self._logger.info(
                "Execution completed",
                action=DataExportLabels.EXECUTE.completed,
                record_count=record_count,
            )

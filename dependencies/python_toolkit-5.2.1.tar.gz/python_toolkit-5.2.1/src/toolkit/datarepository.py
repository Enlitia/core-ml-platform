from typing import Callable, Union


class BaseRepository:
    def __init__(self, session):
        self.session = session

    @staticmethod
    def row_to_model(model_type: Callable, result):
        if isinstance(result, list):
            return [model_type(**row) for row in result]

        return model_type(**result)

    @staticmethod
    def model_to_dict(model: Union[list, object]):
        def convert(m):
            return m.to_dict() if hasattr(m, "to_dict") and callable(m.to_dict) else m.__dict__

        if isinstance(model, list):
            return [convert(m) for m in model]

        return convert(model)

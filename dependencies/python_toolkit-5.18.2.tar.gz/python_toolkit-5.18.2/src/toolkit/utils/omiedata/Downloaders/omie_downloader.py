import datetime as dt


class OMIEDownloader:
    def get_complete_url(self) -> str:
        raise NotImplementedError

    def download_data(self, date_ini: dt.date, date_end: dt.date, output_folder: str, verbose=False) -> int:
        raise NotImplementedError

    def url_responses(self, date_ini: dt.date, date_end: dt.date, verbose=False):
        raise NotImplementedError

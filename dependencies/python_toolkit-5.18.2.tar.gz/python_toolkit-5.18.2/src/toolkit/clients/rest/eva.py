"""EVA API client for authentication and power-meteo forecast data."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import httpx

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import HTTPClientLabels, Logger, get_logger


class EvaError(Exception):
    """Base exception for EVA API client errors."""

    pass


class EvaAPIError(EvaError):
    """Exception raised when EVA API returns an error response."""

    def __init__(self, error_dict: dict[str, Any]):
        self.error_dict = error_dict
        self.status_code = error_dict.get("statusCode", error_dict.get("error_code", 0))
        super().__init__(str(error_dict))


class EvaRequestError(EvaError):
    """Exception raised when there's a problem making the request to EVA API."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class EvaValidationError(EvaError):
    """Exception for input validation errors."""

    pass


# Expected by EVA API query param ``availableDate``.
_AVAILABLE_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
_MARKET_PRICE_DATE_FORMAT = "%Y-%m-%d"


@dataclass
class PowerMeteoForecastParams:
    """Parameters for GET /power-meteo/forecast.

    Query parameters are ``availableDate`` plus exactly one of ``cluster`` or ``idForecast``.

    Args:
        available_date: Instant encoded for the API as ``YYYY-MM-DD HH:MM:SS`` (local/naive or aware).
        cluster: Cluster id (positive integer). Mutually exclusive with ``id_forecast``.
        id_forecast: Forecast id (positive integer), sent as ``idForecast``. Mutually exclusive with ``cluster``.

    Raises:
        EvaValidationError: If ``available_date`` is invalid, or neither or both of ``cluster`` and
            ``id_forecast`` are set, or the set field is not a positive integer.
    """

    available_date: datetime
    cluster: int | None = None
    id_forecast: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.available_date, datetime):
            raise EvaValidationError("available_date must be a datetime")

        has_cluster = self.cluster is not None
        has_id = self.id_forecast is not None
        if has_cluster == has_id:
            raise EvaValidationError("pass exactly one of cluster or id_forecast")

        if has_cluster:
            if not isinstance(self.cluster, int) or self.cluster <= 0:
                raise EvaValidationError("cluster must be a positive integer")
        else:
            if not isinstance(self.id_forecast, int) or self.id_forecast <= 0:
                raise EvaValidationError("id_forecast must be a positive integer")

        self._available_date_str = self.available_date.strftime(_AVAILABLE_DATE_FORMAT)

    @property
    def forecast_scope_params(self) -> dict[str, int]:
        """Either ``cluster`` or ``idForecast`` for the query string (not ``availableDate``)."""
        if self.cluster is not None:
            return {"cluster": self.cluster}
        elif self.id_forecast is not None:
            return {"idForecast": self.id_forecast}
        else:
            raise EvaValidationError("either cluster or id_forecast must be set")

    @property
    def available_date_str(self) -> str:
        """API-formatted availableDate query value."""
        return self._available_date_str


@dataclass
class MarketPriceForecastParams:
    """Parameters for GET /market-price/forecast.

    Query parameters always include ``startDate`` and ``timezone``.
    ``endDate`` and ``horizon`` are optional but must be provided together.

    Args:
        start_date: Start datetime encoded as ``YYYY-MM-DD``.
        end_date: Optional end datetime encoded as ``YYYY-MM-DD``.
        horizon: Optional positive integer horizon, required when ``end_date`` is set.
        timezone: Timezone label accepted by EVA API.

    Raises:
        EvaValidationError: If provided values are invalid.
    """

    start_date: datetime
    end_date: datetime | None = None
    horizon: int | None = None
    timezone: str = "UTC"

    def __post_init__(self) -> None:
        if not isinstance(self.start_date, datetime):
            raise EvaValidationError("start_date must be a datetime")
        if (self.end_date is None) != (self.horizon is None):
            raise EvaValidationError("end_date and horizon must be provided together")
        if self.end_date is not None and not isinstance(self.end_date, datetime):
            raise EvaValidationError("end_date must be a datetime")
        if self.horizon is not None and (not isinstance(self.horizon, int) or self.horizon <= 0):
            raise EvaValidationError("horizon must be a positive integer")
        if not isinstance(self.timezone, str) or not self.timezone.strip():
            raise EvaValidationError("timezone must be a non-empty string")

        self._start_date_str = self.start_date.strftime(_MARKET_PRICE_DATE_FORMAT)
        self._end_date_str = self.end_date.strftime(_MARKET_PRICE_DATE_FORMAT) if self.end_date is not None else None
        self._timezone = self.timezone.strip()

    @property
    def query_params(self) -> dict[str, Any]:
        """API query params for market-price forecast endpoint."""
        params: dict[str, Any] = {"startDate": self._start_date_str, "timezone": self._timezone}
        if self._end_date_str is not None and self.horizon is not None:
            params["endDate"] = self._end_date_str
            params["horizon"] = self.horizon
        return params


class EvaClient(BearerTokenHTTPClient):
    """HTTP client for EVA API (login and power-meteo forecast).

    The caller must pass the full API base URL for the target environment (e.g. production
    or staging); this client does not assume a default host.
    """

    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        logger: Logger | None = None,
        **kwargs: Any,
    ) -> None:
        if not isinstance(base_url, str) or not base_url.strip():
            raise EvaValidationError("base_url must be a non-empty string")

        self._logger = logger or get_logger(__name__)
        super().__init__(base_url.strip(), token, logger=self._logger, **kwargs)

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        try:
            response_body = exc.response.text
            error_dict = json.loads(response_body) if response_body else {}
        except (json.JSONDecodeError, Exception):
            error_dict = {
                "statusCode": exc.response.status_code,
                "message": exc.response.text if hasattr(exc.response, "text") else f"HTTP {exc.response.status_code}",
            }

        if "statusCode" not in error_dict and "error_code" not in error_dict:
            error_dict["statusCode"] = exc.response.status_code

        return EvaAPIError(error_dict)

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        return EvaRequestError(str(exc), exc)

    def _clear_authorization_header(self) -> None:
        if self._client is not None and "Authorization" in self._client.headers:
            del self._client.headers["Authorization"]

    def login(self, email: str, password: str) -> str:
        """Authenticate with email and password; store Bearer token for subsequent calls.

        POST /auth/login uses form-urlencoded body and must not send Authorization.

        Args:
            email: User email.
            password: User password.

        Returns:
            JWT token string from response field ``data``.

        Raises:
            EvaAPIError: If the API returns an error or an unexpected response shape.
            EvaRequestError: If the request fails.
        """
        if not email or not isinstance(email, str):
            raise EvaValidationError("email must be a non-empty string")
        if not isinstance(password, str):
            raise EvaValidationError("password must be a string")

        self._logger.info(
            "auth started",
            action=HTTPClientLabels.AUTH.started,
            step=HTTPClientLabels.AUTH,
        )

        previous_token = self.token
        self._clear_authorization_header()
        login_headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        try:
            response_body = self.post(
                "/auth/login",
                data={"email": email, "password": password},
                headers=login_headers,
            )

            token = response_body.get("data")
            if not isinstance(token, str) or not token:
                raise EvaAPIError(
                    {
                        "statusCode": 0,
                        "message": "Login response missing string token in 'data'",
                        "body": response_body,
                    }
                )
        except Exception:
            self.token = previous_token
            if previous_token:
                self._set_auth_header()
            else:
                self._clear_authorization_header()
            raise
        self.token = token
        self._set_auth_header()

        self._logger.debug(
            "auth completed",
            action=HTTPClientLabels.AUTH.completed,
            step=HTTPClientLabels.AUTH,
        )
        return token

    def get_power_meteo_forecast(self, params: PowerMeteoForecastParams, **kwargs: Any) -> dict[str, Any]:
        """Retrieve power-meteo forecast for ``availableDate`` and either ``cluster`` or ``idForecast``.

        Args:
            params: Validated query parameters.
            **kwargs: Additional query parameters passed to the API.

        Returns:
            Parsed JSON response body.

        Raises:
            EvaAPIError: If the API returns an error response.
            EvaRequestError: If there's a problem making the request.
            EvaValidationError: If params are invalid (raised by PowerMeteoForecastParams).
        """
        scope = params.forecast_scope_params

        query_params: dict[str, Any] = {**scope, "availableDate": params.available_date_str, **kwargs}

        response_data = self.get("/power-meteo/forecast", params=query_params)

        data = response_data.get("data")
        n = len(data) if isinstance(data, list) else 0
        self._logger.debug("power-meteo forecast retrieved", record_count=n)

        return response_data

    def get_market_price_forecast(
        self,
        params: MarketPriceForecastParams,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Retrieve market-price forecast data from EVA.

        Args:
            params: Validated market-price forecast query parameters.
            **kwargs: Additional query parameters passed to the API.

        Returns:
            Parsed JSON response body from the API (same shape as ``self.get`` returns).

        Raises:
            EvaValidationError: If params are invalid (raised by MarketPriceForecastParams).
            EvaAPIError: If the API returns an error response.
            EvaRequestError: If there's a problem making the request.
        """
        query_params = {**params.query_params, **kwargs}

        response_data = self.get("/market-price/forecast", params=query_params)

        data = response_data.get("data")
        n = len(data) if isinstance(data, list) else 0
        self._logger.debug("market-price forecast retrieved", record_count=n)

        return response_data

from __future__ import annotations

from datetime import date, datetime, timedelta
from math import ceil
from typing import Union

from dateutil.relativedelta import relativedelta

from toolkit.errors import ErrorDomain


class DateTime(datetime):
    @property
    def one_day_before(self):
        return self - timedelta(days=1)

    @property
    def one_day_after(self):
        return self + timedelta(days=1)

    def to_iso_8601_date(self) -> ISO8601Date:
        return ISO8601Date(self)

    def zeroed(self, hour=0, minute=0, second=0, microsecond=0) -> DateTime:
        """
        Sets the time attributes to zero. Optionally, it allows to choose a value for
        each of hour, minute, second, microsecond.
        """
        return self.replace(hour=hour, minute=minute, second=second, microsecond=microsecond)

    def to_iso_8601_date_time(self) -> ISO8601DateTime:
        return ISO8601DateTime(self)

    @staticmethod
    def ceil(date_to_ceil: Union[DateTime, datetime]) -> DateTime:
        """
        Ceils the minutes of the date to the nearest upper interval of 1h/6.
        """

        minutes = date_to_ceil.minute
        ceiled_minutes = ceil(minutes / 10) * 10
        if ceiled_minutes >= 60:
            ceiled_minutes = 0
        hour = date_to_ceil.hour
        if minutes > 50:
            hour = date_to_ceil.hour + 1
        if hour > 23:
            hour = 00
        return date_to_ceil.replace(hour=hour, minute=ceiled_minutes, second=00, microsecond=00)  # type: ignore


class ISO8601Date:
    def __init__(self, dt: Union[datetime, date, DateTime]) -> None:
        self._datetime = dt

    def __str__(self) -> str:
        iso_8601_format = "%Y-%m-%d"
        return self._datetime.strftime(iso_8601_format)


class ISO8601DateTime:
    def __init__(self, dt: Union[datetime, date, DateTime]) -> None:
        self._datetime = dt

    def __str__(self) -> str:
        iso_8601_format = "%Y-%m-%d %H:%M:%S"
        return self._datetime.strftime(iso_8601_format)


class ErrorInvalidDateInterval(ErrorDomain):
    message: str = "Error, end date must be greater than start date"
    code: int = 20001


class DateInterval:
    """
    Represents an interval between two dates.
    """

    def __init__(self, start_date: date, end_date: date):
        if start_date >= end_date:
            raise ErrorInvalidDateInterval()

        self._start_date = start_date
        self._end_date = end_date

    def to_hours(self) -> float:
        """
        Returns the date interval in hours.

        Raise an exception is the resulting value is not an integer.
        """
        difference = self._end_date - self._start_date
        hours = difference.total_seconds() / 3600

        return hours

    def to_minutes(self) -> float:
        """
        Returns the date interval in minutes.

        Raise an exception is the resulting value is not an integer.
        """
        difference = self._end_date - self._start_date
        minutes = difference.total_seconds() / 60

        return minutes

    def to_seconds(self) -> float:
        difference = self._end_date - self._start_date
        return difference.total_seconds()

    @property
    def years(self) -> int:
        """
        Returns the number of years contained in a date interval.
        """
        return relativedelta(self._end_date, self._start_date).years

    @property
    def months(self) -> int:
        """
        Returns the number of months contained in a date interval.
        """
        return relativedelta(self._end_date, self._start_date).months

    @property
    def hours(self) -> int:
        """
        Returns the number of hours contained in a date interval.
        """
        return relativedelta(self._end_date, self._start_date).hours

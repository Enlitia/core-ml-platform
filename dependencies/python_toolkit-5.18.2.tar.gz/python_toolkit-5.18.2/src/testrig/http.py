import pytest

from toolkit.web.http import status


def assert_base_response_is_matched(response):
    """
    Checks it the response matches the expected base response for a web service.
    """
    __tracebackhide__ = True
    assert response.status_code == status.HTTP_200_OK, (
        f"expected 'HTTP 200 OK', got '{response.status_code}' instead: {response.content}"
    )

    try:
        _ = response.json()["data"]
        _ = response.json()["errors"]
    except KeyError as e:
        pytest.fail(f"response does not contain required fields: '{e!s}'")

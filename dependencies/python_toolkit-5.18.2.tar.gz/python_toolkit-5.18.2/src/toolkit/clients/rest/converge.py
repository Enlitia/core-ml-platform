"""Converge API client for meter data.

Provides a client for fetching electrical meter readings from the Converge API.
Uses username/password authentication and supports meter data retrieval by
meter ID, signal IDs, and time range. Follows the same pattern as other REST
clients (e.g. AxpoClient) using BearerTokenHTTPClient and httpx.
"""

from datetime import datetime
from typing import Any

import httpx

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import HTTPClientLabels, Logger, get_logger

logger = get_logger(__name__)

LOGIN_PATH = "/login/user-login"
METER_DATA_PATH = "/meter-data"


class ConvergeAPIError(Exception):
    """Exception raised when Converge API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"Converge API request failed with status {status_code}"
        super().__init__(self.message)


class ConvergeRequestError(Exception):
    """Exception raised when there's a problem making the request to Converge."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class ConvergeApiClient(BearerTokenHTTPClient):
    """
    Converge API client for fetching meter data.
    Inherits from BearerTokenHTTPClient; performs username/password login to obtain
    a Bearer token, then uses the shared httpx client for meter-data requests.
    """

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        timeout: int = 300,
        logger: Logger | None = None,
        **kwargs,
    ):
        """
        Initialize the Converge API client.

        Args:
            host: Converge API host (e.g. "https://converge.finerge.pt")
            port: Converge API port
            username: Username for authentication
            password: Password for authentication
            timeout: Request timeout in seconds (default: 300 for Converge API)
            logger: Logger instance
            **kwargs: Additional arguments passed to BearerTokenHTTPClient (e.g. headers)
        """
        self._logger = logger or get_logger(__name__)
        self._username = username
        self._password = password

        base_url = f"{host}:{port}/rest_api/api/v1"
        kwargs.setdefault("timeout", timeout)

        super().__init__(base_url, token=None, logger=self._logger, **kwargs)

        self.token = self.login()
        self.login_func = self.login
        self._set_auth_header()

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to Converge-specific exceptions."""
        return ConvergeAPIError(exc.response.status_code, str(exc.request.url))

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to Converge-specific exceptions."""
        return ConvergeRequestError(str(exc), exc)

    def login(self) -> str:
        """Authenticate with the Converge API and return the Bearer token.

        Returns:
            Access token string for Bearer authentication.

        Raises:
            ConvergeAPIError: If authentication fails
            ConvergeRequestError: If there's a problem making the authentication request
        """
        auth = HTTPClientLabels.AUTH
        self._logger.info("auth started", action=auth.started, step=auth)

        payload = {"userName": self._username, "password": self._password}

        try:
            response = self.post(LOGIN_PATH, json=payload)
            token = response.get("token")
            if not token:
                self._logger.error("auth failed", action=auth.failed, step=auth, error_message="No token in response")
                raise ConvergeAPIError(200, "", "No token in login response")
            self._logger.info("auth completed", action=auth.completed, step=auth)
            return token
        except httpx.HTTPStatusError as exc:
            self._logger.error(
                "auth failed",
                action=auth.failed,
                step=auth,
                status_code=exc.response.status_code,
            )
            raise self._handle_http_error(exc) from exc
        except httpx.RequestError as exc:
            self._logger.error(
                "auth request failed",
                action=auth.failed,
                step=auth,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
            raise self._handle_request_error(exc) from exc

    def get_meter_data(
        self,
        meter_id: int,
        signal_ids: list[int],
        timestamp_start: datetime,
        timestamp_end: datetime,
    ) -> dict[str, Any] | None:
        """
        Fetch meter data from the Converge API.

        Args:
            meter_id: ID of the meter to fetch data for
            signal_ids: List of signal IDs to retrieve
            timestamp_start: Start timestamp for data retrieval
            timestamp_end: End timestamp for data retrieval

        Returns:
            Raw meter data response from the API, or None if failed after retries
        """
        payload = {
            "virtualMeters": [{"virtualMeterId": meter_id, "variableIds": signal_ids}],
            "dataFrom": timestamp_start.strftime("%Y-%m-%dT%H:%M:%S"),
            "dataTo": timestamp_end.strftime("%Y-%m-%dT%H:%M:%S"),
            "useMeterTimezoneAlignment": True,
        }

        retry_count = 0
        max_retries = 3

        while retry_count < max_retries:
            try:
                response_data = self.post(METER_DATA_PATH, json=payload)
                return response_data
            except ConvergeAPIError as e:
                if e.status_code == 401 and retry_count < max_retries - 1:
                    self._logger.warning(
                        "token expired, re-authenticating",
                        action=HTTPClientLabels.AUTH.retry,
                        step=HTTPClientLabels.AUTH,
                        attempt=retry_count + 1,
                    )
                    self.token = self.login()
                    self._set_auth_header()
                    retry_count += 1
                    continue
                self._logger.error(
                    "meter data request failed",
                    status_code=e.status_code,
                )
                return None
            except ConvergeRequestError as e:
                self._logger.error(
                    "meter data request failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                )
                return None

        self._logger.error(
            "meter data request failed after retries",
            meter_id=meter_id,
            max_retries=max_retries,
        )
        return None

    def _acquire_token_data(self) -> None:
        """Legacy method for backward compatibility. Delegates to login()."""
        self.token = self.login()
        self._set_auth_header()

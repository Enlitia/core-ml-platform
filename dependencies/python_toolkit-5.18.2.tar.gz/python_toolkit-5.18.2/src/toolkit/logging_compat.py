# toolkit/logging_compat.py
"""
Backward compatibility shims for the old logging API.

These classes are DEPRECATED and will be removed in a future version.
Use configure_logging() and get_logger() from toolkit.logging instead.
"""

from __future__ import annotations

import json
import logging
import warnings
from datetime import UTC, datetime

import structlog

# Standard LogRecord keys — computed once, reused in formatters.
_STANDARD_RECORD_KEYS = logging.LogRecord("", 0, "", 0, None, None, None).__dict__.keys()


class StructuredLogger:
    """
    DEPRECATED: Use configure_logging() and get_logger() instead.
    See docs/logging.md for migration guide.
    """

    def __init__(
        self,
        name: str,
        project: str,
        service: str,
        extra_defaults: dict | None = None,
        config: dict | None = None,
        logger: logging.Logger | None = None,
        force_reconfigure: bool = False,
    ):
        warnings.warn(
            "StructuredLogger is deprecated. Use configure_logging() instead. See docs/logging.md for migration guide.",
            DeprecationWarning,
            stacklevel=2,
        )

        if not name:
            raise ValueError("Logger name is required")

        # Lazy import to avoid circular dependency
        import toolkit.logging as tk_logging

        if logger is not None:
            # Honor a pre-configured stdlib logger by wrapping it for structlog
            self._logger = structlog.wrap_logger(logger)
        else:
            # Configure using new system if not already configured
            if not tk_logging._CONFIGURED or force_reconfigure:
                tk_logging.configure_logging(
                    project=project,
                    service=service,
                    config=config or {"level": "INFO", "format_type": "json"},
                    force_reconfigure=force_reconfigure,
                )

            self._logger = tk_logging.get_logger(name)

        self._name = name
        self._project = project
        self._service = service
        self._extra_defaults = extra_defaults or {}

        # Bind project/service and extra defaults using local logger binding
        # (not global contextvars) to preserve old StructuredLogger behaviour.
        bind_kwargs = {
            "project": self._project,
            "service": self._service,
            **self._extra_defaults,
        }
        self._logger = self._logger.bind(**bind_kwargs)

    @property
    def context(self) -> dict:
        # Preserve previous API: expose project, service, and extra defaults.
        return {
            "project": self._project,
            "service": self._service,
            **self._extra_defaults,
        }

    @property
    def extra_defaults(self) -> dict:
        return self._extra_defaults

    @property
    def logger(self) -> structlog.stdlib.BoundLogger:
        return self._logger

    def spawn(self, extra_defaults: dict | None = None) -> StructuredLogger:
        """
        Create a child logger with merged extra defaults.
        DEPRECATED: Use context() context manager instead.
        """
        merged_extras = {**self._extra_defaults, **(extra_defaults or {})}

        child = StructuredLogger(
            name=self._name,
            project=self._project,
            service=self._service,
            extra_defaults=merged_extras,
            config=None,
            logger=None,
        )
        return child

    def _log(self, method_name: str, message: str, *args, extra: dict | None = None, **kwargs):
        """Internal log method — unpacks extra into structlog kwargs."""
        log_method = getattr(self._logger, method_name)
        if extra:
            log_method(message, *args, **extra, **kwargs)
        else:
            log_method(message, *args, **kwargs)

    def debug(self, message: str, *args, extra: dict | None = None, **kwargs):
        self._log("debug", message, *args, extra=extra, **kwargs)

    def info(self, message: str, *args, extra: dict | None = None, **kwargs):
        self._log("info", message, *args, extra=extra, **kwargs)

    def warning(self, message: str, *args, extra: dict | None = None, **kwargs):
        self._log("warning", message, *args, extra=extra, **kwargs)

    def error(self, message: str, *args, extra: dict | None = None, **kwargs):
        self._log("error", message, *args, extra=extra, **kwargs)

    def critical(self, message: str, *args, extra: dict | None = None, **kwargs):
        self._log("critical", message, *args, extra=extra, **kwargs)

    def exception(self, message: str, *args, extra: dict | None = None, **kwargs):
        kwargs["exc_info"] = True
        self._log("error", message, *args, extra=extra, **kwargs)


class JsonFormatter(logging.Formatter):
    """DEPRECATED: Formats log records as JSON lines for backward compatibility.

    Produces one JSON object per log line with standard fields (timestamp, level,
    logger, event) plus any extras passed via the ``extra`` dict on the log call.

    Prefer using ``configure_logging(format_type="json")`` from ``toolkit.logging``
    instead. This class will be removed in a future version.
    """

    def __init__(self, *args, **kwargs):
        warnings.warn("JsonFormatter is deprecated.", DeprecationWarning, stacklevel=2)
        super().__init__(*args, **kwargs)

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict = {
            "timestamp": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "event": record.getMessage(),
        }
        _standard = _STANDARD_RECORD_KEYS
        for key, value in record.__dict__.items():
            if key not in _standard and key not in ("message", "msg", "args"):
                log_entry[key] = value
        if record.exc_info and record.exc_info[1] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry, default=str)


class TextFormatter(logging.Formatter):
    """DEPRECATED: Formats log records as human-readable text for backward compatibility.

    Produces ``TIMESTAMP LEVEL [LOGGER] MESSAGE key=value …`` lines, appending
    any extras passed via the ``extra`` dict on the log call.

    Prefer using ``configure_logging(format_type="console")`` from ``toolkit.logging``
    instead. This class will be removed in a future version.
    """

    def __init__(self, *args, **kwargs):
        warnings.warn("TextFormatter is deprecated.", DeprecationWarning, stacklevel=2)
        super().__init__(*args, **kwargs)

    def format(self, record: logging.LogRecord) -> str:
        timestamp = datetime.fromtimestamp(record.created, tz=UTC).strftime("%Y-%m-%d %H:%M:%S")
        base = f"{timestamp} {record.levelname} [{record.name}] {record.getMessage()}"
        _standard = _STANDARD_RECORD_KEYS
        extras = {
            k: v for k, v in record.__dict__.items() if k not in _standard and k not in ("message", "msg", "args")
        }
        if extras:
            extra_str = " ".join(f"{k}={v}" for k, v in extras.items())
            base = f"{base} {extra_str}"
        if record.exc_info and record.exc_info[1] is not None:
            base = f"{base}\n{self.formatException(record.exc_info)}"
        return base

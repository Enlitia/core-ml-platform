"""Reusable CLI utilities and base command patterns for Typer-based CLIs.

Provides:
- Annotated types for common CLI options (StartDate, EndDate, Historical)
- Factory for comma-separated ID options with auto-parsing (ids_option)
- Pre-built ID options (FarmIds, AssetIds, MeterIds, MarketIds)
- Validators and parsers (validate_timestamp, validate_resolution, validate_enum)
- Logger setup (setup_logger)
- Base runner for service commands (run_service)

Usage:
    from toolkit.cli import StartDate, EndDate, FarmIds, IdsType, ids_option, setup_logger, run_service

    # Pre-built types
    @app.command()
    def run(start: StartDate = None, end: EndDate = None, farm_ids: FarmIds = None):
        ...

    # Custom ID type (no toolkit edit needed)
    TurbineIds = ids_option('--turbine-ids')

    @app.command()
    def run(turbine_ids: TurbineIds = None):
        ...  # turbine_ids is already list[int] | None
"""

from datetime import UTC, datetime
from typing import Annotated, Any

import typer

from toolkit.configuration import configuration
from toolkit.database import database
from toolkit.logging import configure_logging, get_logger

# ---------------------------------------------------------------------------
# Datetime formats accepted by all CLI options
# ---------------------------------------------------------------------------

DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"]

# ---------------------------------------------------------------------------
# Annotated types for common CLI options
# ---------------------------------------------------------------------------

StartDate = Annotated[
    datetime | None,
    typer.Option("--start", "-s", help="Start date (YYYY-MM-DD)", formats=DATETIME_FORMATS),
]

EndDate = Annotated[
    datetime | None,
    typer.Option("--end", "-e", help="End date (YYYY-MM-DD)", formats=DATETIME_FORMATS),
]

AvailableDate = Annotated[
    datetime | None,
    typer.Option("--available-date", "-a", help="Available date (YYYY-MM-DD HH)", formats=["%Y-%m-%d %H"]),
]

Historical = Annotated[
    bool,
    typer.Option("--historical", help="Fetch historical data"),
]

# ---------------------------------------------------------------------------
# ID options — factory + pre-built common ones
# ---------------------------------------------------------------------------

# Runtime type after callback processing. Use for explicit type annotations.
type IdsType = list[int] | None


def _ids_callback(value: str | None) -> list[int] | None:
    """Parse comma-separated string of IDs into list[int]."""
    if value is None or not value.strip():
        return None
    try:
        return [int(v.strip()) for v in value.split(",") if v.strip()]
    except ValueError:
        raise typer.BadParameter("IDs must be comma-separated integers (e.g., 1,4,7)") from None


def ids_option(flag: str, label: str | None = None) -> Any:
    """Create a Typer Option that accepts comma-separated integer IDs.

    The CLI accepts a string (e.g., ``"1,4,7"``), which the callback parses
    into ``list[int] | None``.  The ``Annotated`` wrapper uses ``str | None``
    so Typer/Click treat the raw input as a single string; at runtime the
    parameter will already be ``list[int] | None``.

    Use the ``IdsType`` alias when you need to annotate the resolved value
    elsewhere (e.g., forwarding to a function)::

        from toolkit.cli import IdsType


        def process(farm_ids: IdsType) -> None: ...

    Args:
        flag: CLI flag name (e.g., ``'--turbine-ids'``).
        label: Human-readable label for help text. Derived from flag if omitted.

    Returns:
        An ``Annotated`` type alias ready to use as a parameter type hint.

    Example::

        TurbineIds = ids_option("--turbine-ids")


        @app.command()
        def run(turbine_ids: TurbineIds = None):
            # turbine_ids is list[int] | None at runtime
            ...
    """
    name = label or flag.lstrip("-").replace("-", " ")
    return Annotated[
        str | None,
        typer.Option(
            flag,
            help=f"{name.title()} (comma-separated: 1,4,7)",
            callback=_ids_callback,
        ),
    ]


FarmIds = ids_option("--farm-ids", "farm identifiers")
AssetIds = ids_option("--asset-ids", "asset identifiers")
MeterIds = ids_option("--meter-ids", "meter identifiers")
MarketIds = ids_option("--market-ids", "market identifiers")

# ---------------------------------------------------------------------------
# Validators and parsers
# ---------------------------------------------------------------------------


def validate_resolution(resolution: str) -> str:
    """Validate and normalize time component."""
    valid_resolutions = ["HOURLY", "DAILY"]
    normalized = resolution.upper()
    if normalized not in valid_resolutions:
        raise ValueError(f"Invalid resolution '{resolution}'. Valid options: {', '.join(valid_resolutions)}")
    return normalized


def validate_timestamp(timestamp: str | int | datetime | None) -> datetime:
    """Validate and convert a timestamp to a timezone-aware datetime in UTC.

    All outputs are normalized to UTC. Naive datetime inputs are assumed to be UTC.

    Accepts:
        - ``datetime`` objects (naive datetimes are treated as UTC)
        - ISO format strings (``2024-01-01T00:00:00Z``)
        - Date strings (``YYYY-MM-DD``, treated as UTC midnight)
        - Unix timestamps (int)
        - ``None`` raises ValueError

    Raises:
        ValueError: If timestamp is None or has an unsupported format/type.
    """
    if timestamp is None:
        raise ValueError("Timestamp cannot be None")

    if isinstance(timestamp, datetime):
        # If naive, assume UTC; if aware, convert to UTC
        return timestamp.replace(tzinfo=UTC) if timestamp.tzinfo is None else timestamp.astimezone(UTC)

    if isinstance(timestamp, int):
        return datetime.fromtimestamp(timestamp, tz=UTC)

    if isinstance(timestamp, str):
        try:
            return datetime.fromisoformat(timestamp.replace("Z", "+00:00")).astimezone(UTC)
        except ValueError:
            try:
                # Parse date string and treat as UTC midnight
                return datetime.strptime(timestamp, "%Y-%m-%d").replace(tzinfo=UTC)
            except ValueError as e:
                raise ValueError(
                    f"Invalid timestamp format '{timestamp}'. "
                    "Expected ISO format (e.g., 2024-01-01T00:00:00Z) or YYYY-MM-DD"
                ) from e

    raise ValueError(f"Unsupported timestamp type: {type(timestamp)}. Expected str, int, or datetime.")


def validate_enum(value: str, valid_values: list[str], *, case: str = "upper") -> str:
    """Validate a string value against a list of allowed values.

    Args:
        value: The value to validate.
        valid_values: List of allowed values (already in the target case).
        case: Normalization — ``'upper'``, ``'lower'``, or ``'preserve'``.

    Returns:
        The normalized value.

    Raises:
        ValueError: If value is not in valid_values after normalization.
    """
    if case == "upper":
        normalized = value.upper()
    elif case == "lower":
        normalized = value.lower()
    else:
        normalized = value

    if normalized not in valid_values:
        raise ValueError(f"Invalid value '{value}'. Valid options: {', '.join(valid_values)}")
    return normalized


# ---------------------------------------------------------------------------
# Logger setup
# ---------------------------------------------------------------------------


def setup_logger(name: str, *, project: str, service: str, config: dict | None = None, **extra: Any):
    """Configure logging and return a bound logger.

    Calls ``configure_logging`` once and returns a ``structlog`` bound logger
    via ``get_logger``.  Any extra keyword arguments are permanently bound
    to every log entry (e.g. ``data_source='Solcast'``).

    Args:
        name: Logger name (typically ``__name__`` or a class name).
        project: Project identifier (e.g. ``'Finerge'``, ``'Akuo'``).
        service: Service identifier (e.g. ``'MarketData'``).
        config: Logging configuration dict from
            ``configuration.settings.logging``.  When ``None`` the value is
            read automatically from ``configuration.settings``.
        **extra: Additional context fields bound to every log entry
            (e.g. ``data_source='Solcast'``).

    Returns:
        A ``structlog`` bound logger.
    """
    if config is None:
        config = getattr(configuration.settings, "logging", None) or {}
    configure_logging(project=project, service=service, config=config, **extra)
    logger = get_logger(name)
    return logger.bind(**extra) if extra else logger


# ---------------------------------------------------------------------------
# Base service runner
# ---------------------------------------------------------------------------


def run_service(
    service_class: type,
    *args: Any,
    project: str,
    service: str,
    data_source: str,
    use_session: bool = True,
    extra_defaults: dict[str, Any] | None = None,
    **kwargs: Any,
) -> None:
    """Execute a service with standard logger, session, and error handling.

    Calls ``setup_logger``, optionally opens a database session, instantiates
    the service, and calls ``execute()``. Exceptions are logged and re-raised.

    Args:
        service_class: The service class to instantiate.
        *args: Positional arguments forwarded to the service constructor.
        project: Project name for the logger (e.g., ``'Finerge'``).
        service: Service name for the logger (e.g., ``'MeteologicaForecastDataImporter'``).
        data_source: Data source label for log metadata (e.g., ``'Meteologica'``).
        use_session: If True (default), opens a ``database.session()`` and passes
            ``session=session`` to the service. Set to False for services that
            don't need a database session.
        extra_defaults: Additional default fields for the logger.
        **kwargs: Keyword arguments forwarded to the service constructor.

    Example::

        run_service(
            MeteologicaDataImporter,
            meteologica_client,
            project="Finerge",
            service="MeteologicaForecastDataImporter",
            data_source="Meteologica",
            config=config,
        )
    """
    extra: dict[str, Any] = {"data_source": data_source}
    if extra_defaults:
        extra.update(extra_defaults)

    logger = setup_logger(
        service_class.__name__,
        project=project,
        service=service,
        **extra,
    )

    try:
        if use_session:
            with database.session() as session:
                service_instance = service_class(*args, session=session, logger=logger, **kwargs)
                service_instance.execute()
        else:
            service_instance = service_class(*args, logger=logger, **kwargs)
            service_instance.execute()
    except Exception:
        logger.critical("service execution failed", service=service_class.__name__, exc_info=True)
        raise

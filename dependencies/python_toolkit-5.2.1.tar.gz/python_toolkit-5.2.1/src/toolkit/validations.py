class Validations:
    @staticmethod
    def is_of_type(object_to_check, supposed_to_be_type) -> bool:
        return isinstance(object_to_check, supposed_to_be_type)

    @staticmethod
    def is_of_type_or_raise_exception(object_to_check, supposed_to_be_type) -> None:
        if not Validations.is_of_type(object_to_check, supposed_to_be_type):
            raise TypeError(f"type of {object_to_check} must be the same as {supposed_to_be_type} type!")

    @staticmethod
    def has_attribute(object_to_check, attribute) -> bool:
        return hasattr(object_to_check, attribute)

    @staticmethod
    def has_attribute_or_raise_exception(object_to_check, attribute):
        if not Validations.has_attribute(object_to_check, attribute):
            raise ValueError(f"{object_to_check} must have attribute {attribute}!")

    @staticmethod
    def inclusive_number_between(lower_boundary, number, upper_boundary) -> bool:
        if lower_boundary > upper_boundary:
            raise ValueError(f"{lower_boundary} must be less or equal to {upper_boundary}!")

        return lower_boundary <= number and number <= upper_boundary

    @staticmethod
    def inclusive_number_between_or_raise_exception(lower_boundary, number, upper_boundary):
        if not Validations.inclusive_number_between(lower_boundary, number, upper_boundary):
            raise ValueError(f"{number} must be between {lower_boundary} and {upper_boundary}!")

    @staticmethod
    def inclusive_string_length_between(lower_boundary: int, string_to_check: str, upper_boundary: int) -> bool:
        Validations.is_of_type_or_raise_exception(string_to_check, str)
        return Validations.inclusive_number_between(lower_boundary, len(string_to_check), upper_boundary)

    @staticmethod
    def inclusive_string_length_between_or_raise_exception(
        lower_boundary: int, string_to_check: str, upper_boundary: int
    ):
        if not Validations.inclusive_string_length_between(lower_boundary, string_to_check, upper_boundary):
            raise ValueError(f"{string_to_check} length must be between {lower_boundary} and {upper_boundary}!")

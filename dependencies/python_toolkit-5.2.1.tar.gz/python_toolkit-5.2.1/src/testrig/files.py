def lines_without_new_line(f):
    """
    Returns the list of lines without the '\n'
    """

    if not hasattr(f, "readlines"):
        raise Exception(f"Expected a file, got something else: '{type(f)}'")

    return [line.rstrip("\n") for line in f.readlines()]

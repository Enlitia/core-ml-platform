# type: ignore
from typing import TypeVar

from sqlalchemy import Column, text
from sqlalchemy.orm.decl_api import DeclarativeMeta
from sqlalchemy.orm.session import Session

from toolkit.data.sql_datamodel import SQLDataModel
from toolkit.validations import Validations

V = TypeVar("V", bound=SQLDataModel)


class MySQLBaseRepository[V: SQLDataModel]:
    def __init__(self, object_type: type[V], session: Session | None = None):
        Validations.is_of_type_or_raise_exception(object_type, DeclarativeMeta)
        Validations.has_attribute_or_raise_exception(object_type, "__tablename__")
        if session:
            Validations.is_of_type_or_raise_exception(session, Session)

        self.model_type = object_type
        self.session = session

    def with_session(self, session: Session):
        Validations.is_of_type_or_raise_exception(session, Session)
        self.session = session

    def get_by_id(self, *kwargs) -> V:
        datamodel = self.session.get(self.model_type, kwargs)
        return datamodel

    def count(self) -> V:
        count = self.session.query(self.model_type).count()
        return count

    def all(self) -> list[V]:
        all_models = self.session.query(self.model_type).all()
        return all_models

    def save_one(self, model: V) -> V:
        Validations.is_of_type_or_raise_exception(model, self.model_type)
        self.session.add(model)
        return model

    def upsert_one(self, model: V) -> V:
        Validations.is_of_type_or_raise_exception(model, self.model_type)
        # Note: this is much faster than sqlalchemy merge, which is why it isn't used here.
        self.upsert_all([model])
        return model

    def upsert_all(self, model_list: list[V]) -> None:
        columns: list[Column] = self.model_type.__table__.columns
        all_attributes: list[str] = []
        for c in columns:
            all_attributes.append(str(c.name))

        attributes = " (" + ", ".join(all_attributes) + ")"

        binded_all_attributes: list[str] = []
        for c in all_attributes:
            binded_all_attributes.append(":" + c)

        values = " VALUES (" + ", ".join(binded_all_attributes) + ")"
        from sqlalchemy import inspect

        primary_keys = [primary_key.key for primary_key in inspect(self.model_type).primary_key]
        all_attributes_to_update: list[str] = [item for item in all_attributes if item not in primary_keys]

        attribute_update_strings: list[str] = []

        for attribute in all_attributes_to_update:
            attribute_update_strings.append(attribute + " = VALUES(" + attribute + ")")

        on_duplicate_key_update = " ON DUPLICATE KEY UPDATE " + ", ".join(attribute_update_strings)

        sql_stmt = f"""INSERT INTO {self.model_type.__tablename__} {attributes} {values} {on_duplicate_key_update}"""
        self.session.execute(text(sql_stmt), [model.to_dict() for model in model_list])

    def __len__(self):
        return self.count()

    def __getitem__(self, *kwargs) -> V:
        return self.get_by_id(*kwargs)

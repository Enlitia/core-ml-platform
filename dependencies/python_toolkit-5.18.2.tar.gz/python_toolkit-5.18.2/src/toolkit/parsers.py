"""Parsing utilities for data transformation."""


def parse_availability(value: str) -> float:
    """
    Parse availability value from CSV to float (0-1 scale).

    Supports multiple formats and normalizes to 0-1 scale:
    - Percentage: "50%", "75%" → 0.5, 0.75
    - Integer: "50", "75" → 0.5, 0.75
    - Float (0-1): "0.5", "0.75" → 0.5, 0.75
    - Float (0-100): "50.5", "75.3" → 0.505, 0.753

    Args:
        value: Availability value as string from CSV

    Returns:
        Availability value as float (0-1 scale)

    Raises:
        ValueError: If value is empty, invalid format, or out of range

    Examples:
        >>> parse_availability("50%")
        0.5
        >>> parse_availability("75")
        0.75
        >>> parse_availability("0.8")
        0.8
        >>> parse_availability("100")
        1.0
    """
    if not value:
        raise ValueError("Availability value is empty")

    # Remove whitespace
    value = value.strip()

    # Normalize decimal separator (handle both European and US formats)
    # "99,5" → "99.5" (European format with comma)
    value = value.replace(",", ".")

    # Check for invalid double percentage
    if value.count("%") > 1:
        raise ValueError(f"Invalid availability format: {value}")

    try:
        # Handle percentage format: "50%" → 50
        if value.endswith("%"):
            availability = float(value.rstrip("%"))

        # Handle decimal values: can be 0-1 ("0.5") or 0-100 ("50.5")
        elif "." in value:
            float_val = float(value)
            # Keep raw decimal value; it will be validated and normalized below
            availability = float_val

        # Handle integer: "50" → 50
        else:
            availability = float(value)

    except ValueError as e:
        raise ValueError(f"Invalid availability format: {value}") from e

    # Validate range
    if not 0 <= availability <= 100:
        raise ValueError(f"Availability must be 0-100, got: {availability}")

    # Normalize to 0-1 scale
    if availability > 1:
        availability = availability / 100

    return availability

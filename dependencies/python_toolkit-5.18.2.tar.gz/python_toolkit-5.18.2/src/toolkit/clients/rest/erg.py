"""ERG API client for SCADA, outages, meters and forecast data.

Provides a client for the ERG (ERG Renew) databrowsing API on Azure APIM.
Uses OAuth2 client_credentials against Microsoft Entra ID to obtain a Bearer
token, then POSTs JSON bodies to SCADA, outage, observation and forecast
endpoints.

Based on DHG&M_AID_01.0 (API Interface Description for SCADA data) and
ERG API - Enlitia Postman collection.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

import httpx

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import HTTPClientLabels, Logger, get_logger

logger = get_logger(__name__)


class ErgApiPath(StrEnum):
    """ERG API endpoint paths (all POST with JSON body)."""

    SCADA = "databrowsing/api/ScadaVx"
    OUTAGE = "databrowsing/api/outage"
    OBSERVATION = "databrowsing/api/observation"
    FORECAST = "databrowsing/api/forecast"


class ErgError(Exception):
    """Base exception for ERG API client errors."""

    pass


class ErgAPIError(ErgError):
    """Exception raised when ERG API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"ERG API request failed with status {status_code}"
        super().__init__(self.message)


class ErgRequestError(ErgError):
    """Exception raised when there's a problem making the request to ERG."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


@dataclass
class GetDevicesFilter:
    """Body filter for get_devices (SCADA GetDevices).

    Attributes:
        sse: SSE code (e.g. SSEFossa, SSEMineoRRP).
        plant: Plant code (e.g. FDLR, Vizzini).
        addictionalInfo: If True, response includes lat/lon, serial, model, etc.
    """

    sse: str
    plant: str
    addictionalInfo: bool = False

    def to_filter_dict(self) -> dict[str, object]:
        return {"sse": self.sse, "plant": self.plant, "addictionalInfo": self.addictionalInfo}


@dataclass
class GetMeasuresFilter:
    """Body filter for get_measures (SCADA GetMeasures).

    Attributes:
        sse: SSE code.
        plant: Plant code.
        section: Section (e.g. L1, QMT2 - Line 04).
        subsystem: Subsystem (e.g. WPP).
        device: Device id (e.g. GAS57, R-VZ14).
    """

    sse: str
    plant: str
    section: str
    subsystem: str
    device: str

    def to_filter_dict(self) -> dict[str, object]:
        return {
            "sse": self.sse,
            "plant": self.plant,
            "section": self.section,
            "subsystem": self.subsystem,
            "device": self.device,
        }


@dataclass
class DeviceMeasureRequest:
    """One measure to request in get_advanced_data_by_date.

    Attributes:
        type: Measure type (e.g. DMAV).
        name: Measure name (e.g. Active Power, Wind Speed).
    """

    type: str
    name: str

    def to_dict(self) -> dict[str, str]:
        return {"type": self.type, "name": self.name}


@dataclass
class DeviceDataRequest:
    """One device + measures for get_advanced_data_by_date.

    Attributes:
        sse: SSE code.
        plant: Plant code.
        subsystem: Subsystem (e.g. WPP).
        section: Section (e.g. QMT2 - Line 04).
        device: Device id.
        measures: List of measure type+name to request.
    """

    sse: str
    plant: str
    subsystem: str
    section: str
    device: str
    measures: list[DeviceMeasureRequest]

    def to_dict(self) -> dict[str, object]:
        return {
            "sse": self.sse,
            "plant": self.plant,
            "subsystem": self.subsystem,
            "section": self.section,
            "device": self.device,
            "measures": [m.to_dict() for m in self.measures],
        }


@dataclass
class GetAdvancedDataByDateFilter:
    """Body filter for get_advanced_data_by_date (SCADA time-series).

    Attributes:
        devices: List of device + measures to query.
        date_start: Start date (e.g. 2024-09-01 or 2024-09-01 00:00:00).
        date_stop: End date (e.g. 2024-09-02).
        time_zone: IANA timezone (e.g. Europe/Rome).
    """

    devices: list[DeviceDataRequest]
    date_start: str
    date_stop: str
    time_zone: str

    def to_filter_dict(self) -> dict[str, object]:
        return {
            "devices": [d.to_dict() for d in self.devices],
            "date_start": self.date_start,
            "date_stop": self.date_stop,
            "time_zone": self.time_zone,
        }


@dataclass
class GetOutagesBody:
    """Body for get_outages (actual or planned outages).

    Attributes:
        fromDate_UTC: Start datetime UTC (e.g. 2025-01-01T00:00:00+0000).
        toDate_UTC: End datetime UTC.
        limitationType: ACTUALFACILITY, ACTUALGRID for actual; FACILITY, GRID for planned.
        upname: List of UP codes (e.g. UP_VIZZINI_1).
        provider: Optional list of providers (often []).
    """

    fromDate_UTC: str
    toDate_UTC: str
    limitationType: str
    upname: list[str]
    provider: list[str] = field(default_factory=list)

    def to_body_dict(self) -> dict[str, object]:
        return {
            "fromDate_UTC": self.fromDate_UTC,
            "toDate_UTC": self.toDate_UTC,
            "limitationType": self.limitationType,
            "upname": self.upname,
            "provider": self.provider,
        }


@dataclass
class GetMeterObservationsBody:
    """Body for get_meter_observations.

    Attributes:
        from_UTC: Start datetime UTC (e.g. 2025-11-01T00:00:00Z).
        to_UTC: End datetime UTC.
        aggregatedData: "true" or "false".
        type: "meter".
        upname: List of UP codes.
    """

    from_UTC: str
    to_UTC: str
    aggregatedData: str = "false"
    type: str = "meter"
    upname: list[str] = field(default_factory=list)

    def to_body_dict(self) -> dict[str, object]:
        return {
            "from_UTC": self.from_UTC,
            "to_UTC": self.to_UTC,
            "aggregatedData": self.aggregatedData,
            "type": self.type,
            "upname": self.upname,
        }


@dataclass
class GetForecastBody:
    """Body for get_forecast.

    Attributes:
        from_UTC: Start datetime UTC.
        to_UTC: End datetime UTC.
        provider: List of providers (often []).
        mode: e.g. "realtime".
        upname: List of UP codes.
        maxSizeBlock: e.g. "1000".
        blockNumber: e.g. "1".
        granularity: e.g. "15" (minutes).
    """

    from_UTC: str
    to_UTC: str
    provider: list[str] = field(default_factory=list)
    mode: str = "realtime"
    upname: list[str] = field(default_factory=list)
    maxSizeBlock: str = "1000"
    blockNumber: str = "1"
    granularity: str = "15"

    def to_body_dict(self) -> dict[str, object]:
        return {
            "from_UTC": self.from_UTC,
            "to_UTC": self.to_UTC,
            "provider": self.provider,
            "mode": self.mode,
            "upname": self.upname,
            "maxSizeBlock": self.maxSizeBlock,
            "blockNumber": self.blockNumber,
            "granularity": self.granularity,
        }


class ErgApiClient(BearerTokenHTTPClient):
    """HTTP client for ERG databrowsing API (SCADA, outages, meters, forecast).

    Uses OAuth2 client_credentials to obtain a Bearer token from Microsoft
    Entra ID, then calls ERG endpoints with optional Azure APIM subscription key.
    """

    def __init__(
        self,
        base_url: str,
        token_url: str,
        client_id: str,
        client_secret: str,
        scope: str,
        subscription_key: str | None = None,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the ERG API client.

        Args:
            base_url: ERG API base URL (from config).
            token_url: OAuth2 token endpoint (from config).
            client_id: OAuth2 client ID.
            client_secret: OAuth2 client secret.
            scope: OAuth2 scope (from config).
            subscription_key: Optional Azure APIM subscription key (Ocp-Apim-Subscription-Key).
            logger: Optional logger.
            **kwargs: Passed to BearerTokenHTTPClient (e.g. timeout).
        """
        self._logger = logger or get_logger(__name__)
        self._token_url = token_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._subscription_key = subscription_key or ""

        super().__init__(base_url, token=None, logger=self._logger, **kwargs)

        self.token = self.login()
        self.login_func = self.login
        self._set_auth_header()

    @property
    def _default_headers(self) -> dict[str, str]:
        """Default headers including Authorization and optional APIM key."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self._subscription_key:
            headers["Ocp-Apim-Subscription-Key"] = self._subscription_key
        return headers

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to ERG-specific exceptions."""
        return ErgAPIError(exc.response.status_code, str(exc.request.url))

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to ERG-specific exceptions."""
        return ErgRequestError(str(exc), exc)

    def login(self) -> str:
        """Obtain Bearer token via OAuth2 client_credentials.

        Returns:
            Access token string.

        Raises:
            ErgAPIError: If token endpoint returns an error.
            ErgRequestError: If the token request fails.
        """
        auth_label = HTTPClientLabels.AUTH
        self._logger.debug(
            "auth started",
            action=auth_label.started,
            step=auth_label,
        )

        data = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "scope": self._scope,
        }

        try:
            # Token endpoint is on a different host; use a one-off request
            response = httpx.post(
                self._token_url,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data=data,
                timeout=30.0,
            )
        except Exception as e:
            self._logger.error(
                "auth request failed",
                action=auth_label.failed,
                step=auth_label,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise ErgRequestError(str(e), e) from e

        if response.status_code >= 400:
            self._logger.error(
                "auth failed",
                action=auth_label.failed,
                step=auth_label,
                status_code=response.status_code,
            )
            raise ErgAPIError(response.status_code, self._token_url, response.text or "")

        body = response.json()
        token = body.get("access_token")
        if not token:
            self._logger.error(
                "auth failed",
                action=auth_label.failed,
                step=auth_label,
                error_message="No access_token in token response",
            )
            raise ErgAPIError(200, self._token_url, "No access_token in token response")

        self._logger.debug(
            "auth completed",
            action=auth_label.completed,
            step=auth_label,
            token_url=self._token_url,
        )
        return token

    def _scada_post(self, select: str, filter_body: dict[str, object], history: str = "true") -> dict[str, object]:
        """POST to ScadaVx with Select and Filter."""
        body = {"Select": select, "Filter": filter_body, "History": history}
        return self.post(ErgApiPath.SCADA, json=body)

    def get_devices(
        self,
        filter_body: GetDevicesFilter,
        history: str = "false",
    ) -> dict[str, object]:
        """Get devices for a plant (SCADA GetDevices).

        Args:
            filter_body: GetDevicesFilter(sse, plant, addictionalInfo).
            history: "true" or "false".

        Returns:
            Raw JSON response from ERG.
        """
        return self._scada_post("GetDevices", filter_body.to_filter_dict(), history=history)

    def get_measures(
        self,
        filter_body: GetMeasuresFilter,
        history: str = "false",
    ) -> dict[str, object]:
        """Get measures for a device (SCADA GetMeasures).

        Args:
            filter_body: GetMeasuresFilter(sse, plant, section, subsystem, device).
            history: "true" or "false".

        Returns:
            Raw JSON response from ERG.
        """
        return self._scada_post("GetMeasures", filter_body.to_filter_dict(), history=history)

    def get_advanced_data_by_date(
        self,
        filter_body: GetAdvancedDataByDateFilter,
        history: str = "true",
    ) -> dict[str, object]:
        """Get time-series data by date range (SCADA getAdvancedDataByDate).

        Args:
            filter_body: GetAdvancedDataByDateFilter(devices, date_start, date_stop, time_zone).
            history: "true" or "false".

        Returns:
            Raw JSON response from ERG.
        """
        return self._scada_post("getAdvancedDataByDate", filter_body.to_filter_dict(), history=history)

    def get_outages(self, body: GetOutagesBody) -> dict[str, object]:
        """Get actual or planned outages (POST /databrowsing/api/outage).

        Args:
            body: GetOutagesBody(fromDate_UTC, toDate_UTC, limitationType, upname, provider).
                limitationType: "ACTUALFACILITY, ACTUALGRID" for actual; "FACILITY, GRID" for planned.

        Returns:
            Raw JSON response from ERG.
        """
        return self.post(ErgApiPath.OUTAGE, json=body.to_body_dict())

    def get_meter_observations(self, body: GetMeterObservationsBody) -> dict[str, object]:
        """Get meter observations (POST /databrowsing/api/observation).

        Args:
            body: GetMeterObservationsBody(from_UTC, to_UTC, aggregatedData, type, upname).

        Returns:
            Raw JSON response from ERG.
        """
        return self.post(ErgApiPath.OBSERVATION, json=body.to_body_dict())

    def get_forecast(self, body: GetForecastBody) -> dict[str, object]:
        """Get forecast data (POST /databrowsing/api/forecast).

        Args:
            body: GetForecastBody(from_UTC, to_UTC, provider, mode, upname, ...).

        Returns:
            Raw JSON response from ERG.
        """
        return self.post(ErgApiPath.FORECAST, json=body.to_body_dict())

import pathlib
import re
from typing import List, Union


class Directory:
    """
    Provides utils to introspect a directory.
    """

    def __init__(self, path: pathlib.Path) -> None:
        self._path = path

    @staticmethod
    def _validate_extension(extension: str) -> None:
        try:
            matches = re.match(r"\.[a-zA-Z]+$", extension)
        except TypeError:
            # Integers fall here!
            raise ValueError(f"Invalid extension '{extension}'")

        if not matches:
            raise ValueError(f"Invalid extension '{extension}'")

    def files_in(self, /, *, having_extension: Union[str, None] = None) -> List[pathlib.Path]:
        """
        Returns a list of the paths for each file in the directory.

        :param: having_extension: The extension of the files to look for. Must
                                  start with '.'
        """

        pattern = "*"
        if having_extension:
            self._validate_extension(having_extension)
            pattern = f"*{having_extension}"

        p = pathlib.Path(self._path).glob(pattern)
        files = [x for x in p if x.is_file()]
        return files

    def directories_in(self) -> List[pathlib.Path]:
        """
        Returns a list of the paths for each directory inside the directory.
        """
        p = pathlib.Path(self._path).glob("*")
        directories = [x for x in p if x.is_dir()]
        return directories

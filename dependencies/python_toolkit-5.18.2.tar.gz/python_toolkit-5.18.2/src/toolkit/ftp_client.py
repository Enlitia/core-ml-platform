"""FTP/FTPS client implementation."""

import os
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from ftplib import (  # nosec B402 - FTP support needed for legacy systems
    FTP,
    FTP_TLS,
    error_perm,
    error_temp,
)
from pathlib import Path

from toolkit.file_transfer import (
    BaseFileTransferClient,
    FileTransferAuthenticationError,
    FileTransferConfig,
    FileTransferConnectionError,
    FileTransferOperationError,
)
from toolkit.logging import FileTransferLabels


@dataclass
class FTPConfig(FileTransferConfig):
    """Configuration for FTP connections."""

    port: int = 21
    use_ssl: bool = False
    passive_mode: bool = True

    def __post_init__(self):
        """Set port to 990 for implicit FTPS if use_ssl=True and port is default 21."""
        if self.use_ssl and self.port == 21:
            self.port = 990


class FTPClient(BaseFileTransferClient):
    """FTP/FTPS client implementation using Python's ftplib."""

    config: FTPConfig  # Override parent type annotation
    _connection: FTP | FTP_TLS | None = None  # Override parent type annotation

    def connect(self) -> None:
        """Establish FTP or FTPS connection.

        Automatically detects and uses the appropriate connection type:
        - Port 990: Implicit FTPS with TLS encryption
        - Other ports: Regular FTP

        Raises:
            FileTransferAuthenticationError: If login credentials are invalid
            FileTransferConnectionError: If connection cannot be established
        """
        ft = FileTransferLabels
        try:
            # Use FTP_TLS for secure FTP, regular FTP otherwise
            if self.config.port == 990:  # Implicit FTPS
                self._connection = FTP_TLS()
                self._connection.connect(self.config.host, self.config.port, self.config.timeout)
                self._connection.auth()  # Secure the connection
            else:
                self._connection = FTP()  # nosec B321 - FTP support needed for legacy systems
                self._connection.connect(self.config.host, self.config.port, self.config.timeout)

            # Login
            if self.config.username:
                self._connection.login(self.config.username, self.config.password)

            # Set passive mode
            if hasattr(self._connection, "set_pasv"):
                self._connection.set_pasv(self.config.passive_mode)

            self._logger.info(
                "connected", action=ft.CONNECT.completed, step=ft.CONNECT, host=self.config.host, port=self.config.port
            )

        except (error_perm, error_temp) as e:
            self._logger.error(
                "authentication failed",
                action=ft.CONNECT.failed,
                step=ft.CONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferAuthenticationError(f"FTP authentication failed: {e}", e) from e
        except Exception as e:
            self._logger.error(
                "connection failed",
                action=ft.CONNECT.failed,
                step=ft.CONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferConnectionError(f"FTP connection failed: {e}", e) from e

    @property
    def connection(self) -> FTP | FTP_TLS:
        """Get the FTP/FTPS connection."""
        if self._connection is None:
            raise FileTransferOperationError("Not connected to server")
        return self._connection  # type: ignore[return-value]

    def disconnect(self) -> None:
        """Close FTP connection gracefully."""
        try:
            if self._connection:
                self.connection.quit()
                self._connection = None
            self._logger.debug(
                "disconnected", action=FileTransferLabels.DISCONNECT.completed, step=FileTransferLabels.DISCONNECT
            )
        except Exception as e:
            self._logger.warning(
                "disconnect error",
                action=FileTransferLabels.DISCONNECT.failed,
                step=FileTransferLabels.DISCONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )

    def list_directory(self, path: str = "/") -> list[str]:
        """List files and directories in the specified path."""
        resolved_path = self._resolve_path(path)
        try:
            return self.connection.nlst(resolved_path)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to list directory '{resolved_path}': {e}", e) from e

    def download_file(self, remote_path: str, local_path: str) -> None:
        """Download a file from the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            with open(local_path, "wb") as local_file:
                self.connection.retrbinary(f"RETR {resolved_remote_path}", local_file.write)
            self._logger.debug(
                "file downloaded",
                action=FileTransferLabels.DOWNLOAD.completed,
                step=FileTransferLabels.DOWNLOAD,
                remote_path=resolved_remote_path,
                local_path=local_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to download '{resolved_remote_path}': {e}", e) from e

    def upload_file(self, local_path: str, remote_path: str) -> None:
        """Upload a file to the remote server."""
        if not os.path.exists(local_path):
            raise FileTransferOperationError(f"Local file does not exist: {local_path}")

        resolved_remote_path = self._resolve_path(remote_path)
        try:
            with open(local_path, "rb") as local_file:
                self.connection.storbinary(f"STOR {resolved_remote_path}", local_file)
            self._logger.debug(
                "file uploaded",
                action=FileTransferLabels.UPLOAD.completed,
                step=FileTransferLabels.UPLOAD,
                local_path=local_path,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to upload '{local_path}': {e}", e) from e

    def delete_file(self, remote_path: str) -> None:
        """Delete a file on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.delete(resolved_remote_path)
            self._logger.debug(
                "file deleted",
                action=FileTransferLabels.DELETE.completed,
                step=FileTransferLabels.DELETE,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to delete '{resolved_remote_path}': {e}", e) from e

    def create_directory(self, remote_path: str) -> None:
        """Create a directory on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.mkd(resolved_remote_path)
            self._logger.debug(
                "directory created",
                action=FileTransferLabels.MKDIR.completed,
                step=FileTransferLabels.MKDIR,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to create directory '{resolved_remote_path}': {e}", e) from e

    def remove_directory(self, remote_path: str) -> None:
        """Remove a directory on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.rmd(resolved_remote_path)
            self._logger.debug(
                "directory removed",
                action=FileTransferLabels.RMDIR.completed,
                step=FileTransferLabels.RMDIR,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to remove directory '{resolved_remote_path}': {e}", e) from e

    def file_exists(self, remote_path: str) -> bool:
        """Check if a file exists on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.size(resolved_remote_path)
            return True
        except error_perm:
            return False
        except Exception as e:
            raise FileTransferOperationError(f"Failed to check if file exists '{resolved_remote_path}': {e}", e) from e

    def get_file_size(self, remote_path: str) -> int:
        """Get the size of a file on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            size = self.connection.size(resolved_remote_path)
            if size is None:
                raise FileTransferOperationError(f"Could not determine size of '{resolved_remote_path}'")
            return size
        except Exception as e:
            raise FileTransferOperationError(f"Failed to get file size '{resolved_remote_path}': {e}", e) from e

    @contextmanager
    def change_directory(self, remote_path: str) -> Generator[None, None, None]:
        """Context manager to temporarily change to a different directory.

        Changes to the specified directory and automatically returns to the
        original directory when exiting the context.

        Args:
            remote_path: Path to the directory to change to

        Yields:
            None (for use in with statements)

        Raises:
            FileTransferOperationError: If directory change fails

        Example:
            with client.change_directory("/tmp"):
                # Operations here are performed in /tmp
                client.upload_file("local.txt", "remote.txt")
            # Automatically returns to original directory
        """
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            original_path = self.connection.pwd()
            self.connection.cwd(resolved_remote_path)
            try:
                yield
            finally:
                self.connection.cwd(original_path)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to change directory to '{resolved_remote_path}': {e}", e) from e

    # FTP-specific methods

    def set_passive_mode(self, passive: bool) -> None:
        """Set FTP passive mode - FTP-specific method."""
        if self.is_connected() and hasattr(self._connection, "set_pasv"):
            self.connection.set_pasv(passive)
            self.config.passive_mode = passive

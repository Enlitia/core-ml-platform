"""Base HTTP client for API integrations.

This module provides a common base class for HTTP-based API clients, handling
common concerns like authentication, error handling, logging, and resource management.
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

import httpx

from toolkit.logging import HTTPClientLabels, Logger, get_logger


class HTTPClientError(Exception):
    """Base exception for HTTP client errors."""

    pass


class HTTPAPIError(HTTPClientError):
    """Exception raised when API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"API request failed with status {status_code}"
        super().__init__(self.message)


class HTTPRequestError(HTTPClientError):
    """Exception raised when there's a problem making the HTTP request."""

    def __init__(self, message: str, original_exception: Exception | None):
        """Initialize the HTTP request error.

        Args:
            message: Human-readable error message describing the failure.
            original_exception: Underlying exception that caused the failure, if any.
        """
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class BaseHTTPClient(ABC):
    """Base class for HTTP API clients.

    Provides common functionality for HTTP-based API integrations including:
    - HTTP client lifecycle management
    - Authentication handling
    - Error handling and conversion
    - Request/response logging
    - Context manager support

    Subclasses should implement the abstract methods to define their specific
    error handling and authentication strategies.
    """

    def __init__(self, base_url: str, logger: Logger | None = None, **kwargs):
        """Initialize the HTTP client.

        Args:
            base_url: Base URL for the API
            logger: Structured logger instance. If not provided, a default logger is created.
            **kwargs: Additional arguments passed to configure_client()
        """
        self.base_url = base_url
        self.logger: Logger = logger or get_logger(__name__)
        self._client: httpx.Client | None = None
        self._configure_client(**kwargs)

    def _configure_client(self, **kwargs) -> None:
        """Configure the HTTP client with base settings.

        Args:
            **kwargs: Configuration options (timeout, headers, etc.)
        """
        headers = dict(self._default_headers)
        headers.update(kwargs.get("headers", {}))

        client_kwargs = {
            "base_url": self.base_url,
            "headers": headers,
            "timeout": kwargs.get("timeout", 30.0),
        }

        # Add any additional httpx.Client kwargs
        for key in ["verify", "cert", "proxies", "limits"]:
            if key in kwargs:
                client_kwargs[key] = kwargs[key]

        self._client = httpx.Client(**client_kwargs)

    @property
    @abstractmethod
    def _default_headers(self) -> dict[str, str]:
        """Default headers for requests.

        Returns:
            Dictionary of default headers
        """
        pass

    @abstractmethod
    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP status errors to domain-specific exceptions.

        Args:
            exc: The HTTP status error from httpx

        Returns:
            Domain-specific exception to raise
        """
        pass

    @abstractmethod
    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to domain-specific exceptions.

        Args:
            exc: The request error from httpx

        Returns:
            Domain-specific exception to raise
        """
        pass

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures HTTP client is properly closed."""
        self.close()

    def close(self) -> None:
        """Close the HTTP client and clean up resources."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def _make_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: Any | None = None,
        headers: dict[str, str] | None = None,
        auth: httpx.Auth | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP request with error handling and logging.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API endpoint path
            params: Query parameters
            json: JSON body data
            data: Form/raw body data
            headers: Additional headers for this request

        Returns:
            Parsed JSON response

        Raises:
            Domain-specific exceptions via _handle_http_error() and _handle_request_error()
        """
        if self._client is None:
            raise RuntimeError("HTTP client not initialized")

        url = f"/{path.lstrip('/')}"
        http_method = method.upper()
        api = HTTPClientLabels.API

        try:
            self.logger.debug(
                "API request started",
                action=api.started,
                method=http_method,
                url=url,
            )

            response = self._client.request(
                method=method,
                url=url,
                params=params,
                json=json,
                data=data,
                headers=headers,
                auth=auth,
            )

            response_url = str(response.url)
            status_code = response.status_code

            # Handle HTTP errors
            if status_code >= 400:
                raise httpx.HTTPStatusError(f"HTTP {status_code}", request=response.request, response=response)

            self.logger.info(
                "API request completed",
                action=api.completed,
                method=http_method,
                url=response_url,
                status_code=status_code,
            )
            return response.json()

        except httpx.HTTPStatusError as exc:
            self.logger.error(
                "HTTP status error",
                action=api.failed,
                method=http_method,
                url=str(exc.request.url),
                status_code=exc.response.status_code,
                error_message=exc.response.text if exc.response.text else "no error message from api",
            )
            raise self._handle_http_error(exc) from exc

        except httpx.RequestError as exc:
            self.logger.error(
                "API request failed",
                action=api.failed,
                method=http_method,
                url=url,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
            raise self._handle_request_error(exc) from exc

    def get(self, path: str, **kwargs) -> dict[str, Any]:
        """Make a GET request."""
        return self._make_request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> dict[str, Any]:
        """Make a POST request."""
        return self._make_request("POST", path, **kwargs)

    def put(self, path: str, **kwargs) -> dict[str, Any]:
        """Make a PUT request."""
        return self._make_request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs) -> dict[str, Any]:
        """Make a DELETE request."""
        return self._make_request("DELETE", path, **kwargs)


class BearerTokenHTTPClient(BaseHTTPClient):
    """HTTP client with Bearer token authentication.

    Common base class for APIs that use Bearer token authentication.

    The client ensures the token is set before making any requests by raising
    an HTTPRequestError if the token is not set. Subclasses should call this
    method in their initialization to ensure the client is authenticated.
    """

    login_func: Callable[[], str] | None = None

    def __init__(self, base_url: str, token: str | None = None, login_func: Callable[[], str] | None = None, **kwargs):
        """Initialize with Bearer token.

        Args:
            base_url: Base URL for the API
            token: Bearer token for authentication
            login_func: Optional callable for login/authentication
        """
        # Set token attribute BEFORE calling super().__init__ which will call _configure_client
        # which in turn accesses _default_headers that needs self.token
        self.token = token
        self.login_func = login_func

        super().__init__(base_url, **kwargs)

    @property
    def _default_headers(self) -> dict[str, str]:
        """Default headers including Authorization."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _set_auth_header(self):
        """Set the Authorization header with the current token."""
        if self._client is not None:
            self._client.headers["Authorization"] = f"Bearer {self.token}"


class APIKeyHTTPClient(BaseHTTPClient):
    """HTTP client with API key header authentication.

    Common base class for APIs that use x-apikey or similar header authentication.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        api_key_header: str = "x-apikey",
        **kwargs,
    ):
        """Initialize with API key.

        Args:
            base_url: Base URL for the API
            api_key: API key for authentication
            api_key_header: Header name for the API key (default: "x-apikey")
            **kwargs: Additional client configuration (including custom headers)
        """
        self.api_key = api_key
        self.api_key_header = api_key_header
        super().__init__(base_url, **kwargs)

    @property
    def _default_headers(self) -> dict[str, str]:
        """Default headers including API key."""
        return {
            self.api_key_header: self.api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

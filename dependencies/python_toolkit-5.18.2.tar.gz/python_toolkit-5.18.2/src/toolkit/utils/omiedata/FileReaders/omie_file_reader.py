import pandas as pd
from requests import Response  # type: ignore[import-untyped]


class OMIEFileReader:
    def get_keys(self) -> list:
        raise NotImplementedError

    def get_data_from_file(self, filename: str) -> pd.DataFrame:
        raise NotImplementedError

    def get_data_from_response(self, response: Response) -> pd.DataFrame:
        raise NotImplementedError

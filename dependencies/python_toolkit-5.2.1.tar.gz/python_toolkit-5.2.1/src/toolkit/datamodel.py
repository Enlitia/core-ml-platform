from toolkit.database import DataModelBase


class ErrorNoDataModelDefined(Exception):
    pass


class DataModelReader:
    data_model: DataModelBase = None

    def __init__(self, session):
        self.session = session

        if not self.data_model:
            raise ErrorNoDataModelDefined()

    def count(self) -> int:
        return self.session.query(self.data_model).count()

    def exists_by_id(self, item) -> bool:
        q = self.session.query(self.data_model.id).filter(self.data_model.id == item.id)
        return self.session.query(q.exists()).scalar()

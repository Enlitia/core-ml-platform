"""
Views are a way of inspecting the state of an application.
"""

import abc
import typing
from datetime import date


class ErrorValidation(Exception):
    pass


class ViewField:
    """
    A field that can be attached to a view.
    """

    def __init__(self, *, optional: bool = False):
        self.optional = optional

    @abc.abstractmethod
    def validate(self, raw_input):
        return raw_input


class ListOfIntegers(ViewField):
    def validate(self, list_of_integers: typing.Any) -> typing.List[int]:
        try:
            integers = [i for i in list_of_integers.split(",")]
        except AttributeError:
            integers = list_of_integers

        li: typing.List[int] = []
        for i in integers:
            try:
                li.append(int(i))
            except ValueError:
                raise ValueError(f"'{i}' is not a valid integer")
            except TypeError:
                raise ValueError(f"'{i}' is not a valid integer")

        # Make sure all values are unique!
        # I can't see a use case where someone needs repeated values, so
        # let's not overwhelm the server!
        if len(integers) > len(set(integers)):
            raise ValueError("values are not unique")

        return li


class IntegerField(ViewField):
    def validate(self, raw_input):
        return int(raw_input)


class DateField(ViewField):
    def validate(self, raw_input: date) -> date:
        if not isinstance(raw_input, date):
            raise ErrorValidation(f"invalid date value '{raw_input}'")

        return raw_input


class IdentifierField(IntegerField):
    def validate(self, raw_input):
        raw_input = super().validate(raw_input)
        if raw_input <= 0:
            raise ValueError(f"'{raw_input}' is not a valid identifier, should be greater than zero")

        return raw_input


ErrorList = typing.List[str]


class View:
    """
    A View is an inspection on stored data. It should limit its implementation
    logic to minimum needs to present data to the caller.
    """

    def __init__(self, **raw_data):
        self.raw_data = raw_data
        self._is_valid = False
        self._validated_data: dict = {}
        self.errors: typing.List[str] = []

    @property
    @abc.abstractmethod
    def data(self) -> typing.Union[dict, list]:
        """
        Returns the data do be viewed.
        """
        pass

    def pre_validate(self):
        """
        Pre-validate helps to transform data by providing a step before data validation.
        """
        pass

    def validate(self) -> ErrorList:
        """
        Validates the data in accordance with what fields are defined for the
         view.
        """

        for attr, validator in self.__class__.__dict__.items():
            if not issubclass(validator.__class__, ViewField):
                continue

            data_value = self.raw_data.get(attr)
            if not data_value and validator.optional:
                continue

            try:
                self._validated_data[attr] = validator.validate(data_value)
            except Exception as e:
                self.errors.append(str(e))

        self._is_valid = False if self.errors else True
        return self.errors

    @property
    def is_valid(self) -> bool:
        return self._is_valid

    @property
    def validated_data(self) -> dict:
        return self._validated_data


class ValidationEngine:
    """
    Directs the validations on the view.
    """

    def __init__(self, view: View):
        self._view = view

    def run(self) -> None:
        self._view.pre_validate()
        self._view.validate()


class ViewFactory:
    """
    Creates instances of a view by injecting the parameters into the view
     constructor.
    """

    def build(self, view: typing.Type[View], **raw_data) -> View:
        v = view(**raw_data)
        engine = ValidationEngine(v)
        engine.run()
        if not v.is_valid:
            raise ErrorValidation(*v.errors)
        return v

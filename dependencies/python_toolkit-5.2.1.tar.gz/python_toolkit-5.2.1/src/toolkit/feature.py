from __future__ import annotations

from toolkit.configuration import configuration


class Feature:
    def __init__(self, feature: str):
        self.feature = feature

    def is_enabled(self) -> bool:
        feature_toggles = configuration.settings.feature_toggles
        return feature_toggles[self.feature]

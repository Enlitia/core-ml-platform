import functools
import importlib
import os
import typing


class ErrorSettingsModuleNotFound(Exception):
    pass


class ErrorSettingsHasNoSettingsClass(Exception):
    pass


class ConfigurationError(Exception):
    pass


class ApplicationSettings:
    """
    A settings must be defined using SM_SETTINGS_MODULE environment variable.
    Example:
        SM_SETTINGS_MODULE="testing" , where 'testing.py' is the file
        containing the settings.
    """

    def __init__(self) -> None:
        self._settings_module: str | None = None

    @property
    def current_module(self) -> str:
        if not self._settings_module:
            raise ConfigurationError("configuration module is not defined")

        return self._settings_module

    @functools.cached_property
    def settings(self) -> typing.Any:
        try:
            self._settings_module = os.getenv("SM_SETTINGS_MODULE")
            module = importlib.import_module(f"configs.{self._settings_module}")
        except ModuleNotFoundError:
            raise ErrorSettingsModuleNotFound() from None

        try:
            return module.Settings()  # type: ignore
        except AttributeError:
            raise ErrorSettingsHasNoSettingsClass() from None


configuration: typing.Final = ApplicationSettings()

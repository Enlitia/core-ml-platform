"""Meteorage SFTP client implementation.

This module provides an SFTP client for interacting with Meteorage's
file transfer service.
"""

from __future__ import annotations

from datetime import datetime
from io import BytesIO
from typing import Any

import pandas as pd

from toolkit.sftp_client import SFTPClient


class MeteorageClient(SFTPClient):
    """SFTP client for Meteorage service.

    Extends SFTPClient to provide domain-specific methods for fetching and parsing
    Meteorage lightning data files. Uses standard SFTPConfig for configuration
    to ensure type safety and consistency with other SFTP clients.

    Example:
        config = SFTPConfig(
            host="sftp.meteorage.com",
            username="user",
            password="pass",
            folder_path="/lightning_data"
        )

        client = MeteorageClient(config)
        with client:
            data = client.fetch()
    """

    def _parse_file(self, filename: str) -> pd.DataFrame | None:
        """Parse data file from SFTP.

        Args:
            filename: Name of the file to parse

        Returns:
            Parsed DataFrame with data, or None if file is empty
        """
        with BytesIO() as fl:
            self.get_file_fo(filename, fl)

            fl.seek(0)
            if len(fl.getvalue()) == 0:
                return None

            df = pd.read_csv(
                fl,
                header=None,
                names=["read_at", "longitude", "latitude", "intensity", "check"],
                sep=";",
                parse_dates=["read_at"],
            )

            df["read_at"] = df["read_at"].dt.strftime("%Y-%m-%d %H:%M:%S")

        return df

    def _get_file_list(self) -> list[str]:
        """Get list of files from SFTP server.

        Returns:
            List of filenames, sorted in reverse order
        """

        files = self.list_directory()
        files.remove("processed")
        return sorted(files, reverse=True)

    def _parse_filename_date(self, filename: str) -> datetime | None:
        """Parse date from filename.

        Args:
            filename: Filename to parse

        Returns:
            Parsed datetime or None if invalid format
        """
        try:
            if filename.endswith("-result.txt"):
                file_date_str = filename[:-11]
                return datetime.strptime(file_date_str, "%Y-%m-%d_%H:%M:%S")
        except ValueError:
            print(f"skipping file with invalid date format: {filename}")
        return None

    def _fetch_data_with_dates(self, files: list[str], start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Fetch data within date range.

        Args:
            files: List of filenames
            start_date: Start date for filtering
            end_date: End date for filtering

        Returns:
            Combined DataFrame with all matching data
        """
        df = pd.DataFrame()
        for filename in files:
            file_date = self._parse_filename_date(filename)
            if file_date and start_date <= file_date <= end_date:
                sub_df = self._parse_file(filename)
                if sub_df is not None:
                    df = pd.concat([df, sub_df], ignore_index=True)
        return df

    def fetch(self, start_date: datetime | None = None, end_date: datetime | None = None) -> list[dict[str, Any]]:
        """Fetch data from Meteorage.

        Args:
            start_date: Start date for data filtering (optional)
            end_date: End date for data filtering (optional)

        Returns:
            List of data records
        """
        files = self._get_file_list()

        if start_date and end_date:
            df = self._fetch_data_with_dates(files, start_date, end_date)
        else:
            most_recent_file = files[0]
            df = self._parse_file(most_recent_file)

        if df is None or df.empty:
            return []

        return df.to_dict("records")

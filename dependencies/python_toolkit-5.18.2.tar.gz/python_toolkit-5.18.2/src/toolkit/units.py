"""Unit conversion utilities.

Provides a simple, type-safe system for converting between different units of measurement.
Supports power, current, voltage, temperature, irradiance, and other common units used
in energy systems.

Note on temperature conversions:
    Currently only supports Celsius (°C, C) conversions. Temperature conversions to/from
    Kelvin or Fahrenheit are not supported as they require non-linear transformations
    (offset-based, not just multiplicative factors).

To add a new unit type:
    1. Add a new entry to the UnitType enum
    2. Add conversion factors to UNIT_CONVERSION_FACTORS
    3. Set a default unit in DEFAULT_UNITS

Example:
    >>> from toolkit.units import convert_unit, UnitType
    >>>
    >>> # Convert 5 MW to kW
    >>> convert_unit(5, "MW", "kW")
    5000.0
    >>>
    >>> # Convert with explicit unit type
    >>> convert_unit(100, "A", "kA", unit_type=UnitType.CURRENT)
    0.1
    >>>
    >>> # Convert to default unit for type
    >>> convert_unit(1000, "W")  # Defaults to kW for power
    1.0
"""

from enum import Enum


class UnitType(Enum):
    """Types of measurable quantities."""

    POWER = "power"
    ENERGY = "energy"
    CURRENT = "current"
    VOLTAGE = "voltage"
    TEMPERATURE = "temperature"
    IRRADIANCE = "irradiance"
    VOLUME = "volume"
    PRECIPITATION = "precipitation"
    PRESSURE = "pressure"
    PERCENTAGE = "percentage"
    ANGLE = "angle"
    SPEED = "speed"
    REACTIVE_POWER = "reactive_power"
    ROTATIONAL_SPEED = "rotational_speed"


# Conversion factors relative to base unit (factor = 1)
UNIT_CONVERSION_FACTORS = {
    UnitType.POWER: {
        "W": 1.0,
        "kW": 1e3,
        "MW": 1e6,
        "GW": 1e9,
    },
    UnitType.ENERGY: {
        "Wh": 1.0,
        "kWh": 1e3,
        "MWh": 1e6,
        "GWh": 1e9,
    },
    UnitType.CURRENT: {
        "mA": 1e-3,
        "A": 1.0,
        "kA": 1e3,
    },
    UnitType.VOLTAGE: {
        "mV": 1e-3,
        "V": 1.0,
        "kV": 1e3,
    },
    UnitType.TEMPERATURE: {
        "°C": 1.0,  # Degree Celsius (primary)
        "C": 1.0,  # Plain C (alternative)
    },
    UnitType.IRRADIANCE: {
        "W/m2": 1.0,
        "W/m²": 1.0,  # Alternative symbol
    },
    UnitType.VOLUME: {
        "mL": 1e-3,
        "L": 1.0,
        "l": 1.0,  # Alternative symbol
        "m³": 1e3,
    },
    UnitType.PRECIPITATION: {
        "mm": 1.0,  # Millimeters (1L over 1m² = 1mm)
        "in": 25.4,  # Inches of rain
    },
    UnitType.PRESSURE: {
        "Pa": 1e-2,  # Pascal
        "hPa": 1.0,  # Hectopascal (base)
        "kPa": 10.0,
        "bar": 1e3,
    },
    UnitType.PERCENTAGE: {
        "%": 1.0,
    },
    UnitType.ANGLE: {
        "°": 1.0,  # Degree (primary)
        "deg": 1.0,  # Degree (alternative)
        "rad": 57.29578,  # Radian (180/π)
    },
    UnitType.SPEED: {
        "m/s": 1.0,
        "km/h": 0.277778,  # 1/3.6
        "mph": 0.44704,  # Miles per hour
    },
    UnitType.REACTIVE_POWER: {
        "VAr": 1.0,
        "kVAr": 1e3,
        "kvar": 1e3,
        "kVar": 1e3,  # Alternative spelling
        "MVAr": 1e6,
        "GVAr": 1e9,
    },
    UnitType.ROTATIONAL_SPEED: {
        "rpm": 1.0,  # Revolutions per minute (base)
        "rps": 60.0,  # Revolutions per second
        "rad/s": 9.5493,  # Radians per second
    },
}

# Default target unit for each type when not specified
DEFAULT_UNITS = {
    UnitType.POWER: "kW",
    UnitType.ENERGY: "kWh",
    UnitType.CURRENT: "A",
    UnitType.VOLTAGE: "V",
    UnitType.TEMPERATURE: "°C",
    UnitType.IRRADIANCE: "W/m2",
    UnitType.VOLUME: "L",
    UnitType.PRECIPITATION: "mm",
    UnitType.PRESSURE: "hPa",
    UnitType.PERCENTAGE: "%",
    UnitType.ANGLE: "°",
    UnitType.SPEED: "m/s",
    UnitType.REACTIVE_POWER: "kvar",
    UnitType.ROTATIONAL_SPEED: "rpm",
}


class UnitConversionError(ValueError):
    """Raised when unit conversion fails."""

    pass


def detect_unit_type(unit: str) -> UnitType:
    """Detect the type of a unit string.

    Args:
        unit: Unit string (e.g., "kW", "A", "°C")

    Returns:
        UnitType enum value

    Raises:
        UnitConversionError: If unit type cannot be detected
    """
    for unit_type, units in UNIT_CONVERSION_FACTORS.items():
        if unit in units:
            return unit_type
    raise UnitConversionError(f"Cannot detect type for unit '{unit}'")


def get_conversion_factor(
    source_unit: str,
    target_unit: str | None = None,
    unit_type: UnitType | None = None,
) -> float:
    """Get conversion factor from source unit to target unit.

    Args:
        source_unit: Source unit string (e.g., "MW")
        target_unit: Target unit string (e.g., "kW"). If None, uses default for type
        unit_type: Unit type. If None, auto-detected from source_unit

    Returns:
        Conversion factor (multiply source value by this to get target value)

    Raises:
        UnitConversionError: If units are invalid or not found
    """
    if unit_type is None:
        unit_type = detect_unit_type(source_unit)

    units = UNIT_CONVERSION_FACTORS[unit_type]

    if source_unit not in units:
        raise UnitConversionError(f"Unknown source unit '{source_unit}' for unit type '{unit_type.value}'")

    if target_unit is None:
        target_unit = DEFAULT_UNITS[unit_type]

    if target_unit not in units:
        raise UnitConversionError(f"Unknown target unit '{target_unit}' for unit type '{unit_type.value}'")

    return units[source_unit] / units[target_unit]


def convert_unit(
    value: float,
    source_unit: str,
    target_unit: str | None = None,
    unit_type: UnitType | None = None,
) -> float:
    """Convert a value from one unit to another.

    Args:
        value: Numeric value to convert
        source_unit: Source unit string (e.g., "MW")
        target_unit: Target unit string (e.g., "kW"). If None, uses default for type
        unit_type: Unit type. If None, auto-detected from source_unit

    Returns:
        Converted value

    Raises:
        UnitConversionError: If units are invalid or not found, or if value is not numeric

    Examples:
        >>> convert_unit(5, "MW", "kW")
        5000.0
        >>> convert_unit(100, "A", "kA")
        0.1
        >>> convert_unit(1000, "W")  # Defaults to kW
        1.0
    """
    if not isinstance(value, (int, float)):
        raise UnitConversionError(f"Value must be numeric, got {type(value).__name__}")

    if unit_type is None:
        unit_type = detect_unit_type(source_unit)

    if target_unit is None:
        target_unit = DEFAULT_UNITS[unit_type]

    conversion_factor = get_conversion_factor(source_unit, target_unit, unit_type)
    return value * conversion_factor


def convert_list(
    values: list[float],
    source_unit: str,
    target_unit: str | None = None,
    unit_type: UnitType | None = None,
) -> list[float]:
    """Convert a list of values from one unit to another.

    Args:
        values: List of numeric values to convert
        source_unit: Source unit string (e.g., "MW")
        target_unit: Target unit string (e.g., "kW"). If None, uses default for type
        unit_type: Unit type. If None, auto-detected from source_unit

    Returns:
        List of converted values

    Raises:
        UnitConversionError: If units are invalid or not found

    Examples:
        >>> convert_list([1, 2, 3], "MW", "kW")
        [1000.0, 2000.0, 3000.0]
    """
    conversion_factor = get_conversion_factor(source_unit, target_unit, unit_type)
    return [value * conversion_factor for value in values]


def get_available_units(unit_type: UnitType) -> list[str]:
    """Get list of available units for a given type.

    Args:
        unit_type: UnitType enum value

    Returns:
        List of unit strings available for this type

    Examples:
        >>> get_available_units(UnitType.POWER)
        ['W', 'kW', 'MW', 'GW']
    """
    return list(UNIT_CONVERSION_FACTORS[unit_type].keys())


def get_default_unit(unit_type: UnitType) -> str:
    """Get the default unit for a given type.

    Args:
        unit_type: UnitType enum value

    Returns:
        Default unit string for this type

    Examples:
        >>> get_default_unit(UnitType.POWER)
        'kW'
    """
    return DEFAULT_UNITS[unit_type]

from typing import Dict

from toolkit.database import DataModelBase


class SQLAlchemyDataModel:
    def to_dict(self) -> Dict:
        return {col.name: getattr(self, col.name) for col in self.__table__.columns}  # type: ignore


class SQLDataModel(SQLAlchemyDataModel, DataModelBase):
    __abstract__ = True

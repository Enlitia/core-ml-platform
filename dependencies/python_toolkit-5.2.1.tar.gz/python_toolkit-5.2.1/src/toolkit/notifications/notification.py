from dataclasses import dataclass
from typing import Dict, List, Optional, Union

from toolkit.domain.models import Message
from toolkit.notifications.chat import Chat, ChatConfig
from toolkit.notifications.email import Email, EmailConfig


@dataclass
class NotificationConfig:
    message_config: Message


PROVIDER_EMAIL = "email"
PROVIDER_CHAT = "chat"
PROVIDERS = [PROVIDER_CHAT, PROVIDER_EMAIL]


@dataclass
class Provider:
    name: str
    type: str
    config: dict

    def _validate(self) -> bool:
        return self.type in PROVIDERS


class Notification:
    @staticmethod
    def _get_type_class(provider_type: str):
        if provider_type == PROVIDER_CHAT:
            return Chat, ChatConfig
        if provider_type == PROVIDER_EMAIL:
            return Email, EmailConfig

        return None

    def __init__(self, config: NotificationConfig, providers: List[Provider]):
        self._providers: Dict[str, Union[Chat, Email]] = {}
        self._default_message = config.message_config

        for provider in providers:
            if not provider._validate():
                raise TypeError(f"invalid provider type: {provider.type}")

            cls = self._get_type_class(provider.type)
            self._providers[provider.name] = cls[0](cls[1](**provider.config))

    def send(self, message: Union[Message, str], provider_name: Optional[str] = None) -> dict:
        if isinstance(message, str):
            message = self._default_message.set_message(message)

        if provider_name:
            res = self._providers[provider_name].send(str(message))
            return {provider_name: res}
        else:
            res = {}
            for name, provider in self._providers.items():
                res[name] = provider.send(str(message))
            return res

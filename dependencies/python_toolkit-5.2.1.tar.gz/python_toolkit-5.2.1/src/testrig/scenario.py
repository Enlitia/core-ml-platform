from typing import Optional, Union

from toolkit.calendar import DateTime
from toolkit.data.query import DatabaseSession


class ScenarioBuilder:
    """
    Sets up a scenario on which the tests run, using a Domain Specific Language.

    How to implement new methods?
    1. Methods implemented in this call should use the application services to
     create needed entities. In the lack of a dedicated service it should write
     directly in the database.

    2. Each method should optionally receive all the necessary data by
     argument.

    3. Mandatory data should also be an optional parameter to allow it to be
     overridden when needed.
    """

    def __init__(self, *, session: Optional[DatabaseSession] = None, date_time: Union[DateTime, None] = None):
        """
        session: a database session to be used in the Scenario.
        date_time: a date time to be used in a Scenario.
        """
        self.session: Optional[DatabaseSession] = session

        # Date and Time
        self.current_date: DateTime = DateTime.now()
        if date_time:
            self.current_date = date_time

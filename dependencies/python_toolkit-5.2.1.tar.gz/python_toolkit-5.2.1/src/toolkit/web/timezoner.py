from datetime import datetime
from typing import Optional

import pytz
from pytz import UnknownTimeZoneError

from toolkit.views import ErrorValidation


class Timezoner:
    def __init__(self, timezone: Optional[str] = "UTC"):
        self._timezone = timezone

    @property
    def timezone(self):
        if not self._timezone:
            return "UTC"
        return self._timezone

    def convert(self, date_time: datetime) -> datetime:
        if not self._timezone:
            return date_time

        try:
            return date_time.astimezone(pytz.timezone(self._timezone))
        except UnknownTimeZoneError as e:
            raise ErrorValidation(f"Invalid timezone {str(e)}")


class MixinTimezoner:
    """
    Adds timezone support to a view
    """

    timezoner: Timezoner

    def with_timezone(self, timezone: Timezoner):
        self.timezoner = timezone

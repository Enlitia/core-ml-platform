from dataclasses import dataclass
from json import dumps

from httpx import Client


@dataclass
class ChatConfig:
    endpoint: str


class Chat:
    def __init__(self, config: ChatConfig) -> None:
        self._client = Client(headers={"Content-Type": "application/json; charset=UTF-8"})
        self._endpoint = config.endpoint

    def send(self, message: str):
        try:
            response = self._client.post(url=self._endpoint, content=dumps({"text": message}))
            return response.status_code == 200
        except Exception as e:
            raise ValueError(e) from e

"""REN Market Information REST client.

Provides a client for accessing REN (Redes Energéticas Nacionais) Market Information
REST API for Portuguese electricity market data. This client provides the same interface
as the SOAP RenClient for backward compatibility, allowing drop-in replacement.
"""

from __future__ import annotations

import json
from datetime import datetime
from enum import StrEnum
from typing import Any

import httpx

from toolkit.http_client import APIKeyHTTPClient
from toolkit.logging import Logger

DEFAULT_BASE_URL = "https://mercadoservices.ren.pt"


class RenEndpoint(StrEnum):
    """REN REST API endpoints."""

    MARKET_PRICES = "/api/PrecosMercadoSpot/GetPrecosMercadoSpot"
    IMBALANCES = "/api/ValorizaResolucaoDesvios/GetValorizaResolucaoDesvios"


# Default headers matching the REN API requirements (browser-like headers)
DEFAULT_HEADERS: dict[str, str] = {
    "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Referer": "https://mercado.ren.pt/",
    "Origin": "https://mercado.ren.pt",
    "Connection": "keep-alive",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
}


class RenError(Exception):
    """Base exception for REN REST client errors."""

    pass


class RenAPIError(RenError):
    """Exception raised when REN API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"REN API request failed with status {status_code}"
        super().__init__(self.message)


class RenRequestError(RenError):
    """Exception raised when there's a problem making the request to REN."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class RenClient(APIKeyHTTPClient):
    """REST client for REN Market Information service.

    Provides access to Portuguese electricity market data from REN (Redes Energéticas
    Nacionais), the Portuguese transmission system operator. The client keeps the
    same method signatures as the legacy SOAP client so existing call sites can upgrade
    without changing their imports.

    The client returns the REST payloads as-is, without casting field names or values
    to mimic the SOAP format.

    Example:
        ```python
        from datetime import datetime
        from toolkit.clients.rest.ren import RenClient

        client = RenClient()

        date = datetime(2023, 10, 1)
        data = client.get_market_price(date)
        print("First item keys:", data["items"][0].keys())

        data = client.get_imbalances_price(date)
        print("First imbalance item:", data["items"][0])
        ```
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        headers: dict[str, str] | None = None,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the REN Market Information REST client.

        Args:
            api_key: API key for authentication.
            base_url: Base URL for REN's REST API. Defaults to the official REN endpoint.
            headers: Custom headers to use for requests. Defaults to browser-like headers
                required by the REN API. If provided, these will be merged with the
                default headers (custom headers take precedence).
            logger: Optional logger for debugging and monitoring requests/responses.
            **kwargs: Additional arguments passed to the underlying HTTP client.
        """
        # Merge default headers with custom headers (custom takes precedence)
        merged_headers = dict(DEFAULT_HEADERS)
        if headers:
            merged_headers.update(headers)
        kwargs["headers"] = merged_headers

        super().__init__(base_url, api_key, logger=logger, **kwargs)

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to REN-specific exceptions.

        Args:
            exc: The HTTP status error from httpx

        Returns:
            RenAPIError with status code and URL information
        """
        return RenAPIError(exc.response.status_code, str(exc.request.url))

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to REN-specific exceptions.

        Args:
            exc: The request error from httpx

        Returns:
            RenRequestError with original exception details
        """
        return RenRequestError(str(exc), exc)

    def _fetch_raw_data(self, endpoint: str, date: datetime, language: str = "PT") -> list[dict[str, Any]]:
        """Fetch raw data from REN API for a specific date.

        The REN API returns a JSON string inside a JSON string, so we need to
        parse it twice.

        Args:
            endpoint: API endpoint path
            date: Date to fetch data for
            language: Language for the response (default: PT)

        Returns:
            List of dictionaries with the raw API response data
        """
        params = {
            "language": language,
            "dayQuery": date.day,
            "monthQuery": date.month,
            "yearQuery": date.year,
        }

        self.logger.debug("fetching data", endpoint=endpoint, date=date.strftime("%Y-%m-%d"))

        response = self.get(endpoint, params=params)

        # REN API returns a string with a JSON object inside
        if isinstance(response, str):
            response = json.loads(response)

        return response if isinstance(response, list) else []

    def _fetch_data(self, date: datetime, endpoint: RenEndpoint) -> dict[str, Any]:
        """Fetch data for a specific date.

        Generic method to fetch data from an endpoint for a single date.

        Args:
            date: Date to fetch data for
            endpoint: API endpoint to hit

        Returns:
            Dictionary with 'items' key containing all fetched data

        Raises:
            RenAPIError: If the REN service returns an error
            RenRequestError: If there are network/transport issues
        """
        data_label = endpoint.name
        date_str = date.strftime("%Y-%m-%d")

        try:
            raw_data = self._fetch_raw_data(endpoint, date)
        except RenError:
            raise
        except Exception as e:
            raise RenRequestError(f"Failed to process {data_label} data for {date_str}", e) from e

        return {"items": raw_data}

    def get_market_price(self, date: datetime) -> dict[str, Any]:
        """Get market price data for a specific date.

        Retrieves Portuguese electricity market pricing data from REN for the
        specified date. Each day contains hourly periods with pricing
        information for different market sessions.

        Args:
            date: Date to fetch data for (datetime object)

        Returns:
            Dictionary containing the raw market price items returned by REN's REST
            API. Each item holds Portuguese field names such as 'sessao',
            'hora', 'data_utc', and 'preco_pt'. The structure is returned as-is,
            without transforming casing or fields.

        Raises:
            RenAPIError: If the REN service returns an error
            RenRequestError: If there are network/transport issues
        """
        return self._fetch_data(date=date, endpoint=RenEndpoint.MARKET_PRICES)

    def get_imbalances_price(self, date: datetime) -> dict[str, Any]:
        """Get imbalance price data for a specific date.

        Retrieves Portuguese electricity market imbalance pricing data from REN for the
        specified date. Imbalance prices are used to settle deviations between
        scheduled and actual electricity consumption/production.

        Args:
            date: Date to fetch data for (datetime object)

        Returns:
            Dictionary containing the raw imbalance price items returned by REN's
            REST API. Each item uses Portuguese field names such as 'hora',
            'desvioExc', and 'desvioDef'. The structure is returned as provided by
            the API, without a SOAP-style transformation.

        Raises:
            RenAPIError: If the REN service returns an error
            RenRequestError: If there are network/transport issues

        Note:
            Starting from 2025-04-01, data is returned with 15-minute intervals.
            Before that date, hourly intervals are used.
        """
        return self._fetch_data(date=date, endpoint=RenEndpoint.IMBALANCES)

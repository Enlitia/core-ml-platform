"""Base file transfer client implementations with unified interface.

Provides BaseFileTransferClient (abstract), common exceptions, configuration, and utilities
for both FTP and SFTP implementations.
"""

from abc import ABC, abstractmethod
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any

from toolkit.logging import Logger, get_logger


def require_connection(func):
    """Decorator to ensure connection exists before method execution.

    Args:
        func: Method to decorate

    Returns:
        Decorated function that validates connection first

    Raises:
        FileTransferOperationError: If not connected to server
    """

    def wrapper(self, *args: Any, **kwargs: Any):
        if not self.is_connected():
            raise FileTransferOperationError("Not connected to server")
        return func(self, *args, **kwargs)

    return wrapper


class FileTransferClientError(Exception):
    """Base exception for file transfer client errors.

    All file transfer related exceptions inherit from this base class
    to allow for comprehensive error handling.
    """

    pass


class FileTransferConnectionError(FileTransferClientError):
    """Exception for file transfer connection failures."""

    def __init__(self, message: str, original_exception: Exception | None = None):
        self.original_exception = original_exception
        super().__init__(message)


class FileTransferAuthenticationError(FileTransferClientError):
    """Exception for file transfer authentication failures."""

    def __init__(self, message: str, original_exception: Exception | None = None):
        self.original_exception = original_exception
        super().__init__(message)


class FileTransferOperationError(FileTransferClientError):
    """Exception for file transfer operation failures."""

    def __init__(self, message: str, original_exception: Exception | None = None):
        self.original_exception = original_exception
        super().__init__(message)


@dataclass
class FileTransferConfig:
    """Base configuration for file transfer connections."""

    host: str
    port: int
    username: str = ""
    password: str = ""
    timeout: int = 30
    folder_path: str | None = None

    def _resolve_path(self, path: str) -> str:
        """Resolve relative path against folder_path if configured."""
        if self.folder_path and not path.startswith("/"):
            root = self.folder_path.rstrip("/")
            return f"{root}/{path}"
        return path


class BaseFileTransferClient(ABC):
    """Abstract base class for file transfer clients.

    Provides common functionality and defines abstract contracts for
    protocol-specific implementations (FTP, SFTP, etc.).

    Abstract methods that subclasses must implement:
        - connection property: Type-safe access to protocol connection
        - connect(), disconnect(): Connection management
        - All file operation methods: Protocol-specific implementations
    """

    def __init__(self, config: FileTransferConfig, logger: Logger | None = None):
        """Initialize the file transfer client.

        Args:
            config: File transfer configuration parameters
            logger: Optional logger instance for structured logging
        """
        self.config = config
        self._logger = logger or get_logger(__name__)
        self._connection: Any = None

    @property
    @abstractmethod
    def connection(self) -> Any:
        """Get the protocol-specific connection object."""
        pass

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()

    def is_connected(self) -> bool:
        """Check if client is connected to the server."""
        return self._connection is not None

    def _resolve_path(self, path: str) -> str:
        """Resolve relative path against folder_path if configured."""
        return self.config._resolve_path(path)

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to the server.

        This method must be implemented by subclasses to handle
        protocol-specific connection logic.

        Raises:
            FileTransferConnectionError: If connection fails
            FileTransferAuthenticationError: If authentication fails
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close the connection to the server.

        This method must be implemented by subclasses to handle
        protocol-specific disconnection logic.
        """
        pass

    @abstractmethod
    @require_connection
    def list_directory(self, path: str = "/") -> list[str]:
        """List files and directories in the specified path."""
        pass

    @abstractmethod
    @require_connection
    def download_file(self, remote_path: str, local_path: str) -> None:
        """Download a file from the remote server."""
        pass

    @abstractmethod
    @require_connection
    def upload_file(self, local_path: str, remote_path: str) -> None:
        """Upload a file to the remote server."""
        pass

    @abstractmethod
    @require_connection
    def delete_file(self, remote_path: str) -> None:
        """Delete a file on the remote server."""
        pass

    @abstractmethod
    @require_connection
    def create_directory(self, remote_path: str) -> None:
        """Create a directory on the remote server."""
        pass

    @abstractmethod
    @require_connection
    def remove_directory(self, remote_path: str) -> None:
        """Remove a directory on the remote server."""
        pass

    @abstractmethod
    @require_connection
    def file_exists(self, remote_path: str) -> bool:
        """Check if a file exists on the remote server."""
        pass

    @abstractmethod
    @require_connection
    def get_file_size(self, remote_path: str) -> int:
        """Get the size of a file on the remote server."""
        pass

    @abstractmethod
    @require_connection
    @contextmanager
    def change_directory(self, remote_path: str) -> Generator[None, None, None]:
        """Context manager to temporarily change to a different directory.

        Changes to the specified directory and automatically returns to the
        original directory when exiting the context.

        Args:
            remote_path: Path to the directory to change to

        Yields:
            None (for use in with statements)

        Raises:
            FileTransferOperationError: If directory change fails

        Example:
            with client.change_directory("/tmp"):
                # Operations here are performed in /tmp
                client.upload_file("local.txt", "remote.txt")
            # Automatically returns to original directory
        """
        pass

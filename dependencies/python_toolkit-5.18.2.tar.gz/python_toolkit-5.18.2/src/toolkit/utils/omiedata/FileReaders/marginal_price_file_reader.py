import datetime as dt
import re

import numpy as np
import pandas as pd
from babel.numbers import parse_decimal
from requests import Response  # type: ignore[import-untyped]

from toolkit.utils.omiedata.Enums.all_enums import DataTypeInMarginalPriceFile
from toolkit.utils.omiedata.FileReaders.omie_file_reader import OMIEFileReader


class MarginalPriceFileReader(OMIEFileReader):
    # Static or class variables
    __dic_static_concepts__ = {
        "Precio marginal (Cent/kWh)": [DataTypeInMarginalPriceFile.PRICE_SPAIN, 10.0],
        "Precio marginal (EUR/MWh)": [DataTypeInMarginalPriceFile.PRICE_SPAIN, 1.0],
        "Precio marginal en el sistema español (Cent/kWh)": [DataTypeInMarginalPriceFile.PRICE_SPAIN, 10.0],
        "Precio marginal en el sistema español (EUR/MWh)": [DataTypeInMarginalPriceFile.PRICE_SPAIN, 1.0],
        "Precio marginal en el sistema portugués (Cent/kWh)": [DataTypeInMarginalPriceFile.PRICE_PORTUGAL, 10.0],
        "Precio marginal en el sistema portugués (EUR/MWh)": [DataTypeInMarginalPriceFile.PRICE_PORTUGAL, 1.0],
        "Demanda+bombeos (MWh)": [DataTypeInMarginalPriceFile.ENERGY_IBERIAN, 1.0],
        "Energía en el programa resultante de la casación (MWh)": [DataTypeInMarginalPriceFile.ENERGY_IBERIAN, 1.0],
        "Energía total del mercado Ibérico (MWh)": [DataTypeInMarginalPriceFile.ENERGY_IBERIAN, 1.0],
        "Energía total con bilaterales del mercado Ibérico (MWh)": [
            DataTypeInMarginalPriceFile.ENERGY_IBERIAN_WITH_BILLATERAL,
            1.0,
        ],
    }

    # IDA format (since June 14, 2024): header maps to concept
    __ida_header_concepts__ = {
        "MARGINALPIBC": DataTypeInMarginalPriceFile.PRICE_SPAIN,
        "MARGINALPIBCPT": DataTypeInMarginalPriceFile.PRICE_PORTUGAL,
    }

    __key_list_retrieve__ = ["DATE", "CONCEPT"] + [f"H{i}" for i in range(1, 97)]

    __dateFormatInFile__ = "%d/%m/%Y"
    __localeInFile__ = "en_DK.UTF-8"

    def __init__(self, types=None):
        self.conceptsToLoad = types if types else list(DataTypeInMarginalPriceFile)

    def get_keys(self) -> list:
        return MarginalPriceFileReader.__key_list_retrieve__

    def _is_ida_format(self, first_line: str) -> bool:
        """Detect whether the text uses the new IDA row-per-period format."""
        header = first_line.strip().rstrip(";").strip()
        return header in self.__ida_header_concepts__

    def _parse_ida_text(self, text: str, source: str = "") -> pd.DataFrame:
        """Parse the IDA format: header line + one row per period (YYYY;MM;DD;period;price;matched_price;)."""
        lines = [line.strip() for line in text.strip().split("\n") if line.strip() and line.strip() != "*"]
        if not lines:
            return pd.DataFrame(columns=self.get_keys())

        header = lines.pop(0).rstrip(";").strip()
        concept = self.__ida_header_concepts__.get(header)
        if concept is None or concept not in self.conceptsToLoad:
            return pd.DataFrame(columns=self.get_keys())

        result = dict.fromkeys(self.get_keys())
        result["CONCEPT"] = str(concept)
        date_set = False

        for line in lines:
            parts = line.rstrip(";").split(";")
            if len(parts) < 5:
                continue
            try:
                year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
                period = int(parts[3])
                price = float(parts[4])
            except (ValueError, IndexError):
                continue

            if not date_set:
                result["DATE"] = dt.date(year, month, day)
                date_set = True

            if 1 <= period <= 96:
                result[f"H{period}"] = price

        if not date_set:
            return pd.DataFrame(columns=self.get_keys())

        return pd.DataFrame([result])

    def get_data_from_response(self, response: Response) -> pd.DataFrame:
        res = pd.DataFrame(columns=self.get_keys())

        lines = response.text.replace("\r", "").split("\n")
        first_line = lines[0] if lines else ""

        # Detect new IDA format (since June 14, 2024)
        if self._is_ida_format(first_line):
            return self._parse_ida_text(response.text, source=response.url)

        # Legacy format: first line contains two dates
        matches = re.findall(r"\d\d/\d\d/\d\d\d\d", lines.pop(0))
        if len(matches) != 2:
            print("Response " + response.url + " does not have the expected format.")
        else:
            # The second date is the one we want
            date = dt.datetime.strptime(matches[1], MarginalPriceFileReader.__dateFormatInFile__).date()

            # Process all the lines

            while lines:
                # read following line
                line = lines.pop(0)
                splits = line.split(sep=";")
                first_col = splits[0]

                if first_col in MarginalPriceFileReader.__dic_static_concepts__:
                    concept_type: DataTypeInMarginalPriceFile = MarginalPriceFileReader.__dic_static_concepts__[
                        first_col
                    ][0]  # type: ignore[assignment]

                    if concept_type in self.conceptsToLoad:
                        units = MarginalPriceFileReader.__dic_static_concepts__[first_col][1]

                        dico = self._process_line(date=date, concept=concept_type, values=splits[1:], multiplier=units)
                        res = pd.concat([res, pd.DataFrame([dico])], ignore_index=True)

            return res

    def get_data_from_file(self, filename: str) -> pd.DataFrame:
        # Method yield each dictionary one by one
        res = pd.DataFrame(columns=self.get_keys())
        file = open(filename, encoding="latin-1")

        # from first line we get the units and the price date. We just look at the date
        line = file.readline()

        # Detect new IDA format (since June 14, 2024)
        if self._is_ida_format(line):
            remaining = line + file.read()
            file.close()
            return self._parse_ida_text(remaining, source=filename)

        matches = re.findall(r"\d\d/\d\d/\d\d\d\d", line)
        if len(matches) != 2:
            print("File " + filename + " does not have the expected format.")
        else:
            # The second date is the one we want
            date = dt.datetime.strptime(matches[1], MarginalPriceFileReader.__dateFormatInFile__).date()

            # Process all the lines
            while line:
                # read following line
                line = file.readline()
                splits = line.split(sep=";")
                first_col = splits[0]

                if first_col in MarginalPriceFileReader.__dic_static_concepts__:
                    concept_type: DataTypeInMarginalPriceFile = MarginalPriceFileReader.__dic_static_concepts__[
                        first_col
                    ][0]  # type: ignore[assignment]

                    if concept_type in self.conceptsToLoad:
                        units = MarginalPriceFileReader.__dic_static_concepts__[first_col][1]
                        dico = self._process_line(date=date, concept=concept_type, values=splits[1:], multiplier=units)
                        res = pd.concat([res, pd.DataFrame([dico])], ignore_index=True)

            return res

    def _process_line(self, date: dt.date, concept: DataTypeInMarginalPriceFile, values: list, multiplier=1.0) -> dict:
        key_list = MarginalPriceFileReader.__key_list_retrieve__

        result = dict.fromkeys(self.get_keys())
        result[key_list[0]] = date
        result[key_list[1]] = str(concept)

        for i, v in enumerate(values, start=1):
            if i > 100:
                break  # Jump if extra values or spaces (handle up to 100 intervals for DST)
            if not v.strip():
                continue
            try:
                f = multiplier * float(parse_decimal(v.strip(), locale=self.__localeInFile__))
            except Exception:
                # Handle DST changes with 15-minute intervals:
                # - Normal day: 96 intervals (24 hours * 4)
                # - 23-hour day (spring forward): 92 intervals
                # - 25-hour day (fall back): 100 intervals
                if i == 92:
                    # Day with 23-hours, fill missing intervals with NaN
                    for j in range(93, 97):
                        result[key_list[j + 1]] = np.nan
                elif i > 96:
                    # Extra intervals beyond normal day - skip
                    pass
                else:
                    raise
            else:
                if i <= 96:
                    result[key_list[i + 1]] = f

        return result

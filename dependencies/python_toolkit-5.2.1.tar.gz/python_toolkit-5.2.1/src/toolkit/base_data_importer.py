import abc
import traceback
from enum import Enum
from typing import Any, List

from toolkit.application.services import ApplicationService


class DataImportStep(str, Enum):
    """Enum representing the steps in a data import process."""

    FETCHING = "FETCHING"
    PROCESSING = "PROCESSING"
    STORING = "STORING"


class BaseDataImporter(ApplicationService, abc.ABC):
    """
    Abstract base class for all data importers.
    Provides common functionality and structured logging for data import processes.
    """

    def __init__(
        self,
        logger,
        *args,
        **kwargs,
    ):
        """
        Initialize the base data importer.

        Args:
            logger: Pre-configured logger (should be a StructuredLogger instance)
        """
        super().__init__(*args, **kwargs)
        self._logger = logger

    @abc.abstractmethod
    def _fetch_data(self) -> List[Any]:
        """
        Fetch data from the data source.
        This method should be implemented by subclasses.

        Returns:
            The fetched data
        """
        pass

    @abc.abstractmethod
    def _process_data(self, raw_data: List[Any]) -> List[Any]:
        """
        Process the raw data into a format suitable for storage.
        This method should be implemented by subclasses.

        Args:
            raw_data: The raw data from the data source

        Returns:
            The processed data
        """
        pass

    @abc.abstractmethod
    def _store_data(self, processed_data: List[Any]) -> None:
        """
        Store the processed data.
        This method should be implemented by subclasses.

        Args:
            processed_data: The processed data to store
        """
        pass

    def execute(self) -> None:  # type: ignore[override]
        """
        Execute the data import process.
        This is the main entry point for the data import.
        """
        self._logger.info("Starting data import process")

        try:
            self._logger.info("Fetching data from source", extra={"step": DataImportStep.FETCHING.value})
            raw_data = self._fetch_data()

            if not raw_data:
                self._logger.warning("No data returned from fetch", extra={"step": DataImportStep.FETCHING.value})
                return

            self._logger.info("Processing fetched data", extra={"step": DataImportStep.PROCESSING.value})
            processed_data = self._process_data(raw_data)

            if not processed_data:
                self._logger.warning(
                    "No data points to add after processing", extra={"step": DataImportStep.PROCESSING.value}
                )
                return

            self._logger.info("Storing processed data", extra={"step": DataImportStep.STORING.value})
            self._store_data(processed_data)

        except Exception as e:
            self._logger.error(f"Error during data import process: {str(e)}\n{traceback.format_exc()}")
            raise  # Re-raise the exception after logging

        self._logger.info("Data import process finished")

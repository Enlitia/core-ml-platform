# toolkit/logging.py
from __future__ import annotations

import json
import logging
import os
import sys
from collections import OrderedDict
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

import structlog

#: Public type alias so consumers don't couple to structlog internals.
Logger = structlog.stdlib.BoundLogger

__all__ = [
    "DataExportLabels",
    "DataImportLabels",
    "DatabaseLabels",
    "FileTransferLabels",
    "HTTPClientLabels",
    "Logger",
    "LoggingLabels",
    "SOAPClientLabels",
    "bind",
    "configure_logging",
    "context",
    "get_logger",
    "unbind",
]


class LoggingLabels(StrEnum):
    """Base enum for structured log action labels.

    Provides the common lifecycle outcomes shared by all label enums.
    Labels follow the pattern ``{member}.{outcome}`` and are passed as the
    ``action`` kwarg in structured log calls, making them filterable in log
    aggregators (e.g. Loki: ``{action=~"fetch.*"}``).

    Labels::

        *.started      - Process begun
        *.completed    - Process finished successfully
        *.failed       - Process ended with an error
        *.no_data      - Process returned empty result

    Subclass and add domain-specific members / outcomes::

        class MyLabels(LoggingLabels):
            SYNC = "sync"


        logger.info("Started", action=MyLabels.SYNC.started)
    """

    @property
    def started(self) -> str:
        return f"{self.value}.started"

    @property
    def completed(self) -> str:
        return f"{self.value}.completed"

    @property
    def failed(self) -> str:
        return f"{self.value}.failed"

    @property
    def no_data(self) -> str:
        return f"{self.value}.no_data"


class DataImportLabels(LoggingLabels):
    """Log labels for data import processes.

    Labels::

        execute.started    - Import execution begun
        execute.completed  - Import execution finished
        execute.failed     - Import execution error
        fetch.started      - Fetching data from source
        fetch.completed    - Fetch finished
        fetch.no_data      - Fetch returned empty result
        process.started    - Processing raw data
        process.completed  - Processing finished
        process.no_data    - Processing produced empty result
        store.started      - Storing processed data
        store.completed    - Store finished
    """

    EXECUTE = "execute"
    FETCH = "fetch"
    PROCESS = "process"
    STORE = "store"


class DataExportLabels(LoggingLabels):
    """Log labels for data export processes.

    Labels::

        execute.started    - Export execution begun
        execute.completed  - Export execution finished
        execute.failed     - Export execution error
        load.started       - Loading data from storage
        load.completed     - Load finished
        load.no_data       - Load returned empty result
        process.started    - Processing data for export
        process.completed  - Processing finished
        process.no_data    - Processing produced empty result
        export.started     - Exporting processed data
        export.completed   - Export finished
    """

    EXECUTE = "execute"
    LOAD = "load"
    PROCESS = "process"
    EXPORT = "export"


class DatabaseLabels(LoggingLabels):
    """Log labels for database operations.

    Labels::

        connect.started    - Connection attempt begun
        connect.completed  - Connection established
        connect.failed     - All connection attempts exhausted
        connect.retry      - Connection failed, retrying
    """

    CONNECT = "connect"

    @property
    def retry(self) -> str:
        return f"{self.value}.retry"


class FileTransferLabels(LoggingLabels):
    """Log labels for file transfer operations (FTP/SFTP).

    Labels::

        connect.started      - Connection attempt begun
        connect.completed    - Connection established
        connect.failed       - Connection error
        disconnect.started   - Disconnection begun
        disconnect.completed - Disconnected
        disconnect.failed    - Disconnect error
        download.completed   - File downloaded
        upload.completed     - File uploaded
        delete.completed     - File deleted
        mkdir.completed      - Directory created
        rmdir.completed      - Directory removed
        archive.completed    - File archived
        archive.failed       - Archive error
    """

    CONNECT = "connect"
    DISCONNECT = "disconnect"
    DOWNLOAD = "download"
    UPLOAD = "upload"
    DELETE = "delete"
    MKDIR = "mkdir"
    RMDIR = "rmdir"
    ARCHIVE = "archive"


class HTTPClientLabels(LoggingLabels):
    """Log labels for HTTP client operations.

    Labels::

        auth.started     - Authentication attempt
        auth.completed   - API token acquired
        auth.failed      - Authentication error
        api.started      - Outbound HTTP call
        api.completed    - Successful response
        api.failed       - HTTP / request error
        api.retry        - Retryable error, backing off
    """

    AUTH = "auth"
    API = "api"

    @property
    def retry(self) -> str:
        return f"{self.value}.retry"


class SOAPClientLabels(LoggingLabels):
    """Log labels for SOAP client operations.

    Labels::

        auth.started     - Authentication attempt (login)
        auth.completed   - Session token acquired
        auth.failed      - Authentication error
        api.started      - Outbound SOAP call
        api.completed    - Successful response
        api.failed       - SOAP application / transport error
    """

    AUTH = "auth"
    API = "api"


_CONFIGURED = False


def configure_logging(
    *,
    project: str,
    service: str,
    config: dict,
    force_reconfigure: bool = False,
    **extra: Any,
) -> None:
    """
    Configure structured logging for the application. Call once at startup.

    - Configures stdlib logging + structlog (once by default)
    - Binds base context (project/service) and any extra fields (e.g. data_source)

    Expected config shape::

      {
          "level": logging.DEBUG | "DEBUG",
          "format_type": "json" | "splunk" | "console",
          "quiet_libs": ["urllib3", "asyncio", "botocore"],  # optional
      }

    format_type options:
      - "json": Standard JSON with ISO timestamps
      - "splunk": Splunk-compatible JSON (date field first, custom timestamp format)
      - "console": Human-readable colored console output
    """
    global _CONFIGURED
    if force_reconfigure or not _CONFIGURED:
        if force_reconfigure:
            structlog.reset_defaults()
        _configure_logging(config)
        _CONFIGURED = True

    structlog.contextvars.unbind_contextvars("project", "service", *extra.keys())
    structlog.contextvars.bind_contextvars(project=project, service=service, **extra)


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """
    Obtain a structlog logger. Use in any module after configure_logging().

    Usage::

      log = get_logger(__name__)
      log.info("hello", key="value")
    """
    return structlog.get_logger(name) if name else structlog.get_logger()


def bind(**fields: Any) -> None:
    """Bind context fields for current execution context."""
    structlog.contextvars.bind_contextvars(**fields)


def unbind(*keys: str) -> None:
    """Remove context fields from current execution context."""
    structlog.contextvars.unbind_contextvars(*keys)


@contextmanager
def context(**fields: Any) -> Iterator[None]:
    """
    Temporarily bind context fields. Restores previous values on exit,
    even when nested or if an exception occurs.
    """
    current = structlog.contextvars.get_contextvars()
    previous = {k: current[k] for k in fields if k in current}
    new_keys = [k for k in fields if k not in current]

    structlog.contextvars.bind_contextvars(**fields)
    try:
        yield
    finally:
        structlog.contextvars.unbind_contextvars(*new_keys)
        if previous:
            structlog.contextvars.bind_contextvars(**previous)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _splunk_timestamp(_logger, _method_name, event_dict):
    """
    Add Splunk-compatible timestamp as 'date' field.
    Format: "2026-05-20 12:58:34.789 +0100"

    Runs inside ProcessorFormatter where _record is always available,
    ensuring accurate timestamps from the stdlib LogRecord for both
    structlog-originated and foreign (stdlib) log events.
    """
    record = event_dict["_record"]
    dt = datetime.fromtimestamp(record.created, tz=UTC).astimezone()

    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S.%%03d %z") % (dt.microsecond // 1000)
    event_dict["date"] = timestamp
    return event_dict


def _ordered_json_renderer(_logger, _name, event_dict):
    """Render JSON with 'date' as first field (Splunk requirement)."""
    ed = dict(event_dict)
    ordered = OrderedDict()
    if "date" in ed:
        ordered["date"] = ed.pop("date")
    ordered.update(ed)
    return json.dumps(ordered, default=str, ensure_ascii=False)


# Fields that always appear first, in this exact order.
_HEAD_FIELDS = ("data_source", "action", "step")

# Fields that always appear last, in this exact order.
_TAIL_FIELDS = ("event", "project", "service", "logger", "level", "timestamp", "date")


def _order_fields(_logger, _name, event_dict):
    """Reorder event_dict so fields appear in a consistent order.

    Order: data_source → action → step → per-call kwargs → event
    → project → service → logger → level → timestamp.
    """
    ordered = OrderedDict()
    head_set = set(_HEAD_FIELDS)
    tail_set = set(_TAIL_FIELDS)

    # 1. Head fields in fixed order
    for k in _HEAD_FIELDS:
        if k in event_dict:
            ordered[k] = event_dict[k]

    # 2. Everything else (preserving original order)
    for k, v in event_dict.items():
        if k in head_set or k in tail_set:
            continue
        ordered[k] = v

    # 3. Tail fields in fixed order
    for k in _TAIL_FIELDS:
        if k in event_dict:
            ordered[k] = event_dict[k]

    event_dict.clear()
    event_dict.update(ordered)
    return event_dict


def _normalize_level(level: Any) -> int:
    if isinstance(level, int):
        return level
    if isinstance(level, str):
        return logging.getLevelNamesMapping().get(level.upper(), logging.INFO)
    return logging.INFO


def _console_level_styles() -> dict[str, str]:
    """
    Foreground ANSI sequences for log level tags in console format.
    Matches structlog/dev.py fallbacks when colorama is not used.
    """
    green = "\033[32m"
    red = "\033[31m"
    yellow = "\033[33m"
    cyan = "\033[36m"
    styles = structlog.dev.ConsoleRenderer.get_default_level_styles(colors=True)
    styles["debug"] = cyan
    styles["info"] = green
    styles["warn"] = yellow
    styles["warning"] = yellow
    styles["critical"] = red
    styles["error"] = red
    styles["exception"] = red
    return styles


class _LevelFilter(logging.Filter):
    """Filter logs by level range (min_level <= level < max_level)."""

    def __init__(self, min_level: int, max_level: int):
        super().__init__()
        self.min_level = min_level
        self.max_level = max_level

    def filter(self, record: logging.LogRecord) -> bool:
        return self.min_level <= record.levelno < self.max_level


def _configure_logging(config: dict) -> None:
    env_level = os.getenv("LOG_LEVEL")
    level = _normalize_level(env_level or config.get("level", logging.INFO))
    fmt_type = str(config.get("format_type", "json")).lower()

    # Root stdlib logger
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)

    # Shared processors (DRY)
    base_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.processors.add_log_level,
    ]
    tail_processors: list[Any] = [
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if fmt_type == "splunk":
        shared_processors = [*base_processors, *tail_processors]
        formatter_processors = [
            _splunk_timestamp,
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            _order_fields,
            _ordered_json_renderer,
        ]
    elif fmt_type == "json":
        shared_processors = [
            *base_processors,
            structlog.processors.TimeStamper(fmt="iso"),
            *tail_processors,
        ]
        formatter_processors = [
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            _order_fields,
            structlog.processors.JSONRenderer(),
        ]
    else:
        shared_processors = [
            *base_processors,
            structlog.processors.TimeStamper(fmt="iso"),
            *tail_processors,
        ]
        formatter_processors = [
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.dev.ConsoleRenderer(level_styles=_console_level_styles()),
        ]

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=formatter_processors,
        foreign_pre_chain=shared_processors,
    )

    # stdout: DEBUG and INFO
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.DEBUG)
    stdout_handler.addFilter(_LevelFilter(logging.DEBUG, logging.WARNING))
    stdout_handler.setFormatter(formatter)
    root.addHandler(stdout_handler)

    # stderr: WARNING, ERROR, CRITICAL
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(logging.WARNING)
    stderr_handler.setFormatter(formatter)
    root.addHandler(stderr_handler)

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=False,
    )

    # Quiet noisy third-party libs (configurable)
    quiet_libs = config.get("quiet_libs", ["urllib3", "asyncio", "botocore", "paramiko"])
    for lib in quiet_libs:
        logging.getLogger(lib).setLevel(logging.WARNING)


# ---------------------------------------------------------------------------
# Backward compatibility re-exports
# ---------------------------------------------------------------------------


def __getattr__(name: str):
    """Lazy import of deprecated compat classes to avoid circular imports."""
    _compat_names = {"StructuredLogger", "JsonFormatter", "TextFormatter"}
    if name in _compat_names:
        from toolkit import logging_compat

        return getattr(logging_compat, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

"""OMIP SFTP client implementation.

This module provides an SFTP client for interacting with OMIP's
futures market data file transfer service.
"""

from __future__ import annotations

from datetime import date
from io import BytesIO
from typing import Any

import numpy as np
import pandas as pd

from toolkit.sftp_client import SFTPClient


class OMIPClient(SFTPClient):
    """SFTP client for OMIP futures market data service.

    Extends SFTPClient to provide domain-specific methods for fetching and parsing
    OMIP futures market data files. Uses standard SFTPConfig for configuration
    to ensure type safety and consistency with other SFTP clients.

    The client fetches CSV files in the format "FuturesMarketData_YYYYMMDD.csv"
    from the FuturesMarketData folder on ftp.omip.pt.

    Example:
        config = SFTPConfig(
            host="ftp.omip.pt",
            port=8022,
            username="user",
            password="pass",
            folder_path="FuturesMarketData"
        )

        client = OMIPClient(config)
        with client:
            # Get today's data
            data = client.fetch()

            # Get specific date
            from datetime import date
            data = client.fetch(date(2025, 11, 5))
    """

    def _parse_futures_file(self, filename: str) -> pd.DataFrame | None:
        """Parse futures market data file from SFTP.

        Args:
            filename: Name of the CSV file to parse

        Returns:
            Parsed DataFrame with futures market data, or None if file is empty or too small
        """
        with BytesIO() as fl:
            self.get_file_fo(filename, fl)

            fl.seek(0)

            df = pd.read_csv(
                fl,
                sep=";",
                quotechar='"',
            )

        return df

    def _check_file_exists(self, filename: str) -> bool:
        """Check if a file exists on the SFTP server.

        Args:
            filename: Name of the file to check

        Returns:
            True if file exists, False otherwise
        """
        try:
            files = self.list_directory()
            return filename in files
        except Exception:
            return False

    def fetch(self, target_date: date | None = None) -> list[dict[str, Any]] | None:
        """Fetch futures market data from OMIP for a specific date.

        Mimics the behavior of the bash script by:
        1. Generating the expected filename for the target date
        2. Checking if the file exists
        3. Downloading and parsing the file if it's large enough (> 10KB)

        Args:
            target_date: Date to fetch data for. Defaults to today if None.

        Returns:
            List of market data records, or None if file doesn't exist or is too small

        Raises:
            Exception: If file download or parsing fails
        """
        if target_date is None:
            target_date = date.today()

        filename = f"FuturesMarketData_{target_date.strftime('%Y%m%d')}.csv"

        # Check if file exists (like the bash script does)
        if not self._check_file_exists(filename):
            print(f"File does not exist: {filename}")
            return None

        # Parse the file (includes size check like bash script)
        df = self._parse_futures_file(filename)

        if df is None or df.empty:
            return None

        # Convert all NaN values to None
        df = df.replace({np.nan: None})

        return df.to_dict("records")

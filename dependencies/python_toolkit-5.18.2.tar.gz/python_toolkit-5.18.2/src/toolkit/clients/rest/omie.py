"""OMIE API client for electricity market data.

Provides access to OMIE (Operador del Mercado Ibérico de Energía) electricity
market data including marginal prices for Spain and Portugal markets.
"""

from dataclasses import dataclass
from datetime import date
from enum import StrEnum

import pandas as pd

from toolkit.logging import Logger, get_logger
from toolkit.utils.omiedata.DataImport.omie_data_importer_from_responses import (
    OMIEDataImporterFromResponses,
)
from toolkit.utils.omiedata.DataImport.omie_marginalprice_importer import (
    OMIEMarginalPriceFileImporter,
)
from toolkit.utils.omiedata.Downloaders.intra_day_price_downloader import (
    IntraDayPriceDownloader,
)
from toolkit.utils.omiedata.Enums.all_enums import DataTypeInMarginalPriceFile
from toolkit.utils.omiedata.FileReaders.marginal_price_file_reader import (
    MarginalPriceFileReader,
)


class OMIEError(Exception):
    """Base exception for OMIE client errors."""

    pass


class OMIEDataError(OMIEError):
    """Exception for OMIE data retrieval or processing errors."""

    def __init__(self, message: str, original_exception: Exception | None = None):
        self.original_exception = original_exception
        super().__init__(message)


class OMIEValidationError(OMIEError):
    """Exception for input validation errors."""

    pass


class OMIERegion(StrEnum):
    """OMIE market region codes used for intraday file downloads."""

    ES = "ES"
    PT = "PT"


class PriceRegion(StrEnum):
    """OMIE price regions for market data filtering."""

    PRICE_SPAIN = str(DataTypeInMarginalPriceFile.PRICE_SPAIN)
    PRICE_PORTUGAL = str(DataTypeInMarginalPriceFile.PRICE_PORTUGAL)
    ENERGY_IBERIAN = str(DataTypeInMarginalPriceFile.ENERGY_IBERIAN)
    ENERGY_IBERIAN_WITH_BILLATERAL = str(DataTypeInMarginalPriceFile.ENERGY_IBERIAN_WITH_BILLATERAL)


@dataclass
class MarginalPriceRecord:
    timestamp: date
    region: PriceRegion
    prices: list[float | None]


class OMIEClient:
    """Client for retrieving OMIE electricity market data."""

    def __init__(self, logger: Logger | None = None) -> None:
        """Initialize the OMIE client."""
        self._logger = logger or get_logger(__name__)

    def get_marginal_market_prices(
        self,
        start_date: date,
        end_date: date,
        price_region: PriceRegion | None = None,
    ) -> list[MarginalPriceRecord]:
        """Get electricity market prices for a date range."""
        if start_date > end_date:
            raise OMIEValidationError("start_date must be before or equal to end_date")

        try:
            self._logger.info(
                "retrieving OMIE market prices",
                start_date=str(start_date),
                end_date=str(end_date),
                price_region=str(price_region) if price_region else None,
            )

            # Use the OMIE data importer to fetch market prices
            df = OMIEMarginalPriceFileImporter(start_date, end_date).read_to_dataframe()
            if df.empty:
                self._logger.warning(
                    "no market price data available", start_date=str(start_date), end_date=str(end_date)
                )
                return []

            # Filter by price region if specified
            if price_region:
                initial_count = len(df)
                df = df[str(price_region) == df.CONCEPT]
                self._logger.debug(
                    "data filtered by region",
                    initial_count=initial_count,
                    filtered_count=len(df),
                    price_region=str(price_region),
                )

            self._logger.debug(
                "market price data retrieved", record_count=len(df), start_date=str(start_date), end_date=str(end_date)
            )

            result = [
                MarginalPriceRecord(
                    timestamp=record["DATE"],
                    region=PriceRegion(record["CONCEPT"]),
                    prices=[None if pd.isna(val) else val for key, val in record.items() if key.startswith("H")],
                )
                for record in df.to_dict(orient="records")
            ]

            return result

        except OMIEValidationError:
            raise
        except Exception as e:
            self._logger.error(
                "failed to retrieve market prices",
                start_date=str(start_date),
                end_date=str(end_date),
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise OMIEDataError(f"Failed to retrieve market data: {e}", e) from e

    def get_intraday_prices(
        self,
        start_date: date,
        end_date: date,
        session: int,
        region: OMIERegion,
    ) -> list[MarginalPriceRecord]:
        """Get intraday auction (IDA) prices for a date range.

        Since June 14, 2024, OMIE publishes 3 IDA sessions per region (ES/PT).

        Args:
            start_date: Start date (inclusive).
            end_date: End date (inclusive).
            session: IDA session number (1, 2, or 3).
            region: Market region (``OMIERegion.ES`` or ``OMIERegion.PT``).
        """
        if start_date > end_date:
            raise OMIEValidationError("start_date must be before or equal to end_date")
        if session not in (1, 2, 3):
            raise OMIEValidationError("session must be 1, 2, or 3")
        region = OMIERegion(region)

        try:
            self._logger.info(
                f"Retrieving OMIE intraday IDA{session} prices for {region} from {start_date} to {end_date}"
            )

            df = OMIEDataImporterFromResponses(
                date_ini=start_date,
                date_end=end_date,
                file_downloader=IntraDayPriceDownloader(session, region=region),
                file_reader=MarginalPriceFileReader(),
            ).read_to_dataframe()

            if df.empty:
                self._logger.warning(f"No intraday IDA{session} data for {region} from {start_date} to {end_date}")
                return []

            result = [
                MarginalPriceRecord(
                    timestamp=record["DATE"],
                    region=PriceRegion(record["CONCEPT"]),
                    prices=[None if pd.isna(val) else val for key, val in record.items() if key.startswith("H")],
                )
                for record in df.to_dict(orient="records")
            ]

            return result

        except OMIEValidationError:
            raise
        except Exception as e:
            raise OMIEDataError(
                f"Failed to retrieve intraday IDA{session} prices for {region} from {start_date} to {end_date}: {e}"
            ) from e

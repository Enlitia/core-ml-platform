"""
Test fixtures to be used by all packages.
"""

import pathlib
from dataclasses import dataclass

try:
    import pytest
except ImportError as exc:
    raise Exception("Must install pytest to use toolkit's fixtures") from exc

from toolkit.configuration import configuration

MISSING_SQLALCHEMY = ImportError("sqlalchemy is required for database fixtures. Please install it.")


@dataclass
class TmpDbParams:
    """
    Parameters that may be passed to tmp_db and tmp_db_empty fixtures.

    ## Example:
    ```python
    import pytest

    @pytest.mark.parametrize(
        "tmp_db", [TmpDbParams(db_alias="testing")], indirect=True
    )
    def test_something(tmp_db):
        # tmp_db will be a session to the database with "testing" alias
        ...
    ```
    """

    sql_files_path: str = "./tests/data/sql"
    db_alias: str = "default"


@pytest.fixture(scope="function", autouse=True)
def clear_settings_cache():
    """
    Settings are immutable due to performance reasons, each time we need to
     access those, it would need to read the environment variable once again.
    For testing purposes, we actually want to be able to change that
     environment variable frequently and see settings changing accordingly.
    This fixture, clears the settings cache after each test.
    """
    yield
    try:
        del configuration.settings
    except AttributeError:
        # Not every test accesses settings, therefore, the object will never
        # be cached
        pass


@pytest.fixture()
def file_fixture_path():
    """
    Defines the path for the project file fixtures. It is expected the
     fixture path to be: $PROJECT_ROOT/fixtures
    """
    fixture_path = pathlib.Path("./tests/data")
    if not fixture_path.exists() or not fixture_path.is_dir():
        raise Exception("Invalid or not found fixture path")

    return fixture_path


@pytest.fixture
def test_data_model(request):
    """
    Provides a data model to be used in tests and creates the matching database
    table. After the test runs, it cleans any data in the table.
    """
    # Local import, because we shouldn't trigger database engine creation in
    # tests unless we really need it.
    try:
        from sqlalchemy import Column, Integer, String
        from sqlalchemy.orm import close_all_sessions
    except ImportError:
        raise MISSING_SQLALCHEMY
    from toolkit.database import DataModelBase, _Database

    # Allow the test to define which database it wants to use
    try:
        alias = request.param
    except AttributeError:
        alias = None
    database = _Database(configuration.settings, alias=alias)

    # Setup ------------------------------------------------------------------
    # Having a test table here, provides a clean way of creating a table and
    # deleting any of it's content in the end of a test.
    #
    # To fix warning: https://stackoverflow.com/questions/60615531/creating-dynamic-classes-in-sqlalchemy
    #       "This declarative base already contains a class with the same class
    #        name and module name as testrig.global_fixtures.TestDataModel,
    #        and will be replaced in the string-lookup table"
    class TestDataModel(DataModelBase):
        __tablename__ = "test_data_model"
        # Assuming extension of the exiting table. It's not like anyone will
        # change the table in the middle of a test.
        # https://stackoverflow.com/questions/37908767/table-roles-users-is-already-defined-for-this-metadata-instance
        __table_args__ = {"extend_existing": True}
        id = Column(Integer, primary_key=True)
        # The 'name' attribute is to allow tests to use something more to play
        name = Column(String(16))

    TestDataModel.__table__.create(database.engine)

    # Provide the table -------------------------------------------------------
    yield TestDataModel

    # TearDown: Cleaning the table contents here ------------------------------
    # Not closing the session, makes the drop hang in place forever.
    # https://docs.sqlalchemy.org/en/20/orm/session_api.html?highlight=close_all#sqlalchemy.orm.close_all_sessions
    close_all_sessions()
    TestDataModel.__table__.drop(database.engine)


"""
Variable that stores the standard commit function of a database session.

The commit function will be assigned to this variable when the database setup is done for the first time.
"""
_commit = None

"""
Variable that stores the standard sql test files.
"""
_default_sql_files = pathlib.Path("./tests/data/sql")


def _dummy_commit():
    """
    Does nothing.

    Dummy function used to override the standard commit function
    of a database session in order to disable the functionality.
    """
    pass


def _clear_tables(session, path: pathlib.Path):  # noqa
    try:
        from sqlalchemy import text
    except ImportError:
        raise MISSING_SQLALCHEMY
    """
    Creates or cleans the database.
    """
    if "postgresql" == session.bind.dialect.name:
        statement = "select table_name from information_schema.tables where table_schema = 'public'"
    elif "mysql" == session.bind.dialect.name:
        statement = "SHOW TABLES;"

    tables = session.execute(text(statement)).all()
    tables_exist = True if tables else False

    # Create the tables
    if not tables_exist:
        sql_file = path / "01-tables.sql"
        try:
            sql = sql_file.read_text()
        except FileNotFoundError:
            raise FileNotFoundError("You need to create this file: tests/data/sql/01-tables.sql")

        if sql:  # Files may exist, but empty
            session.execute(text(sql))
            session.commit()
    else:
        # Truncate tables
        truncate_query = ""
        if "mysql" == session.bind.dialect.name:
            session.execute(text("SET foreign_key_checks = 0"))
        for (table,) in tables:
            if "postgresql" == session.bind.dialect.name:
                truncate_query += f'TRUNCATE TABLE "{table}" CASCADE;'
            elif "mysql" == session.bind.dialect.name:
                truncate_query += f"TRUNCATE TABLE `{table}`;"
        session.execute(text(truncate_query))
        if "mysql" == session.bind.dialect.name:
            session.execute(text("SET foreign_key_checks = 1"))

    session.commit()


def _load_static_data(session, path: pathlib.Path):
    """
    Loads SQL static data into the tables.
    """

    sql_file = path / "02-static-data.sql"
    try:
        sql = sql_file.read_text()
    except FileNotFoundError:
        raise FileNotFoundError("You need to create this file: tests/data/sql/02-static-data.sql")
    if not sql:  # Files may exist, but empty
        return

    try:
        from sqlalchemy import text
    except ImportError:
        raise MISSING_SQLALCHEMY

    session.execute(text(sql))
    session.commit()


def _load_test_data(session, path: pathlib.Path):
    """
    Loads SQL test data into the tables.
    """

    sql_file = path / "03-test-data.sql"
    try:
        sql = sql_file.read_text()
    except FileNotFoundError:
        raise FileNotFoundError("You need to create this file: tests/data/sql/03-test-data.sql")
    if not sql:  # Files may exist, but empty
        return

    try:
        from sqlalchemy import text
    except ImportError:
        raise MISSING_SQLALCHEMY

    session.execute(text(sql))
    session.commit()


def _setup_base_database_scenario(session, sql_files):
    """
    Creates or cleans the database and sets up in its initial state.
    """
    _clear_tables(session, sql_files)
    _load_static_data(session, sql_files)


def _sql_files(request):
    """
    Returns the paths of SQL test scripts.

    Loads any SQL available in $PROJECTROOT/tests/data/sql.
    The SQL files path can be customized by using a test fixture. Example:
    > @pytest.mark.parametrize("tmp_db", ["./tests/custom_path/"], indirect=["tmp_db"])
    > def test_......
    """
    sql_files = _default_sql_files
    if hasattr(request, "param") and isinstance(request.param, TmpDbParams):
        params: TmpDbParams = request.param
        sql_files = pathlib.Path(params.sql_files_path)
    return sql_files


@pytest.fixture(scope="session")
def _database():
    """
    Yields database.
    """
    from toolkit.database import _Database  # noqa

    with _Database(configuration.settings) as database:
        yield database


@pytest.fixture(scope="session")
def _standard_test_session(_database, request):
    """
    Setups the initial database and yields a session.
    """
    session_ctx = _database.session
    if hasattr(request, "param") and isinstance(request.param, TmpDbParams):
        params: TmpDbParams = request.param
        if params.db_alias != "default":
            session_ctx = _database.using(params.db_alias).session

    with session_ctx() as session:
        global _commit
        _commit = session.commit

        sql_files = _sql_files(request)
        _setup_base_database_scenario(session, sql_files)

        yield session


@pytest.fixture
def tmp_db_empty(_standard_test_session, request):
    """
    Creates or cleans the database and sets up its initial state.

    Yields a session which allows commiting to the database.
    After the test runs, the database is cleaned and restored to its initial state.

    Loads any SQL available in $PROJECTROOT/tests/data/sql.
    The SQL files path can be customized by using a test fixture. Example:
    > @pytest.mark.parametrize("tmp_db_empty", ["./tests/custom_path/"], indirect=["tmp_db_empty"])
    > def test_......
    """
    setattr(_standard_test_session, "commit", _commit)  # noqa

    yield _standard_test_session

    sql_files = _sql_files(request)
    _setup_base_database_scenario(_standard_test_session, sql_files)


@pytest.fixture
def tmp_db(_standard_test_session, request):
    """
    Creates or cleans the database and populates it with test data.

    Yields a session which allows commiting to the database.
    After the test runs, the database is cleaned and restored to its initial state.

    Loads any SQL available in $PROJECTROOT/tests/data/sql.
    The SQL files path can be customized by using a test fixture. Example:
    > @pytest.mark.parametrize("tmp_db", ["./tests/custom_path/"], indirect=["tmp_db"])
    > def test_......
    """
    setattr(_standard_test_session, "commit", _commit)  # noqa

    sql_files = _sql_files(request)
    _load_test_data(_standard_test_session, sql_files)

    yield _standard_test_session

    _setup_base_database_scenario(_standard_test_session, sql_files)


@pytest.fixture
def transactional_tmp_db_empty(_standard_test_session):
    """
    Creates or cleans the database and sets up its initial state.

    Yields a session which doesn't allow commiting to the database.
    After the test runs, the transaction is rollbacked.

    Loads any SQL available in $PROJECTROOT/tests/data/sql.
    The SQL files path can be customized by using a test fixture. Example:
    > @pytest.mark.parametrize("transactional_tmp_db_empty", ["./tests/custom_path/"],
    indirect=["transactional_tmp_db_empty"])
    > def test_......
    """
    setattr(_standard_test_session, "commit", _dummy_commit)  # noqa

    yield _standard_test_session

    _standard_test_session.rollback()


@pytest.fixture
def transactional_tmp_db(_standard_test_session, request):
    """
    Creates or cleans the database and populates it with test data.

    Yields a session which doesn't allow commiting to the database.
    After the test runs, the transaction is rollbacked.

    Loads any SQL available in $PROJECTROOT/tests/data/sql.
    The SQL files path can be customized by using a test fixture. Example:
    > @pytest.mark.parametrize("transactional_tmp_db", ["./tests/custom_path/"], indirect=["transactional_tmp_db"])
    > def test_......
    """
    setattr(_standard_test_session, "commit", _dummy_commit)  # noqa

    sql_files = _sql_files(request)
    _load_test_data(_standard_test_session, sql_files)

    yield _standard_test_session

    _standard_test_session.rollback()

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from zeep import Client
from zeep.exceptions import Error, Fault, TransportError
from zeep.helpers import serialize_object
from zeep.xsd import SkipValue

from toolkit.logging import Logger, SOAPClientLabels, get_logger


class SOAPRequestError(Exception):
    """Generic exception for SOAP request errors (application-level)."""

    def __init__(self, method: str, error_code: str, message: str = ""):
        self.method = method
        self.error_code = error_code
        self.message = message or f"SOAP request '{method}' failed with error code '{error_code}'"
        super().__init__(self.message)


class SOAPTransportError(Exception):
    """Exception for network/transport-level errors."""

    def __init__(self, method: str, original_exception: Exception):
        self.method = method
        self.original_exception = original_exception
        super().__init__(f"SOAP transport error in '{method}': {str(original_exception)}")


class NoSessionToken(Exception):
    """
    Exception raised when the user didn't login successfully.
    """

    def __init__(self) -> None:
        self.message = "Login failed"
        super().__init__(self.message)


@dataclass
class ObservationFacilityData:
    facility_id: int
    start_time: datetime
    data: float
    valid: str = "1"


@dataclass
class ForecastResponse:
    facilityId: str
    granularity: int
    percentiles: list[int]
    variableId: str
    predictorId: str
    forecastDate: datetime
    data: List[dict[str, Any]]


class MeteologicaClient:
    """SOAP client for Meteologica's weather forecast API.

    This client provides access to Meteologica's weather forecasting services through their SOAP API.
    It handles authentication, session management, and provides methods for retrieving facility data,
    forecasts, and submitting observation data.

    The client implements automatic session token management and error handling for both
    network-level (transport) and application-level (API) errors.

    Example:
        ```python
        with MeteologicaClient("wsdl_url", "username", "password") as client:
            client.login()
            facilities = client.get_all_facilities()
            forecast = client.get_forecast_multi("predictor_id")
        ```

    Args:
        wsdl_path: URL to Meteologica's WSDL service definition
        username: API username for authentication
        password: API password for authentication
        logger: Optional logger instance (defaults to module logger)
    """

    def __init__(self, wsdl_path: str, username: str, password: str, logger: Logger | None = None) -> None:
        self._client: Client = Client(wsdl=wsdl_path)
        self._factory: Any = self._client.type_factory("ns0")

        self._username = username
        self._password = password

        self._session_token: Union[str, None] = None
        self._header: Any = None

        self._logger = logger or get_logger(__name__)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Improved context manager exit."""
        try:
            self._logout()
        except Exception as e:
            self._logger.warning("logout failed during cleanup", error_type=type(e).__name__, error_message=str(e))

    def _set_token(self, session_token: str):
        """Set the session token and update the header."""
        self._session_token = session_token
        self._header = self._factory.APIRequestHeader(sessionToken=session_token)

    def _request(self, method: str, request_type: str, response_type: str, *args, **kwargs):
        """
        Generic method to call a SOAP service with automatic header injection,
        authentication validation, and error handling.

        Validates that authentication is established before making API calls.
        All methods except 'login' require a valid session header.

        :param method: Name of the SOAP method to call
        :param request_type: Name of the request object to build
        :param response_type: Name of the response object to parse
        :param args: Positional arguments for the request object
        :param kwargs: Keyword arguments for the request object
        :return: Parsed response object if successful
        :raises: SOAPRequestError, SOAPTransportError

        Note:
            - Raises SOAPRequestError with "NO_SESSION" code if authentication required but missing
            - Login method is exempt from authentication validation
        """

        api = SOAPClientLabels.API

        # Check if authentication header is required for this method
        if method != "login" and self._header is None:
            raise SOAPRequestError(method, "NO_SESSION", "Authentication required but no session header found")

        try:
            self._logger.debug("SOAP request started", action=api.started, method=method)

            # Build request object
            request_obj = (
                getattr(self._factory, request_type)(*args, **kwargs, header=self._header)
                if self._header
                else getattr(self._factory, request_type)(*args, **kwargs)
            )

            # Call the SOAP service with auth header
            raw_response = getattr(self._client.service, method)(request_obj)
            self._logger.debug("SOAP request completed", action=api.completed, method=method)

            # Parse the response
            response_obj = getattr(self._factory, response_type)(raw_response)

            # Application-level error handling + token update
            if hasattr(response_obj, "__getitem__") and "errorCode" in response_obj:
                error_info = response_obj["errorCode"]
                code = error_info["errorCode"] if "errorCode" in error_info else "UNKNOWN"

                header = None
                if "header" in error_info:
                    header = error_info["header"]
                elif "header" in response_obj:
                    header = response_obj["header"]

                if header and "sessionToken" in header:
                    new_token = header["sessionToken"]
                    if new_token != self._session_token:
                        self._logger.info("Session token refreshed", action=api.completed, method=method)
                        self._set_token(new_token)

                if code != "OK":
                    message = error_info["message"] if "message" in error_info else ""
                    self._logger.error(
                        "SOAP application error",
                        action=api.failed,
                        method=method,
                        error_code=code,
                        error_message=message,
                    )
                    raise SOAPRequestError(method, code, message)

            return response_obj[
                "errorCode"
            ]  # This is confusing but errorCode is the main response container even on success

        except (Fault, TransportError, Error) as e:
            # Network/transport-level error handling
            self._logger.error(
                "SOAP transport error",
                action=api.failed,
                method=method,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise SOAPTransportError(method, e)

    def login(self):
        """Authenticate with Meteologica's API and establish a session.

        This method must be called before using any other API methods. It exchanges
        the provided credentials for a session token that is automatically used
        for subsequent requests.

        Returns:
            str: The API response error code ("OK" on success)

        Raises:
            NoSessionToken: If authentication fails or no session token is received
            SOAPRequestError: If API returns an error
            SOAPTransportError: If network/transport error occurs
        """
        auth = SOAPClientLabels.AUTH
        self._logger.debug("Login started", action=auth.started)

        response = self._request(
            method="login",
            request_type="LoginReq",
            response_type="LoginResp",
            username=self._username,
            password=self._password,
        )

        if not self._header:
            self._logger.error("Login failed — no session token received", action=auth.failed)
            raise NoSessionToken

        self._logger.info("Login completed", action=auth.completed)
        return response["errorCode"]

    def _logout(self):
        """End the current API session.

        This method should be called when finished with API operations to properly
        clean up the session. It's automatically called by the context manager.

        Returns:
            str: The API response error code ("OK" on success), or None if no client exists
        """
        if not self._client:
            # No client means no session was ever established
            return

        response = self._request(
            method="logout",
            request_type="LogoutReq",
            response_type="LogoutResp",
        )

        self._session_token = None
        self._header = None
        self._logger.debug("Logged out")

        return response["errorCode"]

    def get_all_facilities(self):
        """Fetch all assets available for forecasting in Meteologica's service.

        Returns:
            List[Dict]: List of dictionaries with facility information:
                - facilityId (str): Unique identifier for the asset
                - facilityName (str): Descriptive name for the asset
                - installedCapacity (int): Nominal power in kW
                - lat (float): Latitude coordinate
                - long (float): Longitude coordinate (note: API uses 'long', not 'lon')
                - timezone (str): Timezone of the asset's location

        Raises:
            SOAPRequestError: If API returns an error
            SOAPTransportError: If network/transport error occurs
        """

        response = self._request(
            method="getAllFacilities",
            request_type="GetAllFacilitiesReq",
            response_type="GetAllFacilitiesResp",
        )

        return serialize_object(response["facilityItems"]["item"])

    def get_facility_forecasted_vnp(self, facility_id: str):
        """Fetch available predictors for forecasting a specific asset.

        Args:
            facility_id: Unique identifier of the facility/asset

        Returns:
            List[Dict]: List of available predictors with keys:
                - facilityId (str): The facility identifier (same as input)
                - variableId (str): Variable that can be forecasted
                - predictorId (str): Predictor ID for use in get_forecast_multi()

        Raises:
            SOAPRequestError: If API returns an error
            SOAPTransportError: If network/transport error occurs
        """

        response = self._request(
            method="getFacilityForecastedVnP",
            request_type="GetFacilityForecastedVnPReq",
            response_type="GetFacilityForecastedVnPResp",
            facilityId=facility_id,
        )

        return serialize_object(response["vnps"]["item"])

    @staticmethod
    def _parse_forecast_data(data: str, percentiles: List[int]):
        """Parse forecast data string into structured dictionaries.

        Args:
            data: Raw forecast data in format ":unix_time~p1~p2~...pN:unix_time~p1~p2...pN:"
            percentiles: List of percentile values corresponding to the data columns

        Returns:
            List[Dict]: Parsed forecast data with keys:
                - time (datetime): Forecast timestamp in UTC
                - {percentile} (float): Value for each percentile (e.g., "50": 120.5)
        """
        if not data or not data.strip():
            return []

        parsed_data = []

        # Format: :unix_time~p1~p2~...pN:unix_time~p1~p2...pN: ...
        epochs = data.split(":")[1:]  # Remove first empty element
        for epoch in epochs:
            if not epoch.strip():  # Skip empty epochs
                continue

            epoch_data: Dict[str, Union[datetime, float]] = {}
            variables = epoch.split("~")
            unix_time = int(variables[0])

            epoch_data = {str(percentile): float(variables[i + 1]) for i, percentile in enumerate(percentiles)}
            epoch_data["time"] = datetime.fromtimestamp(unix_time, tz=timezone.utc)

            parsed_data.append(epoch_data)

        return parsed_data

    def get_forecast_multi(
        self,
        predictor_id: str,
        forecast_date: Optional[datetime] = None,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        granularity: Optional[int] = None,
        percentiles: Optional[List[int]] = None,
        facilities_id: Optional[Union[str, List]] = None,
        variable_id: str = "prod",
    ):
        """Get forecast data for one or more assets.

        Args:
            predictor_id: Prediction method to use (must be available, e.g., "aggregated")
            forecast_date: Date when the forecast was produced (available date)
            from_date: Start time for the forecast period
            to_date: End time for the forecast period
            granularity: Time resolution in minutes (5, 10, 15, 30, or 60)
            percentiles: Confidence bounds (50 represents the target forecast)
            facilities_id: Asset identifier(s) - string or list of strings
            variable_id: Variable identifier (defaults to "prod")

        Returns:
            List[Dict]: Forecast data with keys:
                - facilityId (str): Asset's unique identifier
                - granularity (int): Time resolution in minutes
                - percentiles (List[int]): Confidence bounds used
                - variableId (str): Variable identifier
                - predictorId (str): Predictor identifier used
                - forecastDate (datetime): When forecast was produced
                - data (List[Dict]): Time series data with:
                    - time (datetime): Prediction timestamp
                    - {percentile} (float): Value for each percentile

        Raises:
            SOAPRequestError: If API returns an error
            SOAPTransportError: If network/transport error occurs

        Note:
            Use get_facility_forecasted_vnp() first to check available predictors
            for your assets.
        """

        if not forecast_date:
            forecast_date = SkipValue  # type: ignore
        if not from_date:
            from_date = SkipValue  # type: ignore
        if not to_date:
            to_date = SkipValue  # type: ignore
        if not granularity:
            granularity = SkipValue  # type: ignore
        if not percentiles:
            percentiles = SkipValue  # type: ignore

        if percentiles != SkipValue:
            percentiles = ",".join([str(element) for element in percentiles])  # type: ignore

        if not facilities_id or len(facilities_id) == 0:
            facilities_id = SkipValue  # type: ignore
        else:
            facilities_id = self._factory.ArrayOfString(facilities_id)

        response = self._request(
            method="getForecastMulti",
            request_type="GetForecastMultiReq",
            response_type="GetForecastMultiResp",
            variableId=variable_id,
            predictorId=predictor_id,
            forecastDate=forecast_date,
            fromDate=from_date,
            toDate=to_date,
            granularity=granularity,
            percentiles=percentiles,
            facilitiesId=facilities_id,
        )

        # Parse response into organized list of dictionaries
        variable_id = response["variableId"]
        predictor_id = response["predictorId"]
        percentiles_str: str = response["percentiles"]
        percentiles = [int(x) for x in percentiles_str.split(",")]
        granularity = int(response["granularity"])
        forecast_data = serialize_object(response["facilitiesForecastData"]["item"])

        final_response: list[ForecastResponse] = []

        for item in forecast_data:
            try:
                forecast_date = datetime.fromisoformat(item["forecastDate"])
            except ValueError:
                splitted_datetime = item["forecastDate"].split("+")
                if len(splitted_datetime) != 2:
                    raise
                datetime_body = splitted_datetime[0]
                datetime_offset = splitted_datetime[1]
                # Add ':' to offset, to make valid ISO format string (this is a bug on Meteologica's side)
                offset_hours = datetime_offset[: len(datetime_offset) // 2]
                offset_minutes = datetime_offset[len(datetime_offset) // 2 :]
                forecast_date = datetime.fromisoformat(f"{datetime_body}+{offset_hours}:{offset_minutes}")

            final_response.append(
                ForecastResponse(
                    facilityId=item["facilityId"],
                    granularity=granularity,
                    percentiles=percentiles,
                    variableId=variable_id,
                    predictorId=predictor_id,
                    forecastDate=forecast_date,
                    data=self._parse_forecast_data(item["forecastData"], percentiles),
                )
            )

        return final_response

    def set_observation_multi(
        self,
        observation_facilities_data: list[ObservationFacilityData],
        measurement_type: str = "MEAN",
        variable_id: str = "prod",
        measurement_time: Optional[int] = None,
        unit: Optional[str] = None,
        observation_type: Optional[str] = None,
    ):
        """Sets observation data for multiple assets

        Args:
            observation_facilities_data (List[ObservationFacilityData]): An object for each observed value for each
                facility.
            measurement_type (str): Metering method to use.
            variable_id (str): Unique identifier of forecasted variable.
            measurement_time (int): Duration of each metered interval in minutes. Default is 0 if not sent.
            unit (str): Defines the unit of measurement of the observed data. Default is 'MW' if not sent.
            observation_type (str): Type of observation.

        Returns True if everything went ok.

        In case of error, it raises an exception with the error.

        """

        if not measurement_time:
            measurement_time = SkipValue  # type: ignore
        if not unit:
            unit = SkipValue  # type: ignore
        if not observation_type:
            observation_type = SkipValue  # type: ignore

        observation_facilities = [
            self._factory.ObsFacilitiesData(
                facilityId=data.facility_id, startTime=data.start_time, data=data.data, valid=data.valid
            )
            for data in observation_facilities_data
        ]
        observation_facilities = self._factory.ArrayOfObsfacilitiesdata(observation_facilities)

        self._request(
            method="setObservationMulti",
            request_type="SetObservationMultiReq",
            response_type="SetObservationMultiResp",
            variableId=variable_id,
            measurementType=measurement_type,
            measurementTime=measurement_time,
            unit=unit,
            observationType=observation_type,
            observationFacilitiesData=observation_facilities,
        )


# flake8: noqa
# Below is useful information regarding Meteologica's API,
# generated with the following command:
#   poetry run python -m zeep \
#   https://webservice.meteologica.com/apitest/wsdl/MeteologicaDataExchangeService.wsdl
# Global types:
#      xsd:anyType
#      xsd:ENTITIES
#      xsd:ENTITY
#      xsd:ID
#      xsd:IDREF
#      xsd:IDREFS
#      xsd:NCName
#      xsd:NMTOKEN
#      xsd:NMTOKENS
#      xsd:NOTATION
#      xsd:Name
#      xsd:QName
#      xsd:anySimpleType
#      xsd:anyURI
#      xsd:base64Binary
#      xsd:boolean
#      xsd:byte
#      xsd:date
#      xsd:dateTime
#      xsd:decimal
#      xsd:double
#      xsd:duration
#      xsd:float
#      xsd:gDay
#      xsd:gMonth
#      xsd:gMonthDay
#      xsd:gYear
#      xsd:gYearMonth
#      xsd:hexBinary
#      xsd:int
#      xsd:integer
#      xsd:language
#      xsd:long
#      xsd:negativeInteger
#      xsd:nonNegativeInteger
#      xsd:nonPositiveInteger
#      xsd:normalizedString
#      xsd:positiveInteger
#      xsd:short
#      xsd:string
#      xsd:time
#      xsd:token
#      xsd:unsignedByte
#      xsd:unsignedInt
#      xsd:unsignedLong
#      xsd:unsignedShort
#      ns0:APIErrorEnum
#      ns0:APIRequestHeader(sessionToken: xsd:string)
#      ns0:APIResponseHeader(sessionToken: xsd:string, errorCode: ns0:APIErrorEnum)
#      ns0:ArrayOfAvailabilitydata(item: ns0:AvailabilityData[])
#      ns0:ArrayOfAvailfacilitiesdata(item: ns0:AvailFacilitiesData[])
#      ns0:ArrayOfFacilitiesavailabilitydata(item: ns0:FacilitiesAvailabilityData[])
#      ns0:ArrayOfFacilitiesforecastdata(item: ns0:FacilitiesForecastData[])
#      ns0:ArrayOfFacility(item: ns0:Facility[])
#      ns0:ArrayOfFacilityspe(item: ns0:FacilitySPE[])
#      ns0:ArrayOfObsdata(item: ns0:ObsData[])
#      ns0:ArrayOfObsfacilitiesdata(item: ns0:ObsFacilitiesData[])
#      ns0:ArrayOfObsvar(item: ns0:ObsVar[])
#      ns0:ArrayOfSpevar(item: ns0:SPEvar[])
#      ns0:ArrayOfString(item: xsd:string[])
#      ns0:ArrayOfVnp(item: ns0:VnP[])
#      ns0:AvailFacilitiesData(facilityId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, availability: xsd:float)
#      ns0:AvailabilityData(fromDate: xsd:string, toDate: xsd:string, limitationType: xsd:string, powerPercentage: xsd:string, powerValue: xsd:string, unit: xsd:string, installedCapacity: xsd:string, insertDate: xsd:string, source: xsd:string, comment: xsd:string)
#      ns0:FacilitiesAvailabilityData(facilityId: xsd:string, availabilityData: ns0:ArrayOfAvailabilitydata)
#      ns0:FacilitiesForecastData(forecastDate: xsd:string, facilityId: xsd:string, forecastData: xsd:string)
#      ns0:Facility(facilityId: xsd:string, facilityName: xsd:string, installedCapacity: xsd:int, lat: xsd:float, long: xsd:float, timezone: xsd:string)
#      ns0:FacilitySPE(facilityId: xsd:string, facilityName: xsd:string, lat: xsd:float, long: xsd:float, timezone: xsd:string)
#      ns0:GetAllFacilitiesErrorEnum
#      ns0:GetAllFacilitiesReq(header: ns0:APIRequestHeader)
#      ns0:GetAllFacilitiesResp(errorCode: ns0:GetAllFacilitiesErrorEnum, facilityItems: ns0:ArrayOfFacility, header: ns0:APIResponseHeader)
#      ns0:GetAllFacilitiesSPEErrorEnum
#      ns0:GetAllFacilitiesSPEReq(header: ns0:APIRequestHeader)
#      ns0:GetAllFacilitiesSPEResp(errorCode: ns0:GetAllFacilitiesSPEErrorEnum, facilityItems: ns0:ArrayOfFacilityspe, header: ns0:APIResponseHeader)
#      ns0:GetAvailabilityMultiErrorEnum
#      ns0:GetFacilityForecastedVarSPEErrorEnum
#      ns0:GetFacilityForecastedVarSPEReq(facilityId: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetFacilityForecastedVarSPEResp(errorCode: ns0:GetFacilityForecastedVarSPEErrorEnum, SPEvars: ns0:ArrayOfSpevar, header: ns0:APIResponseHeader)
#      ns0:GetFacilityForecastedVnPEnsembleErrorEnum
#      ns0:GetFacilityForecastedVnPEnsembleReq(facilityId: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetFacilityForecastedVnPEnsembleResp(errorCode: ns0:GetFacilityForecastedVnPEnsembleErrorEnum, vnps: ns0:ArrayOfVnp, header: ns0:APIResponseHeader)
#      ns0:GetFacilityForecastedVnPErrorEnum
#      ns0:GetFacilityForecastedVnPReq(facilityId: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetFacilityForecastedVnPResp(errorCode: ns0:GetFacilityForecastedVnPErrorEnum, vnps: ns0:ArrayOfVnp, header: ns0:APIResponseHeader)
#      ns0:GetFacilityOVErrorEnum
#      ns0:GetFacilityOVReq(facilityId: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetFacilityOVResp(errorCode: ns0:GetFacilityOVErrorEnum, obsVariables: ns0:ArrayOfObsvar, header: ns0:APIResponseHeader)
#      ns0:GetForecastEnsembleReq(facilityId: xsd:string, variableId: xsd:string, predictorId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, forecastDate: xsd:dateTime, granularity: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetForecastEnsembleResp(errorCode: ns0:GetForecastErrorEnum, facilityId: xsd:string, variableId: xsd:string, predictorId: xsd:string, forecastDate: xsd:string, granularity: xsd:string, forecastData: xsd:string, header: ns0:APIResponseHeader)
#      ns0:GetForecastErrorEnum
#      ns0:GetForecastMultiErrorEnum
#      ns0:GetForecastMultiReq(variableId: xsd:string, predictorId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, forecastDate: xsd:dateTime, granularity: xsd:string, percentiles: xsd:string, facilitiesId: ns0:ArrayOfString, header: ns0:APIRequestHeader)
#      ns0:GetForecastMultiResp(errorCode: ns0:GetForecastMultiErrorEnum, variableId: xsd:string, predictorId: xsd:string, granularity: xsd:string, percentiles: xsd:string, facilitiesForecastData: ns0:ArrayOfFacilitiesforecastdata, header: ns0:APIResponseHeader)
#      ns0:GetForecastReq(facilityId: xsd:string, variableId: xsd:string, predictorId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, forecastDate: xsd:dateTime, granularity: xsd:string, percentiles: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetForecastResp(errorCode: ns0:GetForecastErrorEnum, facilityId: xsd:string, variableId: xsd:string, predictorId: xsd:string, forecastDate: xsd:string, granularity: xsd:string, forecastData: xsd:string, header: ns0:APIResponseHeader)
#      ns0:GetForecastSPEErrorEnum
#      ns0:GetForecastSPEReq(facilityId: xsd:string, variableId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, forecastDate: xsd:dateTime, granularity: xsd:string, header: ns0:APIRequestHeader)
#      ns0:GetForecastSPEResp(errorCode: ns0:GetForecastSPEErrorEnum, facilityId: xsd:string, variableId: xsd:string, unitMeasure: xsd:string, forecastDate: xsd:string, forecastData: xsd:string, header: ns0:APIResponseHeader)
#      ns0:KeepAliveErrorEnum
#      ns0:KeepAliveReq(header: ns0:APIRequestHeader)
#      ns0:KeepAliveResp(errorCode: ns0:KeepAliveErrorEnum, header: ns0:APIResponseHeader)
#      ns0:LoginErrorEnum
#      ns0:LoginReq(username: xsd:string, password: xsd:string)
#      ns0:LoginResp(errorCode: ns0:LoginErrorEnum, header: ns0:APIResponseHeader)
#      ns0:LogoutErrorEnum
#      ns0:LogoutReq(header: ns0:APIRequestHeader)
#      ns0:LogoutResp(errorCode: ns0:LogoutErrorEnum, header: ns0:APIResponseHeader)
#      ns0:ObsData(startTime: xsd:dateTime, data: xsd:float, valid: xsd:string)
#      ns0:ObsFacilitiesData(facilityId: xsd:string, startTime: xsd:dateTime, data: xsd:float, valid: xsd:string)
#      ns0:ObsVar(variableId: xsd:string)
#      ns0:SPEvar(facilityId: xsd:string, variableId: xsd:string)
#      ns0:SetAvailabilityErrorEnum
#      ns0:SetAvailabilityMultiErrorEnum
#      ns0:SetAvailabilityMultiReq(limitationType: xsd:string, unit: xsd:string, availabilityFacilitiesData: ns0:ArrayOfAvailfacilitiesdata, header: ns0:APIRequestHeader)
#      ns0:SetAvailabilityMultiResp(errorCode: ns0:SetAvailabilityMultiErrorEnum, header: ns0:APIResponseHeader)
#      ns0:SetAvailabilityReq(facilityId: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, limitationType: xsd:string, unit: xsd:string, availability: xsd:float, header: ns0:APIRequestHeader)
#      ns0:SetAvailabilityResp(errorCode: ns0:SetAvailabilityErrorEnum, header: ns0:APIResponseHeader)
#      ns0:SetObservationErrorEnum
#      ns0:SetObservationMultiErrorEnum
#      ns0:SetObservationMultiReq(variableId: xsd:string, measurementType: xsd:string, measurementTime: xsd:int, unit: xsd:string, observationType: xsd:string, observationFacilitiesData: ns0:ArrayOfObsfacilitiesdata, header: ns0:APIRequestHeader)
#      ns0:SetObservationMultiResp(errorCode: ns0:SetObservationMultiErrorEnum, header: ns0:APIResponseHeader)
#      ns0:SetObservationReq(facilityId: xsd:string, variableId: xsd:string, measurementType: xsd:string, measurementTime: xsd:int, unit: xsd:string, observationType: xsd:string, observationData: ns0:ArrayOfObsdata, header: ns0:APIRequestHeader)
#      ns0:SetObservationResp(errorCode: ns0:SetObservationErrorEnum, header: ns0:APIResponseHeader)
#      ns0:VnP(facilityId: xsd:string, variableId: xsd:string, predictorId: xsd:string)
#      ns0:getAvailabilityMultiReq(limitationType: xsd:string, fromDate: xsd:dateTime, toDate: xsd:dateTime, unit: xsd:string, facilitiesId: ns0:ArrayOfString, header: ns0:APIRequestHeader)
#      ns0:getAvailabilityMultiResp(errorCode: ns0:GetAvailabilityMultiErrorEnum, facilityAvailabilityData: ns0:ArrayOfFacilitiesavailabilitydata, header: ns0:APIResponseHeader)
#
# Bindings:
#      Soap11Binding: {https://webservice.meteologica.com/apitest/MeteologicaDataExchangeService.php}MeteologicaDataExchangeServiceBinding
#
# Service: MeteologicaDataExchangeServiceService
#      Port: MeteologicaDataExchangeServicePort (Soap11Binding: {https://webservice.meteologica.com/apitest/MeteologicaDataExchangeService.php}MeteologicaDataExchangeServiceBinding)
#          Operations:
#             getAllFacilities(request: ns0:GetAllFacilitiesReq) -> return: ns0:GetAllFacilitiesResp
#             getAllFacilitiesSPE(request: ns0:GetAllFacilitiesSPEReq) -> return: ns0:GetAllFacilitiesSPEResp
#             getAvailabilityMulti(request: ns0:getAvailabilityMultiReq) -> return: ns0:getAvailabilityMultiResp
#             getFacilityForecastedVarSPE(request: ns0:GetFacilityForecastedVarSPEReq) -> return: ns0:GetFacilityForecastedVarSPEResp
#             getFacilityForecastedVnP(request: ns0:GetFacilityForecastedVnPReq) -> return: ns0:GetFacilityForecastedVnPResp
#             getFacilityForecastedVnPEnsemble(request: ns0:GetFacilityForecastedVnPEnsembleReq) -> return: ns0:GetFacilityForecastedVnPEnsembleResp
#             getFacilityOV(request: ns0:GetFacilityOVReq) -> return: ns0:GetFacilityOVResp
#             getForecast(request: ns0:GetForecastReq) -> return: ns0:GetForecastResp
#             getForecastEnsemble(request: ns0:GetForecastEnsembleReq) -> return: ns0:GetForecastEnsembleResp
#             getForecastMulti(request: ns0:GetForecastMultiReq) -> return: ns0:GetForecastMultiResp
#             getForecastSPE(request: ns0:GetForecastSPEReq) -> return: ns0:GetForecastSPEResp
#             keepAlive(request: ns0:KeepAliveReq) -> return: ns0:KeepAliveResp
#             login(request: ns0:LoginReq) -> return: ns0:LoginResp
#             logout(request: ns0:LogoutReq) -> return: ns0:LogoutResp
#             setAvailability(request: ns0:SetAvailabilityReq) -> return: ns0:SetAvailabilityResp
#             setAvailabilityMulti(request: ns0:SetAvailabilityMultiReq) -> return: ns0:SetAvailabilityMultiResp
#             setObservation(request: ns0:SetObservationReq) -> return: ns0:SetObservationResp
#             setObservationMulti(request: ns0:SetObservationMultiReq) -> return: ns0:SetObservationMultiResp

import abc
import typing
from typing import Any

from toolkit.application.events import DomainEvent, DomainEventsMediator
from toolkit.errors import ErrorBase


class Command:
    """
    A command is an order given to the system. A command should be used by an
    application service to fulfill some business rules.
    """

    pass


ServiceResult = typing.Union[list[typing.Any], dict[typing.Any, typing.Any], typing.Any]


class IPresenter(abc.ABC):
    """
    A presenter is useful to output the data from the execution of a service.
    """

    @abc.abstractmethod
    def present(self, value: ServiceResult) -> None:
        pass


class ApplicationService:
    """
    Application Service is where the application business logic is executed.
    The application business logic, is what the application must do to execute
    the business logic in the domain.
    """

    presenter: IPresenter

    def __init__(
        self, *_, domain_event_mediator: DomainEventsMediator, domain_event_class: type[DomainEvent] = DomainEvent, **__
    ):
        self._event_class: type[DomainEvent] = domain_event_class
        self.event: DomainEvent | None = None
        self.domain_event_mediator = domain_event_mediator

    def execute(self, command: Command) -> None:
        self.event = self._event_class()
        self.domain_event_mediator.emit(self.event)


class ErrorNotAService(ErrorBase):
    code: int = 10100


class ErrorUnregisteredService(ErrorBase):
    code: int = 10101


class ErrorAlreadyRegistered(ErrorBase):
    code: int = 10102


_application_service_class_directory: dict[str, type[ApplicationService]] = {}


class ServiceFactory:
    """
    Handles the construction of application services.
    """

    @staticmethod
    def _is_a_service(application_service_class: type[ApplicationService]):
        if not issubclass(application_service_class, ApplicationService):
            raise ErrorNotAService()

    @staticmethod
    def register(application_service_class: type[ApplicationService]):
        """
        Registers a new service to be available for construction in the factory.
        """
        ServiceFactory._is_a_service(application_service_class)

        global _application_service_class_directory
        if _application_service_class_directory.get(str(application_service_class)):
            raise ErrorAlreadyRegistered()
        _application_service_class_directory[str(application_service_class)] = application_service_class

    def build(self, application_service_class: type[ApplicationService], *args, **kwargs) -> Any:
        """
        Builds the requested service and injects the desired arguments.
        """
        self._is_a_service(application_service_class)

        try:
            class_ = _application_service_class_directory[str(application_service_class)]
        except KeyError:
            raise ErrorUnregisteredService() from None

        domain_event_mediator = DomainEventsMediator()

        return class_(*args, domain_event_mediator=domain_event_mediator, **kwargs)

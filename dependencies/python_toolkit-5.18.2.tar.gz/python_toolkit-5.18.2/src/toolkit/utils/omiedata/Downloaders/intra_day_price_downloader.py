import datetime as dt
import os

import requests as req  # type: ignore[import-untyped]

from toolkit.utils.omiedata.Downloaders.omie_downloader import OMIEDownloader


class IntraDayPriceDownloader(OMIEDownloader):
    """Downloader for OMIE Intraday Auction (IDA) price files.

    Since June 14, 2024, OMIE replaced the old 6-session intraday format
    (INT_PIB_EV_H_1_SS_...) with IDA files served per region from:
      https://www.omie.es/en/file-download?parents={parent}&filename={parent}_YYYYMMDDSS.1

    Files are separate per region: ``marginalpibc`` (ES), ``marginalpibcpt`` (PT).
    There are now 3 IDA sessions instead of the former 6.
    """

    _base_url = "https://www.omie.es/en/file-download"
    _PARENT_MAP = {"ES": "marginalpibc", "PT": "marginalpibcpt"}

    def __init__(self, session: int, region: str):
        self.session = session
        self.region = region.upper()
        self.parent = self._PARENT_MAP.get(self.region, "marginalpibc")

    def _build_url(self, target: dt.date) -> str:
        filename = f"{self.parent}_{target.year:04d}{target.month:02d}{target.day:02d}{self.session:02d}.1"
        return f"{self._base_url}?parents={self.parent}&filename={filename}"

    def get_complete_url(self) -> str:
        return self._base_url

    def download_data(self, date_ini: dt.date, date_end: dt.date, output_folder: str, verbose=False) -> int:
        dt_aux = date_ini
        while dt_aux <= date_end:
            url = self._build_url(dt_aux)
            if verbose:
                print(f"Downloading {url} ...")
            response = req.get(url, allow_redirects=True, timeout=10)
            filename = f"PrecioIntra_{self.session}_{self.region}_{dt_aux:%Y%m%d}.txt"
            filepath = os.path.join(output_folder, filename)
            if verbose:
                print(f"Copying to {filepath} ...")
            with open(filepath, "wb") as f:
                f.write(response.content)
            dt_aux += dt.timedelta(days=1)
        return 0

    def url_responses(self, date_ini: dt.date, date_end: dt.date, verbose=False):
        dt_aux = date_ini
        while dt_aux <= date_end:
            url = self._build_url(dt_aux)
            if verbose:
                print(f"Requesting {url} ...")
            yield req.get(url, allow_redirects=True, timeout=10)
            dt_aux += dt.timedelta(days=1)

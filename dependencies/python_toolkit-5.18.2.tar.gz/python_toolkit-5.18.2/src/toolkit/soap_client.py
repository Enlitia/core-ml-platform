"""Base SOAP client for web service interactions.

Provides a simplified base class for creating SOAP clients using the zeep library.
See docs/BaseSOAPClient.md for detailed documentation and examples.
"""

from typing import Any

import defusedxml.ElementTree as ET
from zeep import Client
from zeep.exceptions import Fault

from toolkit.logging import Logger, get_logger


class SOAPException(Exception):
    """Base exception for all SOAP-related errors."""

    def __init__(self, message: str, original: Exception | None = None):
        super().__init__(message)
        self.original = original


class SOAPFaultException(SOAPException):
    """Exception for SOAP fault responses from the service."""

    def __init__(self, message: str, original: Fault | None = None):
        super().__init__(f"SOAP fault: {message}", original)


class SOAPTransportException(SOAPException):
    """Exception for network/transport-level errors."""

    def __init__(self, message: str, original: Exception):
        super().__init__(f"Transport error: {message}", original)


class SOAPRequestError(SOAPFaultException):
    """Generic exception for SOAP request errors (application-level)."""

    def __init__(self, method: str, error_code: str, message: str = ""):
        self.method = method
        self.error_code = error_code
        self.message = message or f"SOAP request '{method}' failed with error code '{error_code}'"
        super().__init__(self.message, None)


class SOAPTransportError(SOAPTransportException):
    """Exception for network/transport-level errors."""

    def __init__(self, method: str, original_exception: Exception):
        self.method = method
        self.original_exception = original_exception
        super().__init__(f"SOAP transport error in '{method}': {original_exception!s}", original_exception)


class BaseSOAPClient:
    """Base class for SOAP service clients.

    Provides a simplified interface for interacting with SOAP web services using
    the zeep library. See docs/BaseSOAPClient.md for detailed usage examples.
    """

    def __init__(self, wsdl_url: str, *, logger: Logger | None = None, **kwargs):
        """Initialize the SOAP client.

        Args:
            wsdl_url: URL to the WSDL file describing the web service
            logger: Optional logger instance for debugging and monitoring
            **kwargs: Additional arguments passed to the underlying zeep.Client
        """
        self.wsdl_url = wsdl_url
        self.logger = logger or get_logger(__name__)
        self._client = Client(wsdl_url, **kwargs)

    @property
    def service(self):
        """Get the default service from the WSDL."""
        return self._client.service

    def handle_soap_exception(self, exc: Exception, method: str) -> Exception:
        """Convert SOAP exceptions to domain-specific exceptions.

        Subclasses can override this method to provide appropriate
        error handling for their specific service domain.

        Args:
            exc: The original exception (Fault for SOAP faults, other for transport errors)
            method: The SOAP method name that was being called

        Returns:
            A domain-specific exception that will be raised instead of the original exception.
        """
        if isinstance(exc, Fault):
            return SOAPFaultException(str(exc), exc)
        else:
            return SOAPTransportException(str(exc), exc)

    def _request(self, method: str, **kwargs) -> Any:
        """Call a SOAP service method with automatic error handling.

        Args:
            method: Name of the SOAP method to call (must exist in the service)
            **kwargs: Keyword arguments to pass to the SOAP method

        Returns:
            The response from the SOAP service (type depends on the method)

        Raises:
            Exception: Domain-specific exception via handle_soap_exception()
        """
        try:
            operation = getattr(self.service, method)
            return operation(**kwargs)
        except Exception as exc:
            raise self.handle_soap_exception(exc, method) from exc

    def _parse_xml_string_to_dict(self, xml_string: str) -> dict[str, Any]:
        """Simple XML to dictionary parser for SOAP service responses.

        Converts XML responses to simple Python dictionaries without any
        field name conversion or type conversion.

        Args:
            xml_string: Raw XML string response from a SOAP service

        Returns:
            Dictionary with 'items' key containing a list of parsed records.

        Raises:
            SOAPFaultException: If the XML cannot be parsed or contains an error
        """
        try:
            root = ET.fromstring(xml_string)

            # Check for <Error> in the response
            error_elem = root.find("Error")
            if error_elem is not None:
                code = error_elem.findtext("Code")
                message = error_elem.findtext("Message")
                raise SOAPFaultException(f"SOAP Error {code}: {message}")

            items = []
            for item in root.findall(".//Item"):
                item_data = {}
                for elem in item:
                    if elem.text is not None:
                        item_data[elem.tag] = elem.text
                if item_data:
                    items.append(item_data)
            return {"items": items}

        except (ET.ParseError, ValueError, AttributeError) as e:
            raise SOAPFaultException(f"Failed to parse XML response: {e}", None) from e

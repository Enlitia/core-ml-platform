from dataclasses import asdict, dataclass
from datetime import datetime
from enum import StrEnum
from typing import Any

import httpx

from toolkit.http_client import BaseHTTPClient, HTTPAPIError, HTTPRequestError
from toolkit.logging import HTTPClientLabels, Logger


class WeatherHubError(Exception):
    """Base exception for Weather Hub API client errors."""

    pass


class WeatherHubValidationError(WeatherHubError):
    """Exception for input validation errors."""

    pass


class WeatherHubEndpoint(StrEnum):
    """Available Weather Hub API endpoints."""

    CLIENT = "client"
    LOCATION = "location"
    WEATHER_FORECAST = "weather_forecast"
    OBSERVATIONS = "observations"


@dataclass
class WeatherHubParams:
    """Parameters for weather forecast requests.

    Args:
        external_id: External location ID - must be non-empty string
        start_hour: Start date/time (YYYY-MM-DD or YYYY-MM-DDTHH:MM)
        end_hour: End date/time (YYYY-MM-DD or YYYY-MM-DDTHH:MM)
        model: Optional weather model name
        variables: Optional comma-separated weather variables

    Raises:
        WeatherHubValidationError: If any parameter is invalid
    """

    external_id: str
    start_hour: str
    end_hour: str
    model: str | None = None
    variables: str | None = None

    def __post_init__(self) -> None:
        """Validate parameters after initialization."""
        if not self.external_id:
            raise WeatherHubValidationError("external_id must be a non-empty string")
        if not self.start_hour:
            raise WeatherHubValidationError("start_hour must be a non-empty string")
        if not self.end_hour:
            raise WeatherHubValidationError("end_hour must be a non-empty string")
        if self.model and not isinstance(self.model, str):
            raise WeatherHubValidationError("model must be a string")
        if self.variables and not isinstance(self.variables, str):
            raise WeatherHubValidationError("variables must be a string")

        start_dt = self._parse_datetime(self.start_hour, "start_hour")
        end_dt = self._parse_datetime(self.end_hour, "end_hour")

        if start_dt >= end_dt:
            raise WeatherHubValidationError("start_hour must be before end_hour")

    def _parse_datetime(self, value: str, field_name: str) -> datetime:
        """Parse datetime string."""
        formats = ["%Y-%m-%d", "%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S"]

        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            pass

        for fmt in formats:
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue

        raise WeatherHubValidationError(
            f"{field_name} must be a valid datetime format (YYYY-MM-DD, YYYY-MM-DDTHH:MM, or ISO 8601)"
        )


class WeatherHubClient(BaseHTTPClient):
    """Weather Hub API client for fetching weather data.

    Example:
        client = WeatherHubClient(base_url="...", username="...", password="...")

        params = WeatherHubParams(
            external_id="location-123",
            start_hour="2025-11-25",
            end_hour="2025-11-26",
        )

        result = client.fetch(WeatherHubEndpoint.WEATHER_FORECAST, params)
    """

    API_VERSION = "api/1"

    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        logger: Logger | None = None,
        **kwargs,
    ):
        """Initialize Weather Hub API client.

        Args:
            base_url: Base URL for Weather Hub API
            username: Username for authentication
            password: Password for authentication
            logger: Optional logger instance
            **kwargs: Additional HTTP client configuration
        """
        self._username = username
        self._password = password
        self._api_key: str | None = None

        super().__init__(base_url, logger, **kwargs)

        self._login()

    @property
    def _default_headers(self) -> dict[str, str]:
        """Default headers for requests."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if self._api_key:
            headers["X-API-Key"] = self._api_key
        return headers

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to Weather Hub specific exceptions."""
        return HTTPAPIError(
            status_code=exc.response.status_code,
            url=self.base_url,
            message=f"Weather Hub API request failed: {exc!s} with response: {exc.response.json()}",
        )

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to Weather Hub specific exceptions."""
        return HTTPRequestError(
            message=f"Weather Hub API request failed: {exc!s}",
            original_exception=exc,
        )

    def _login(self) -> None:
        """Authenticate with Weather Hub API and store API key."""
        payload = {"username": self._username, "password": self._password}

        result = self.post("auth/login", json=payload)
        self._api_key = result["api_key"]
        if self._client:
            self._client.headers["X-API-Key"] = self._api_key

        self.logger.info(
            "auth completed",
            action=HTTPClientLabels.AUTH.completed,
            step=HTTPClientLabels.AUTH,
        )

    def _ensure_authenticated(self) -> None:
        """Ensure client is authenticated, re-login if needed."""
        if not self._api_key:
            self._login()

    def fetch(self, endpoint: WeatherHubEndpoint, params: WeatherHubParams | None = None) -> dict[str, Any]:
        """Fetch data from an endpoint.

        Args:
            endpoint: API endpoint from WeatherHubEndpoint enum
            params: Validated WeatherHubParams dataclass

        Returns:
            API response data

        Raises:
            WeatherHubValidationError: If parameters are invalid
            HTTPAPIError: If the API returns an error response
            HTTPRequestError: If there's a problem making the request
        """

        self._ensure_authenticated()

        path = f"{self.API_VERSION}/{endpoint.value}"

        params_dict = {} if params is None else {k: v for k, v in asdict(params).items() if v is not None}

        result = self.get(path, params=params_dict)

        return result

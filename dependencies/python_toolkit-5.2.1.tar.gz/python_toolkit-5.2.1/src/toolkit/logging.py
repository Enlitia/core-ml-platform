import json
import logging
from typing import Any, Dict, Mapping, Optional


class JsonFormatter(logging.Formatter):
    """
    A logging formatter that outputs log records as JSON objects.

    Includes standard log fields (level, message, name, time) and,
    if present, 'project', 'service', and any extra fields.
    """

    def format(self, record: logging.LogRecord) -> str:
        log_record = {
            "level": record.levelname,
            "message": record.getMessage(),
            "name": record.name,
            "time": self.formatTime(record, self.datefmt),
        }

        for key in ("project", "service"):
            if hasattr(record, key):
                log_record[key] = getattr(record, key)

        extras = getattr(record, "__extra__", {})
        log_record.update(extras)

        return json.dumps(log_record)


class TextFormatter(logging.Formatter):
    """
    A logging formatter that outputs log records as formatted text.

    If the format string contains '%(extras)', extra fields are joined and included in the output.
    """

    def __init__(self, fmt: str, datefmt: str):
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.includes_extras = "%(extras)" in fmt if fmt else False

    def format(self, record: logging.LogRecord) -> str:
        if self.includes_extras:
            extras = getattr(record, "__extra__", {})
            # Only use the values, join them
            record.extras = " | ".join(str(v) for v in extras.values()) if extras else ""
        else:
            record.extras = ""
        return super().format(record)


class StructuredLogger:
    """
    Structured logger utility for consistent log formatting.

    Provides logging methods (info, debug, warning, error, critical, exception) that output logs
    with project and service context, and optional extra fields, using either text or JSON format.
    Can be used with standard Python loggers or Prefect loggers.

    Supports creating child loggers with additional default extra fields via `spawn`.
    """

    def __init__(
        self,
        name: str,
        project: str,
        service: str,
        extra_defaults: Optional[Dict[str, Any]] = None,
        config: Optional[Dict[str, Any]] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize a StructuredLogger.

        Args:
            name: Name for the logger (required).
            project: Project name to include in logs.
            service: Service name to include in logs.
            extra_defaults: Optional dictionary of extra default fields to include in logs.
            config: Optional dict for logging configuration (format, datefmt, level, format_type).
            logger: Optional pre-configured logger instance.

        Raises:
            ValueError: If name is empty.
        """
        if name is None or name == "":
            raise ValueError("Name is required. Please provide a logger name.")

        if config is None or not isinstance(config, dict):
            config = {}

        self._name = name
        self._project = project
        self._service = service
        self._base_logger = logger or logging.getLogger(name)

        self._config = config.copy() if config else {}
        self._level = self._config.get("level", logging.INFO)
        self._formatter = self._create_formatter()

        self._configure_handlers()

        context: Dict[str, Any] = {"project": self._project, "service": self._service}
        if extra_defaults:
            context["__extra__"] = extra_defaults
            context.update(extra_defaults)

        self._context = context

        self._logger = self._base_logger

    @property
    def context(self) -> Dict[str, Any]:
        """
        Get the current context of the logger.

        Returns:
            A dictionary containing the logger's context.
        """
        return self._context

    @property
    def extra_defaults(self) -> Dict[str, Any]:
        """
        Get the default extra fields for this logger.

        Returns:
            A dictionary of default extra fields.
        """
        val = self._context.get("__extra__", {})
        return val if isinstance(val, dict) else {}

    @property
    def logger(self) -> logging.Logger:
        """
        Get the underlying logger instance.

        Returns:
            The configured logging.Logger instance.
        """
        return self._logger

    def _configure_handlers(self) -> None:
        """
        Configure logging handlers and formatters for the base logger.
        """
        if not self._base_logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(self._formatter)
            handler.setLevel(self._level)
            self._base_logger.addHandler(handler)
        else:
            for h in self._base_logger.handlers:
                h.setFormatter(self._formatter)
                h.setLevel(self._level)

        self._base_logger.setLevel(self._level)
        self._base_logger.propagate = False

    def _create_formatter(self) -> logging.Formatter:
        """
        Create a logging formatter based on configuration.

        Returns:
            Configured logging.Formatter instance.
        """
        fmt_type = self._config.get("format_type", "text").lower()
        datefmt = self._config.get("datefmt", "%Y-%m-%d %H:%M:%S")

        if fmt_type == "json":
            return JsonFormatter(datefmt=datefmt)
        else:
            fmt = self._config.get(
                "format", "%(asctime)s | %(levelname)s | %(project)s | %(service)s | %(extras)s | %(message)s"
            )
            return TextFormatter(fmt=fmt, datefmt=datefmt)

    def _log(self, level: int, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs) -> None:
        """
        Internal method to log a message at a specified level with optional extra fields.

        Args:
            level: Logging level (e.g., logging.INFO).
            message: Log message (supports formatting).
            *args: Arguments for message formatting.
            extra: Optional mapping of extra fields to include in the log.
            **kwargs: Additional keyword arguments for the logger.
        """

        # merge context and extra fields
        log_extras = {**self.context, "__extra__": {**self.extra_defaults, **(extra or {})}}

        self._logger.log(level, message, *args, extra=log_extras, **kwargs)

    def info(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        self._log(logging.INFO, message, *args, extra=extra, **kwargs)

    def debug(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        self._log(logging.DEBUG, message, *args, extra=extra, **kwargs)

    def warning(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        self._log(logging.WARNING, message, *args, extra=extra, **kwargs)

    def error(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        self._log(logging.ERROR, message, *args, extra=extra, **kwargs)

    def critical(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        self._log(logging.CRITICAL, message, *args, extra=extra, **kwargs)

    def exception(self, message: str, *args, extra: Optional[Mapping[str, object]] = None, **kwargs):
        kwargs.setdefault("exc_info", True)
        self._log(logging.ERROR, message, *args, extra=extra, **kwargs)

    def spawn(
        self,
        *,
        extra_defaults: Optional[Dict[str, Any]] = None,
    ) -> "StructuredLogger":
        """
        Create a child StructuredLogger with the same configuration but potentially different extra default fields.

        Args:
            extra_defaults: Optional dictionary of extra default fields to include in the child logger.

        Returns:
            StructuredLogger: A new StructuredLogger instance with updated extra defaults.
        """
        current_extra_defaults = self.extra_defaults.copy()
        if extra_defaults:
            current_extra_defaults.update(extra_defaults)

        return StructuredLogger(
            name=self._name,
            project=self._project,
            service=self._service,
            extra_defaults=current_extra_defaults,
            config=self._config.copy(),
            logger=self._base_logger,
        )

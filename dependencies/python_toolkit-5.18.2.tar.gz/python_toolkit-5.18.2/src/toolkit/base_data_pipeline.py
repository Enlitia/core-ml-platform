import abc
from typing import Any

from toolkit.application.services import ApplicationService
from toolkit.logging import LoggingLabels


class BaseDataPipeline(ApplicationService, abc.ABC):
    """Abstract base class for 3-step data pipelines (import or export).

    Provides the shared ``_run_step`` helper that wraps each pipeline stage
    with structured lifecycle logging (started / completed / no_data).

    Subclasses must define three abstract methods for their domain-specific
    steps and implement ``execute`` to wire them together with the
    appropriate labels.

    See Also:
        ``BaseDataImporter`` — fetch → process → store
        ``BaseDataExporter`` — load → process → export
    """

    def __init__(self, logger, *args, **kwargs):
        """
        Args:
            logger: Pre-configured logger (should be a ``Logger`` instance).
        """
        super().__init__(*args, **kwargs)
        self._logger = logger

    def _run_step(self, label: LoggingLabels, func, *args) -> list[Any] | None:
        """Run a pipeline step with lifecycle logging.

        Logs ``started`` / ``completed`` / ``no_data`` for the given step label.

        Three outcomes:

        * ``result is None`` → void step (e.g. ``_store`` / ``_export``).
          Logs **completed** with ``record_count`` from the input when available.
        * ``result`` is an empty sequence → step found no data.
          Logs **no_data** as a warning.
        * otherwise → step produced records.  Logs **completed** with
          ``record_count`` from the output.

        Returns:
            The step result, or ``None`` when the step produced no data.
        """
        self._logger.info(f"{label} started", action=label.started)
        result = func(*args)

        if result is None:
            log_kwargs: dict[str, Any] = {"action": label.completed}
            if args:
                log_kwargs["record_count"] = len(args[0])
            self._logger.info(f"{label} completed", **log_kwargs)
            return None

        if hasattr(result, "__len__") and len(result) == 0:
            self._logger.warning(
                f"{label} returned no data",
                action=label.no_data,
            )
            return None

        self._logger.info(
            f"{label} completed",
            action=label.completed,
            record_count=len(result),
        )
        return result

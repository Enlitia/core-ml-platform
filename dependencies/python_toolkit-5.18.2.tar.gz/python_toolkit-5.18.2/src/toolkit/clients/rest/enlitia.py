"""Enlitia API client for market price and power forecast data.

This module provides a client for accessing forecast data from the Enlitia API,
specifically for market price forecasts and asset power forecasts.

Classes:
    - ForecastParams: Base parameters for market price forecasts
    - PowerForecastParams: Extended parameters for power forecasts (adds percentile)
    - EnlitiaClient: HTTP client for Enlitia API

See docs/EnlitiaClient.md for comprehensive documentation, usage examples,
and best practices.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import httpx

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import Logger, get_logger

logger = get_logger(__name__)


class EnlitiaError(Exception):
    """Base exception for Enlitia API client errors."""

    pass


class EnlitiaAPIError(EnlitiaError):
    """Exception raised when Enlitia API returns an error response."""

    def __init__(self, error_dict: dict[str, Any]):
        self.error_dict = error_dict
        self.status_code = error_dict.get("statusCode", error_dict.get("error_code", 0))
        super().__init__(str(error_dict))


class EnlitiaRequestError(EnlitiaError):
    """Exception raised when there's a problem making the request to Enlitia API."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class EnlitiaValidationError(EnlitiaError):
    """Exception for input validation errors."""

    pass


@dataclass
class ForecastParams:
    """Base forecast request parameters with validation (for Market Price Forecasts).

    Args:
        planner_id: Market ID - must be positive integer
        start_date: Start date in ISO format (e.g., 2025-09-09T18:00:00.000Z) - non-empty string
        end_date: End date in ISO format (e.g., 2025-09-10T18:00:00.000Z) - non-empty string
        provider_ids: List of provider IDs - non-empty list of positive integers

    Raises:
        EnlitiaValidationError: If any parameter is invalid
    """

    planner_id: int
    start_date: str
    end_date: str
    provider_ids: list[int]

    def __post_init__(self) -> None:
        """Validate forecast request parameters after initialization.

        Validates planner_id is positive integer, dates are non-empty strings,
        provider_ids is non-empty list of positive integers, and date range is
        valid ISO format with start < end.

        Raises:
            EnlitiaValidationError: If any parameter is invalid
        """
        self._validate_basic_params()
        self._validate_date_range()

    def _validate_basic_params(self) -> None:
        """Validate basic forecast parameters.

        Checks:
        - planner_id is an integer and greater than 0
        - start_date is a non-empty string
        - end_date is a non-empty string
        - provider_ids is a non-empty list
        - all provider_ids are positive integers

        Raises:
            EnlitiaValidationError: If any basic parameter is invalid
        """
        if not isinstance(self.planner_id, int) or self.planner_id <= 0:
            raise EnlitiaValidationError("planner_id must be a positive integer")

        if not self.start_date or not isinstance(self.start_date, str):
            raise EnlitiaValidationError("start_date must be a non-empty string")

        if not self.end_date or not isinstance(self.end_date, str):
            raise EnlitiaValidationError("end_date must be a non-empty string")

        if not isinstance(self.provider_ids, list) or not self.provider_ids:
            raise EnlitiaValidationError("provider_ids must be a non-empty list")

        if not all(isinstance(pid, int) and pid > 0 for pid in self.provider_ids):
            raise EnlitiaValidationError("all provider_ids must be positive integers")

    def _validate_date_range(self) -> None:
        """Validate date format and range.

        Checks:
        - start_date is valid ISO 8601 format with timezone (e.g., 2025-09-09T18:00:00.000Z)
        - end_date is valid ISO 8601 format with timezone (e.g., 2025-09-10T18:00:00.000Z)
        - start_date is before end_date (start_date < end_date)

        Raises:
            EnlitiaValidationError: If dates are invalid format or start_date >= end_date
        """
        try:
            start_dt = datetime.fromisoformat(self.start_date.replace("Z", "+00:00"))
            end_dt = datetime.fromisoformat(self.end_date.replace("Z", "+00:00"))

            if start_dt >= end_dt:
                raise EnlitiaValidationError("start_date must be before end_date")

        except ValueError as e:
            raise EnlitiaValidationError(
                f"Invalid datetime format. Use ISO format with timezone (e.g., 2025-10-09T00:00:00.000Z): {e}"
            ) from e


@dataclass
class PowerForecastParams(ForecastParams):
    """Power forecast request parameters with percentile validation (for Asset Power Forecasts).

    Extends ForecastParams with required percentile field for power forecasts.

    Args:
        planner_id: Asset ID - must be positive integer
        start_date: Start date in ISO format (e.g., 2025-10-09T00:00:00.000Z) - non-empty string
        end_date: End date in ISO format (e.g., 2025-10-10T23:00:00.000Z) - non-empty string
        provider_ids: List of provider IDs - non-empty list of positive integers
        percentile: List of percentile values - non-empty list of integers divisible by 10 (0, 10, 20, ..., 90, 100)

    Raises:
        EnlitiaValidationError: If any parameter is invalid
    """

    percentile: list[int]

    def __post_init__(self) -> None:
        """Validate power forecast request parameters after initialization.

        Validates all base parameters plus percentile values.

        Raises:
            EnlitiaValidationError: If any parameter is invalid
        """
        super().__post_init__()
        self._validate_percentile()

    def _validate_percentile(self) -> None:
        """Validate percentile parameter for power forecast.

        Checks:
        - percentile is a non-empty list
        - all percentile values are integers
        - all percentile values are between 0 and 100 (inclusive)
        - all percentile values are divisible by 10 (0, 10, 20, ..., 90, 100)

        Raises:
            EnlitiaValidationError: If percentile is invalid
        """
        if not isinstance(self.percentile, list) or not self.percentile:
            raise EnlitiaValidationError("percentile must be a non-empty list")

        if not all(isinstance(p, int) and 0 <= p <= 100 for p in self.percentile):
            raise EnlitiaValidationError("all percentile values must be integers between 0 and 100")

        if not all(p % 10 == 0 for p in self.percentile):
            raise EnlitiaValidationError("all percentile values must be divisible by 10 (0, 10, 20, ..., 90, 100)")


class EnlitiaClient(BearerTokenHTTPClient):
    """HTTP client for Enlitia API forecast data.

    Provides access to market price and power forecast data through the Enlitia API.
    Use ForecastParams for market forecasts and PowerForecastParams for power forecasts.

    Args:
        base_url: Base URL for the Enlitia API (e.g., "https://connect.app.enlitia.com/v1")
        token: API authentication token
        logger: Optional logger instance
        **kwargs: Additional HTTP client configuration
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the Enlitia API client."""
        self._logger = logger or get_logger(__name__)
        super().__init__(base_url, token, logger=self._logger, **kwargs)

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP status errors to domain-specific exceptions."""
        import json

        try:
            response_body = exc.response.text
            # Try to parse JSON response
            error_dict = json.loads(response_body) if response_body else {}
        except (json.JSONDecodeError, Exception):
            # If JSON parsing fails, create a simple error dict
            error_dict = {
                "statusCode": exc.response.status_code,
                "message": exc.response.text if hasattr(exc.response, "text") else f"HTTP {exc.response.status_code}",
            }

        # Ensure statusCode is in the dict
        if "statusCode" not in error_dict and "error_code" not in error_dict:
            error_dict["statusCode"] = exc.response.status_code

        return EnlitiaAPIError(error_dict)

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to domain-specific exceptions."""
        return EnlitiaRequestError(str(exc), exc)

    def get_market_price_forecast_data(self, params: ForecastParams, **kwargs) -> dict[str, Any]:
        """Get market price forecast data for a planner (Market ID).

        Args:
            params: ForecastParams with validated parameters (planner_id is Market ID)
            **kwargs: Additional query parameters

        Returns:
            Dictionary containing market price forecast data

        Raises:
            EnlitiaAPIError: If the API returns an error response
            EnlitiaRequestError: If there's a problem making the request
        """
        self._logger.info(
            "Retrieving market price forecast data for planner %d from %s to %s with providers %s",
            params.planner_id,
            params.start_date,
            params.end_date,
            params.provider_ids,
        )

        query_params = {
            "startDate": params.start_date,
            "endDate": params.end_date,
            "providerIds": ",".join(map(str, params.provider_ids)),
            **kwargs,
        }

        response_data = self.get(f"/planner/{params.planner_id}/marketPriceForecast", params=query_params)

        self._logger.debug(
            "Market price forecast data retrieved for planner: %d (%d records)",
            params.planner_id,
            len(response_data.get("values", [])),
        )
        return response_data

    def get_power_forecast_data(
        self, params: PowerForecastParams, historical: bool = False, **kwargs
    ) -> dict[str, Any]:
        """Get power forecast data for a planner (Asset ID).

        Args:
            params: PowerForecastParams with validated parameters including percentile (planner_id is Asset ID)
            historical: If True, retrieves historical forecast data.
                If False (default), retrieves current forecast data.
            **kwargs: Additional query parameters

        Returns:
            Dictionary containing power forecast data

        Raises:
            EnlitiaAPIError: If the API returns an error response
            EnlitiaRequestError: If there's a problem making the request
        """
        forecast_type = "historical power" if historical else "power"

        self._logger.info(
            "Retrieving %s forecast data for planner %d from %s to %s with providers %s and percentiles %s",
            forecast_type,
            params.planner_id,
            params.start_date,
            params.end_date,
            params.provider_ids,
            params.percentile,
        )

        query_params = {
            "startDate": params.start_date,
            "endDate": params.end_date,
            "providerIds": ",".join(map(str, params.provider_ids)),
            "percentile": ",".join(map(str, params.percentile)),
            **kwargs,
        }

        # Build endpoint path
        endpoint = f"/planner/{params.planner_id}/powerForecast"
        if historical:
            endpoint += "/historical"

        response_data = self.get(endpoint, params=query_params)

        self._logger.debug(
            "%s forecast data retrieved for planner: %d (%d records)",
            forecast_type.capitalize(),
            params.planner_id,
            len(response_data.get("values", [])),
        )
        return response_data

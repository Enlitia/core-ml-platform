from toolkit.database import DataModelBase


class SQLAlchemyDataModel:
    def to_dict(self) -> dict:
        return {col.name: getattr(self, col.name) for col in self.__table__.columns}  # type: ignore


class SQLDataModel(SQLAlchemyDataModel, DataModelBase):
    __abstract__ = True

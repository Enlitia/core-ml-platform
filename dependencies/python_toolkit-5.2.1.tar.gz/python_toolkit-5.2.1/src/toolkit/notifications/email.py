from dataclasses import dataclass
from email.message import EmailMessage
from smtplib import SMTP, SMTPException
from typing import List, Optional


@dataclass
class EmailConfig:
    host: str
    username: str
    password: str
    port: Optional[int] = 587
    default_sender: Optional[str] = None
    default_subject: Optional[str] = None
    default_recipients: Optional[List[str]] = None


class Email:
    def __init__(self, config: EmailConfig) -> None:
        try:
            smtp = SMTP(host=config.host, port=config.port, timeout=120)  # type: ignore
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(config.username, config.password)

            self._smtp = smtp

            self._default_sender = config.default_sender
            self._default_subject = config.default_subject
            self._default_recipients = config.default_recipients
        except SMTPException as e:
            raise e

    def send(
        self,
        message: str,
        recipients: Optional[List[str]] = None,
        subject: Optional[str] = None,
        sender: Optional[str] = None,
    ):
        if not sender:
            sender = self._default_sender
        if not subject:
            subject = self._default_subject
        if not recipients:
            recipients = self._default_recipients

        try:
            msg = EmailMessage()
            msg.set_content(message)
            msg["Subject"] = subject
            msg["From"] = sender
            msg["To"] = ", ".join(recipients)  # type: ignore

            self._smtp.send_message(msg)

            return True
        except Exception as e:
            raise ValueError(e)

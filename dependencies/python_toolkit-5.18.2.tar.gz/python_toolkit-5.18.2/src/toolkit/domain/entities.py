from toolkit.errors import ErrorDomain


class ErrorNotAnEntity(ErrorDomain):
    message: str = "Error, object is not an entity"


class ErrorNotRegistered(ErrorDomain):
    message: str = "Error, cannot create an instance for an unknown entity"


class Entity:
    """
    An object defined not by its attributes, but its identity.

    Example, each seat in a theater is unique, it doesn't matter who sits in it
    the seat will always be the same.
    """

    def __init__(self, entity_id: int = 0):
        self._id = entity_id

    @property
    def id(self) -> int:
        if not self._id:
            raise ValueError(f"Entity {self} does not have an ID")

        return self._id

    @id.setter
    def id(self, value: int) -> None:
        if self._id:
            raise ValueError(f"Entity {self} already has an ID")

        if not value:
            raise ValueError("Cannot defined entity ID less than 1")

        self._id = value

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}(entity_id={self._id})"


_entity_directory = {}


class EntityFactory:
    """
    Handles the construction of entities.
    """

    @staticmethod
    def register(entity: type[Entity]):
        """
        Registers a new entity to be available for construction in the factory.
        """
        EntityFactory._check_is_subclass_of_entity(entity)

        global _entity_directory
        _entity_directory[str(entity)] = entity

    @staticmethod
    def build(entity: type[Entity], *args, **kwargs):
        """
        Builds the requested entity and injects the desired arguments.
        """
        EntityFactory._check_is_subclass_of_entity(entity)

        try:
            entity = _entity_directory[str(entity)]
        except KeyError:
            raise ErrorNotRegistered() from None

        if "entity_id" in kwargs:
            # The id of an Entity is a detail of the infrastructure.
            # While, it is true that the architecture does not yet abstract
            # this detail, we must prevent the definition of the id using the
            # factory
            raise Exception("The entity id cannot be defined by a factory")

        return entity(*args, **kwargs)

    @staticmethod
    def _check_is_subclass_of_entity(entity):
        if not issubclass(entity, Entity):
            raise ErrorNotAnEntity()

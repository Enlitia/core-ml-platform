"""Axpo REST client.

Provides a client for accessing Axpo API endpoints for power forecast data
and other energy market information.

This module provides a client for interacting with the Axpo API, which offers
access to power forecast data, timeseries information, and other energy market
data through REST endpoints. The client uses OAuth2 password grant authentication
with Basic Auth credentials.

See docs/clients/rest/AxpoClient.md for usage examples.
"""

import decimal
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Any, Final, Literal
from urllib.parse import quote

import httpx
import pytz

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import HTTPClientLabels, Logger, get_logger

logger = get_logger(__name__)

# Axpo API timezone requirement - all datetime parameters must be in Europe/Madrid timezone
AXPO_TIMEZONE = pytz.timezone("Europe/Madrid")


class TimeSeriesType(StrEnum):
    """Axpo timeseries types.

    Each timeseries type has corresponding subtype enums that are valid only for that type:
    - FORECAST → uses ForecastSubType enum (e.g., ForecastSubType.FINAL)
    - INCCLIENTPROGRAMBREAKDOWN → uses AxpoMarket enum (e.g., AxpoMarket.MD, AxpoMarket.MI1, etc.)
    - FINALFORECASTBREAKDOWN → uses AxpoMarket enum (e.g., AxpoMarket.MD, AxpoMarket.MI1, etc.)
    """

    FORECAST = "FORECAST"
    INCCLIENTPROGRAMBREAKDOWN = "INCCLIENTPROGRAMBREAKDOWN"
    FINALFORECASTBREAKDOWN = "FINALFORECASTBREAKDOWN"


class ForecastSubType(StrEnum):
    """Axpo forecast subtypes.

    Valid subtypes when type=TimeSeriesType.FORECAST.
    Used in the GET timeseries endpoint path: /timeseries/{FORECAST}/{subtype}/...
    """

    FINAL = "final"


class EntityType(StrEnum):
    """Axpo entity types."""

    UFI = "UFI"


class AxpoMarket(StrEnum):
    """Axpo market codes.

    Valid subtypes when type=TimeSeriesType.INCCLIENTPROGRAMBREAKDOWN.
    Used in the GET timeseries endpoint path: /timeseries/{INCCLIENTPROGRAMBREAKDOWN}/{market}/...
    """

    MD = "MD"  # Day-ahead market (Mercado Diário)
    MI1 = "MI1"  # Intraday market session 1
    MI2 = "MI2"  # Intraday market session 2
    MI3 = "MI3"  # Intraday market session 3
    MFRR_PT = "mFRR_PT"  # Tertiary reserve (manual Frequency Restoration Reserve)
    RT1 = "RT1"  # Real-time adjustment 1
    RT2 = "RT2"  # Real-time adjustment 2

    @classmethod
    def to_list(cls) -> list[str]:
        """Return a list of all market code values."""
        return [market.value for market in cls]

    @classmethod
    def all_markets(cls) -> list["AxpoMarket"]:
        """Return a list of all AxpoMarket enum members for iteration."""
        return list(cls)


# Mapping from each TimeSeriesType to its valid subtype enum class.
# To add a new timeseries type, add one entry here.
MAPPING_TYPE_TO_SUBTYPE: dict[TimeSeriesType, type] = {
    TimeSeriesType.FORECAST: ForecastSubType,
    TimeSeriesType.INCCLIENTPROGRAMBREAKDOWN: AxpoMarket,
    TimeSeriesType.FINALFORECASTBREAKDOWN: AxpoMarket,
}


class AxpoRequestEndpoints(StrEnum):
    """Axpo POST endpoint paths."""

    FORECAST = "forecast"
    AVAILABILITY = "availability"


@dataclass
class AxpoRequestParams(ABC):
    """Base query parameters for POST forecast and POST availability.

    Common query parameters: localDate (YYYY-MM-DD), ufiCode (installation code).
    Subclasses define the abstract "type" field.

    Differences:
    - Forecast: type="original" (fixed), source="client"
    - Availability: type="percentage" or "MWh" (user defines), no source

    Use AxpoForecastRequestParams for post_forecast; use AxpoAvailabilityRequestParams for post_availability.
    """

    localDate: str
    ufiCode: str

    def __post_init__(self) -> None:
        if not self.localDate or not isinstance(self.localDate, str):
            raise AxpoValidationError("localDate must be a non-empty string")
        try:
            datetime.strptime(self.localDate, "%Y-%m-%d")
        except ValueError:
            raise AxpoValidationError("localDate must be in YYYY-MM-DD format") from None
        if not self.ufiCode or not isinstance(self.ufiCode, str):
            raise AxpoValidationError("ufiCode must be a non-empty string")

    @abstractmethod
    def to_query_params(self) -> dict[str, str]:
        """Build query parameters dict. Subclasses define the full dict including 'type'."""
        ...


@dataclass
class AxpoForecastRequestParams(AxpoRequestParams):
    """Query parameters for POST forecast."""

    type: Final[str] = "original"
    source: Final[str] = "client"

    def to_query_params(self) -> dict[str, str]:
        return {
            "localDate": self.localDate,
            "type": self.type,
            "source": self.source,
            "ufiCode": self.ufiCode,
        }


@dataclass
class AxpoAvailabilityRequestParams(AxpoRequestParams):
    """Query parameters for POST availability.

    Difference from forecast: type is "percentage" (default) or "MWh", no source.
    - percentage: availability expressed as a percentage
    - MWh: availability expressed as a limit in MWh
    """

    type: Literal["percentage", "MWh"] = "percentage"

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.type not in ("percentage", "MWh"):
            raise AxpoValidationError("type must be 'percentage' or 'MWh'")

    def to_query_params(self) -> dict[str, str]:
        return {
            "localDate": self.localDate,
            "type": self.type,
            "ufiCode": self.ufiCode,
        }


@dataclass
class AxpoRequestBody:
    """Request body for POST forecast and POST availability.

    Same structure for both endpoints. timePeriodType must be "fourthhour";
    v must have 92, 96, or 100 quarter-hourly values (float or None).

    Args:
        timePeriodType: Time resolution; must be "fourthhour" (default).
        v: Array of 92, 96, or 100 values (percentage 0-1 or MWh; values can be null).

    Raises:
        AxpoValidationError: If timePeriodType is not "fourthhour", v length is invalid,
            or any element is not a number or None.
    """

    v: list[float | None]
    timePeriodType: str = "fourthhour"

    def __post_init__(self) -> None:
        if self.timePeriodType != "fourthhour":
            raise AxpoValidationError("timePeriodType must be 'fourthhour'")
        if len(self.v) not in (92, 96, 100):
            raise AxpoValidationError("v must have 92, 96, or 100 elements")
        for i, x in enumerate(self.v):
            if x is not None and not isinstance(x, (int, float, decimal.Decimal)):
                raise AxpoValidationError(f"v[{i}] must be a number or None")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON request body."""
        return {"timePeriodType": self.timePeriodType, "v": self.v}


@dataclass
class AxpoTimeseriesParam:
    """Parameters for _get_timeseries_data.

    Holds timeseries type, subtype, entity, resolution and date range.
    The date range (end_date - start_date) must not exceed 1 day.

    IMPORTANT: The subtype depends on the type:
    - If timeseries_type=FORECAST, then timeseries_subtype must be a ForecastSubType value
    - If timeseries_type=INCCLIENTPROGRAMBREAKDOWN, then timeseries_subtype must be an AxpoMarket value
    - If timeseries_type=FINALFORECASTBREAKDOWN, then timeseries_subtype must be an AxpoMarket value

    Args:
        timeseries_type: Type of the timeseries (TimeSeriesType enum)
        timeseries_subtype: Subtype that corresponds to the type (ForecastSubType or AxpoMarket)
        entity_type: Entity type of the timeseries (EntityType enum)
        entity_id: Entity ID of the timeseries (e.g., UFI code)
        resolution_id: Resolution ("quarterly" or "hourly")
        start_date: Start datetime (YYYY-MM-DDThh:mm:ss format)
        end_date: End datetime (YYYY-MM-DDThh:mm:ss format)
    """

    timeseries_type: TimeSeriesType
    timeseries_subtype: ForecastSubType | AxpoMarket
    entity_type: EntityType
    entity_id: str
    resolution_id: str
    start_date: datetime
    end_date: datetime

    def __post_init__(self) -> None:
        if self.resolution_id not in ("quarterly", "hourly"):
            raise AxpoValidationError(f"resolution_id must be 'quarterly' or 'hourly', got '{self.resolution_id}'")

        # Check if datetimes are timezone-aware (before comparing, to avoid TypeError)
        if self.start_date.tzinfo is None or self.end_date.tzinfo is None:
            raise AxpoValidationError("start_date and end_date must be timezone-aware")

        if self.start_date > self.end_date:
            raise AxpoValidationError("start_date must be before or equal to end_date")

        # Convert to Europe/Madrid timezone and then make naive for API request
        # AXPO API expects datetime in Madrid timezone but as naive datetime
        # Always convert to ensure correct timezone, then strip timezone info
        self.start_date = self.start_date.astimezone(AXPO_TIMEZONE).replace(tzinfo=None)
        self.end_date = self.end_date.astimezone(AXPO_TIMEZONE).replace(tzinfo=None)

        # Validate type-subtype relationship
        expected_subtype = MAPPING_TYPE_TO_SUBTYPE.get(self.timeseries_type)
        if expected_subtype is None:
            raise AxpoValidationError(f"Unknown timeseries_type: {self.timeseries_type}")
        if not isinstance(self.timeseries_subtype, expected_subtype):
            raise AxpoValidationError(
                f"timeseries_subtype must be one of {expected_subtype.__name__} enum values "
                f"for timeseries_type {self.timeseries_type}"
            )


@dataclass
class AxpoFinalPowerForecastParams(AxpoTimeseriesParam):
    """Parameters for get_final_power_forecast.

    Extends AxpoTimeseriesParam with fixed timeseries_type=FORECAST and
    timeseries_subtype=FINAL (ForecastSubType.FINAL), and entity_type=UFI.

    This demonstrates the type-subtype relationship:
    - type: TimeSeriesType.FORECAST
    - subtype: ForecastSubType.FINAL (subtype depends on type being FORECAST)

    Only requires specifying: ufi_id, start_date, end_date, and optional resolution_id.

    Args:
        ufi_id: UFI identifier for the asset
        start_date: Start datetime
        end_date: End datetime
        resolution_id: Resolution ID (must be "quarterly" or "hourly"). Defaults to "quarterly"

    Raises:
        AxpoValidationError: If resolution_id is invalid or date range exceeds 1 day
    """

    def __init__(
        self,
        ufi_id: str,
        start_date: datetime,
        end_date: datetime,
        resolution_id: str = "quarterly",
    ):
        """Initialize with user-friendly parameter names.

        Args:
            ufi_id: UFI identifier for the asset
            start_date: Start datetime
            end_date: End datetime
            resolution_id: Resolution ID (defaults to "quarterly")
        """
        super().__init__(
            timeseries_type=TimeSeriesType.FORECAST,
            timeseries_subtype=ForecastSubType.FINAL,
            entity_type=EntityType.UFI,
            entity_id=ufi_id,
            resolution_id=resolution_id,
            start_date=start_date,
            end_date=end_date,
        )


@dataclass
class AxpoIncrementalClientProgramBreakdownParams(AxpoTimeseriesParam):
    """Parameters for get_incremental_client_program_breakdown.

    Extends AxpoTimeseriesParam with fixed timeseries_type=INCCLIENTPROGRAMBREAKDOWN
    and entity_type=UFI. The market parameter becomes the timeseries_subtype.

    This demonstrates the type-subtype relationship:
    - type: TimeSeriesType.INCCLIENTPROGRAMBREAKDOWN
    - subtype: AxpoMarket (market code - subtype depends on type being INCCLIENTPROGRAMBREAKDOWN)

    Only requires specifying: ufi_id, market, start_date, end_date, and optional resolution_id.

    Args:
        ufi_id: UFI identifier for the asset
        market: Market code (AxpoMarket enum: MD, MI1, MI2, MI3, mFRR_PT, RT1, RT2)
                This becomes the timeseries_subtype for INCCLIENTPROGRAMBREAKDOWN type
        start_date: Start datetime
        end_date: End datetime
        resolution_id: Resolution ID (must be "quarterly" or "hourly"). Defaults to "quarterly"

    Raises:
        AxpoValidationError: If resolution_id is invalid, date range exceeds 1 day,
            or market is not an AxpoMarket enum value
    """

    def __init__(
        self,
        ufi_id: str,
        market: AxpoMarket,
        start_date: datetime,
        end_date: datetime,
        resolution_id: str = "quarterly",
    ):
        """Initialize with user-friendly parameter names.

        Args:
            ufi_id: UFI identifier for the asset
            market: Market code (AxpoMarket enum)
            start_date: Start datetime
            end_date: End datetime
            resolution_id: Resolution ID (defaults to "quarterly")
        """
        super().__init__(
            timeseries_type=TimeSeriesType.INCCLIENTPROGRAMBREAKDOWN,
            timeseries_subtype=market,
            entity_type=EntityType.UFI,
            entity_id=ufi_id,
            resolution_id=resolution_id,
            start_date=start_date,
            end_date=end_date,
        )


@dataclass
class AxpoFinalForecastBreakdownParams(AxpoTimeseriesParam):
    """Parameters for get_final_forecast_breakdown.

    Extends AxpoTimeseriesParam with fixed timeseries_type=FINALFORECASTBREAKDOWN
    and entity_type=UFI. The market parameter becomes the timeseries_subtype.

    This demonstrates the type-subtype relationship:
    - type: TimeSeriesType.FINALFORECASTBREAKDOWN
    - subtype: AxpoMarket (market code - subtype depends on type being FINALFORECASTBREAKDOWN)

    Only requires specifying: ufi_id, market, start_date, end_date, and optional resolution_id.

    Args:
        ufi_id: UFI identifier for the asset
        market: Market code (AxpoMarket enum: MD, MI1, MI2, MI3, mFRR_PT, RT1, RT2)
                This becomes the timeseries_subtype for FINALFORECASTBREAKDOWN type
        start_date: Start datetime
        end_date: End datetime
        resolution_id: Resolution ID (must be "quarterly" or "hourly"). Defaults to "quarterly"

    Raises:
        AxpoValidationError: If resolution_id is invalid, date range exceeds 1 day,
            or market is not an AxpoMarket enum value
    """

    def __init__(
        self,
        ufi_id: str,
        market: AxpoMarket,
        start_date: datetime,
        end_date: datetime,
        resolution_id: str = "quarterly",
    ):
        """Initialize with user-friendly parameter names.

        Args:
            ufi_id: UFI identifier for the asset
            market: Market code (AxpoMarket enum)
            start_date: Start datetime
            end_date: End datetime
            resolution_id: Resolution ID (defaults to "quarterly")
        """
        super().__init__(
            timeseries_type=TimeSeriesType.FINALFORECASTBREAKDOWN,
            timeseries_subtype=market,
            entity_type=EntityType.UFI,
            entity_id=ufi_id,
            resolution_id=resolution_id,
            start_date=start_date,
            end_date=end_date,
        )


@dataclass
class AxpoTimeseriesResponse:
    """Single timeseries data point from Axpo API response.

    Represents one value entry from the timeseries endpoint response.
    The API returns these in the response["Lista"]["values"] array.
    """

    dateTime: str
    val: float
    unit: str
    updateDate: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AxpoTimeseriesResponse":
        """Parse from API response dict.

        Args:
            data: Dict with keys: dateTime, val, unit, updateDate

        Returns:
            AxpoTimeseriesResponse instance
        """
        return cls(
            dateTime=data["dateTime"],
            val=data["val"],
            unit=data["unit"],
            updateDate=data["updateDate"],
        )


def parse_axpo_timeseries_values(response: dict[str, Any]) -> list[AxpoTimeseriesResponse]:
    """Extract and parse values array from Axpo timeseries API response.

    Args:
        response: Raw API response with Lista.values structure

    Returns:
        List of AxpoTimeseriesResponse parsed from response["Lista"]["values"]
    """
    values = response.get("Lista", {}).get("values", [])
    return [AxpoTimeseriesResponse.from_dict(v) for v in values]


class AxpoError(Exception):
    """Base exception for Axpo client errors."""

    pass


class AxpoAPIError(AxpoError):
    """Exception raised when Axpo API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"Axpo API request failed with status {status_code}"
        super().__init__(self.message)


class AxpoRequestError(AxpoError):
    """Exception raised when there's a problem making the request to Axpo."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class AxpoValidationError(AxpoError):
    """Exception for input validation errors."""

    pass


class AxpoClient(BearerTokenHTTPClient):
    """HTTP client for Axpo API.

    Provides access to Axpo power forecast data and timeseries information
    through REST endpoints. The client uses OAuth2 password grant authentication
    with Basic Auth (consumer_id/consumer_key) to obtain a Bearer token for API requests.

    Args:
        base_url: Base URL for the Axpo API (e.g., "https://api.axpo.com")
        api_path: API path prefix for data endpoints (e.g., "/helio/v2/rest")
        auth_path: Path for authentication endpoint (e.g., "/token")
        username: Username for OAuth2 password grant
        password: Password for OAuth2 password grant
        consumer_id: Consumer ID for Basic Auth
        consumer_key: Consumer key for Basic Auth
        grant_type_password: OAuth2 grant type for password authentication
        grant_type_refresh: OAuth2 grant type for token refresh
        headers: Optional custom headers to merge with defaults
        logger: Optional logger instance for debugging and monitoring
        **kwargs: Additional HTTP client configuration
    """

    def __init__(
        self,
        base_url: str,
        api_path: str,
        auth_path: str,
        username: str,
        password: str,
        consumer_id: str,
        consumer_key: str,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the Axpo API client."""
        self._logger = logger or get_logger(__name__)
        self._username = username
        self._password = password
        self._consumer_id = consumer_id
        self._consumer_key = consumer_key
        self.api_path = api_path
        self._auth_path = auth_path
        self._grant_type_password: str | None = "password"
        self._grant_type_refresh: str | None = "refresh_token"
        self._refresh_token: str | None = None
        self._expires_in: int | None = None

        # Initialize BearerTokenHTTPClient without token
        # We'll get the token after client initialization
        super().__init__(base_url, token=None, logger=self._logger, **kwargs)

        # Now that client is initialized, perform login to get real token
        self.token = self.login()
        self.login_func = self.login
        # Update the Authorization header with the real token
        self._set_auth_header()

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to Axpo-specific exceptions.

        Args:
            exc: The HTTP status error from httpx

        Returns:
            AxpoAPIError with status code and URL information
        """
        return AxpoAPIError(exc.response.status_code, str(exc.request.url))

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to Axpo-specific exceptions.

        Args:
            exc: The request error from httpx

        Returns:
            AxpoRequestError with original exception details
        """
        return AxpoRequestError(str(exc), exc)

    def _validate_resolution_id(self, resolution_id: str) -> None:
        """Validate that resolution_id is either 'quarterly' or 'hourly'.

        Args:
            resolution_id: Resolution ID to validate

        Raises:
            AxpoValidationError: If resolution_id is not 'quarterly' or 'hourly'
        """
        if resolution_id not in ("quarterly", "hourly"):
            raise AxpoValidationError(f"resolution_id must be 'quarterly' or 'hourly', got '{resolution_id}'")

    def login(self) -> str:
        """Login to Axpo API and obtain Bearer token using OAuth2 password grant.

        Uses Basic Auth (consumer_id/consumer_key) to obtain a Bearer token
        via OAuth2 password grant flow. The access token, refresh token, and
        expiration time are stored for use in subsequent API requests.

        Raises:
            AxpoAPIError: If authentication fails
            AxpoRequestError: If there's a problem making the authentication request

        Returns:
            Access token string for Bearer authentication
        """
        auth = httpx.BasicAuth(self._consumer_id, self._consumer_key)

        # OAuth2 password grant uses form-encoded data in the request body
        data = {
            "username": self._username,
            "password": self._password,
            "grant_type": self._grant_type_password,
        }

        auth_label = HTTPClientLabels.AUTH

        try:
            self._logger.debug(
                "auth started",
                action=auth_label.started,
                step=auth_label,
                auth_path=self._auth_path,
            )

            response = self.post(
                path=self._auth_path,
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                auth=auth,
            )

            result = response
            access_token = response["access_token"]

            self._refresh_token = result.get("refresh_token")
            self._expires_in = result.get("expires_in", 3600)  # Default 3600 seconds

            self._logger.info(
                "auth completed",
                action=auth_label.completed,
                step=auth_label,
                expires_in=self._expires_in,
            )

            return access_token

        except httpx.HTTPStatusError as exc:
            self._logger.error(
                "auth failed",
                action=auth_label.failed,
                step=auth_label,
                status_code=exc.response.status_code,
                error_message=exc.response.text,
            )
            raise self._handle_http_error(exc) from exc

        except httpx.RequestError as exc:
            self._logger.error(
                "auth request failed",
                action=auth_label.failed,
                step=auth_label,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
            raise self._handle_request_error(exc) from exc

    def _get_timeseries_data(
        self,
        params: AxpoTimeseriesParam,
    ) -> list[AxpoTimeseriesResponse]:
        """Get timeseries data for a specific entity and date range.

        Generic method to retrieve timeseries data from Axpo API using the GET timeseries endpoint:
        GET: {baseUrl}/helio/v2/rest/timeseries/{type}/{subtype}/{entityType}/{entityId}/{resolutionId}/{startDateTime}/{endDateTime}  # noqa: E501

        IMPORTANT: The subtype parameter depends on the type parameter:
        - If type=FORECAST → subtype must be a ForecastSubType value (e.g., ForecastSubType.FINAL)
        - If type=INCCLIENTPROGRAMBREAKDOWN → subtype must be an AxpoMarket value (e.g., AxpoMarket.MD)

        Args:
            params: AxpoTimeseriesParam with timeseries_type, timeseries_subtype,
                entity_type, entity_id, resolution_id, start_date, end_date.
                The timeseries_subtype must correspond to the timeseries_type.

        Returns:
            List of AxpoTimeseriesResponse objects containing the timeseries data values

        Raises:
            AxpoAPIError: If the API returns an error response
            AxpoRequestError: If there's a problem making the request
            AxpoValidationError: If resolution_id is not "quarterly" or "hourly"
        """
        # Validate resolution_id
        self._validate_resolution_id(params.resolution_id)

        # Convert enums to strings (all parameters are enums)
        type_str = params.timeseries_type.value
        subtype_str = params.timeseries_subtype.value
        entity_type_str = params.entity_type.value

        start_iso = quote(params.start_date.isoformat())
        end_iso = quote(params.end_date.isoformat())

        endpoint = (
            f"{self.api_path}/timeseries/{type_str}/{subtype_str}/{entity_type_str}/{params.entity_id}/"
            f"{params.resolution_id}/{start_iso}/{end_iso}"
        )

        response = self.get(endpoint)
        return parse_axpo_timeseries_values(response)

    def get_final_power_forecast(
        self,
        params: AxpoFinalPowerForecastParams,
    ) -> list[AxpoTimeseriesResponse]:
        """Get final power forecast data for a specific UFI and date range.

        This method retrieves timeseries data with fixed type-subtype combination:
        - timeseries_type: TimeSeriesType.FORECAST
        - timeseries_subtype: ForecastSubType.FINAL (subtype depends on FORECAST type)

        Endpoint: GET /timeseries/FORECAST/final/UFI/{ufi_id}/...

        Args:
            params: AxpoFinalPowerForecastParams with ufi_id, start_date, end_date,
                and optional resolution_id (defaults to "quarterly")

        Returns:
            List of AxpoTimeseriesResponse objects containing the final power forecast data values

        Raises:
            AxpoAPIError: If the API returns an error response
            AxpoRequestError: If there's a problem making the request
            AxpoValidationError: If resolution_id is not "quarterly" or "hourly"
        """
        return self._get_timeseries_data(params)

    def get_incremental_client_program_breakdown(
        self,
        params: AxpoIncrementalClientProgramBreakdownParams,
    ) -> list[AxpoTimeseriesResponse]:
        """Get incremental client program breakdown for a specific market and UFI.

        **INCREMENTAL DATA**: Retrieves the increment of the schedule (in MW) that has
        been confirmed by the NEMO (OMIE in this case) or TSO (REE/REN) by the specific market.

        This is incremental data showing changes to the schedule, not the full schedule.

        This method uses the type-subtype combination:
        - timeseries_type: TimeSeriesType.INCCLIENTPROGRAMBREAKDOWN
        - timeseries_subtype: AxpoMarket (market code - subtype depends on INCCLIENTPROGRAMBREAKDOWN type)

        Endpoint: GET /timeseries/INCCLIENTPROGRAMBREAKDOWN/{market}/UFI/{ufi_id}/...
        where {market} can be: MD, MI1, MI2, MI3, mFRR_PT, RT1, RT2

        Args:
            params: AxpoIncrementalClientProgramBreakdownParams with ufi_id, market,
                start_date, end_date, and optional resolution_id (defaults to "quarterly")

        Returns:
            List of AxpoTimeseriesResponse objects containing the incremental client program breakdown data values

        Raises:
            AxpoAPIError: If the API returns an error response
            AxpoRequestError: If there's a problem making the request
            AxpoValidationError: If resolution_id is not "quarterly" or "hourly", or market is not an AxpoMarket enum
        """
        return self._get_timeseries_data(params)

    def get_final_forecast_breakdown(
        self,
        params: AxpoFinalForecastBreakdownParams,
    ) -> list[AxpoTimeseriesResponse]:
        """Get final forecast breakdown for a specific market and UFI.

        Retrieves the final forecast breakdown data (in MW) for a given market
        and asset, showing how the final forecast is distributed across markets.

        This method uses the type-subtype combination:
        - timeseries_type: TimeSeriesType.FINALFORECASTBREAKDOWN
        - timeseries_subtype: AxpoMarket (market code)

        Endpoint: GET /timeseries/FINALFORECASTBREAKDOWN/{market}/UFI/{ufi_id}/...
        where {market} can be: MD, MI1, MI2, MI3, mFRR_PT, RT1, RT2

        Args:
            params: AxpoFinalForecastBreakdownParams with ufi_id, market,
                start_date, end_date, and optional resolution_id (defaults to "quarterly")

        Returns:
            List of AxpoTimeseriesResponse objects containing the final forecast breakdown data values

        Raises:
            AxpoAPIError: If the API returns an error response
            AxpoRequestError: If there's a problem making the request
            AxpoValidationError: If resolution_id is not "quarterly" or "hourly", or market is not an AxpoMarket enum
        """
        return self._get_timeseries_data(params)

    def post_forecast(
        self,
        params: AxpoForecastRequestParams,
        body: AxpoRequestBody,
    ) -> dict[str, Any]:
        """POST forecast (quarter-hourly energy forecasts) to HELIO.

        Query params (via AxpoForecastRequestParams): localDate, type="original", source="client", ufiCode.
        Body: timePeriodType="fourthhour", v = array of 92, 96, or 100 quarter-hourly values.

        Args:
            params: AxpoForecastRequestParams (type is always "original", source always "client").
            body: AxpoRequestBody with timePeriodType and v (92/96/100 values).

        Returns:
            API response JSON.

        Raises:
            AxpoAPIError: If the API returns an error.
            AxpoRequestError: If the request fails.
        """
        return self.post(
            f"{self.api_path}/{AxpoRequestEndpoints.FORECAST}",
            params=params.to_query_params(),
            json=body.to_dict(),
        )

    def post_availability(
        self,
        params: AxpoAvailabilityRequestParams,
        body: AxpoRequestBody,
    ) -> dict[str, Any]:
        """POST availability (quarter-hourly availability data) to HELIO.

        Query params (via AxpoAvailabilityRequestParams): localDate, type ("percentage" or "MWh"), ufiCode (no source).
        type: "percentage" = availability as percentage; "MWh" = availability as limit in MWh.

        Args:
            params: AxpoAvailabilityRequestParams with type "percentage" or "MWh".
            body: AxpoRequestBody with timePeriodType and v (92/96/100 values).

        Returns:
            API response JSON.

        Raises:
            AxpoAPIError: If the API returns an error.
            AxpoRequestError: If the request fails.
        """
        return self.post(
            f"{self.api_path}/{AxpoRequestEndpoints.AVAILABILITY}",
            params=params.to_query_params(),
            json=body.to_dict(),
        )

from datetime import date, datetime, timedelta
from typing import Iterator, Protocol, Tuple, TypeVar


class _datetime_like(Protocol):
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int


def ensure_py_datetime(dt: _datetime_like) -> datetime:
    """Transform any "datetimish" type into a Python datetime object

    Args:
        dt (_datetime_like): input datetime

    Returns:
        datetime: same as `dt` but a Python datetime object
    """
    return datetime(
        dt.year,
        dt.month,
        dt.day,
        dt.hour,
        dt.minute,
        dt.second,
    )


def zeroed_to_hour(dt: _datetime_like) -> datetime:
    """Returns `dt` with all fields smaller than the hour zeroed

    Args:
        dt (_datetime_like): input datetime

    Returns:
        datetime: zeroed `dt`
    """
    return datetime(dt.year, dt.month, dt.day, dt.hour)


T = TypeVar("T", datetime, date)


def time_window_batches(start: T, end: T, delta: timedelta) -> Iterator[Tuple[T, T]]:
    """Iterates through subsequent (start,end) pairs, from `start` to `end` (inclusive),
    with a maximum timedelta of `delta`

    Args:
        start (datetime or date T): start of time window
        end (datetime or date T): end of time window
        delta (timedelta): "batch" window timedelta

    Raises:
        ValueError: If end < start

    Yields:
        Iterator[Tuple[T, T]]: Iterator of (start,end) tuple pairs
    """
    if end < start:
        raise ValueError("end < start")

    if start + delta == start:
        raise ValueError("delta is too small")

    if end - start < delta:
        yield start, end
        return

    current = next_window = start
    while True:
        next_window = min(current + delta, end)
        yield current, next_window
        current = next_window
        if current == end:
            break

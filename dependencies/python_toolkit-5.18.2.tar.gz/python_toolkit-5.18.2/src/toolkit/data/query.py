from __future__ import annotations

import typing
import warnings

from sqlalchemy import text

from toolkit.calendar import ISO8601Date


class DatabaseSession(typing.Protocol):
    def execute(self, prepared_statement: typing.Any):
        pass


class Query:
    """
    Helps to build SQL statements and prepare those for execution.
    """

    def __init__(self, initial_sql_statement: str) -> None:
        self._bind_params: dict = {}
        self._dates_added_counter: int = 0
        self._sql_stmt: str = self._clean_statement(initial_sql_statement)

    @staticmethod
    def _clean_statement(sql_stmt: str) -> str:
        """
        Removes new lines and extra spaces the sql statement may have.
        Adds a space to the statement to help further statement construction
         logic.
        """
        stripped_sql_stmt = sql_stmt.replace("\n", " ")
        tokenized_stmt = stripped_sql_stmt.split()
        space_joined_stmt = " ".join(tokenized_stmt)
        space_ended_stmt = f"{space_joined_stmt} "
        return space_ended_stmt

    @staticmethod
    def _clean_parameter(param: str) -> str:
        return param.replace(".", "_")

    def with_parameter(self, bind_parameter: str, bind_value: typing.Any) -> Query:
        """
        Adds a parameter to bind to the initial sql statement.
        """
        self._bind_params[bind_parameter] = bind_value
        return self

    def with_parameters(self, **args):
        """
        Adds multiple parameters to the initial sql statement.
        """
        for attr, val in args.items():
            self.with_parameter(attr, val)
        return self

    @property
    def prepared_statement(self):
        """
        An SQL statement already with bind parameters inserted.
        """
        return text(str(self)).bindparams(**self.params)

    @property
    def binds(self) -> dict:
        """
        The bind parameters to be inserted into the SQL statement.
        """
        warnings.warn("deprecated, use 'params' method instead", stacklevel=2)
        return self._bind_params

    @property
    def params(self) -> dict:
        """
        The parameters to be inserted into the SQL statement.
        """
        return self._bind_params

    def __str__(self) -> str:
        return self._sql_stmt.rstrip()

    def with_date(self, date_str: typing.Union[str, ISO8601Date], column_name: str, operator: str) -> Query:
        """
        Adds a date to a SQL statement while allowing to specify the column
        and the operator.
        Example:
            If the column is named 'read_at' and the operator is '>=', we get
            this:

                "read_at >= :date1"
        """
        self._dates_added_counter += 1
        bind_parameter_name = f"date{self._dates_added_counter}"
        self._bind_params[bind_parameter_name] = str(date_str)

        conditions = f"AND {column_name} {operator} :{bind_parameter_name}"
        if not self._has_where_clause:
            conditions = f"WHERE {column_name} {operator} :{bind_parameter_name}"

        self._inject_conditions_in_sql_statement(conditions)

        return self

    @property
    def _has_where_clause(self) -> bool:
        return "WHERE" in self._sql_stmt

    def with_in(self, column_name: str, params: typing.Union[tuple, list]) -> Query:
        conditions = f"AND {column_name} IN ("
        if not self._has_where_clause:
            conditions = f"WHERE {column_name} IN ("
        conditions = self._populate_in_values(column_name, conditions, params)
        conditions = self._close_in_values(conditions)
        self._inject_conditions_in_sql_statement(conditions)

        return self

    def _populate_in_values(self, column_name, conditions, params):
        for param_number, param_value in enumerate(params):
            param_name = self._clean_parameter(column_name)
            bind_parameter_name = f"{param_name}{param_number}"

            self._bind_params[bind_parameter_name] = param_value
            conditions = f"{conditions}:{bind_parameter_name}, "
        return conditions

    @staticmethod
    def _close_in_values(conditions):
        return f"{conditions[:-2]}) "

    def _inject_conditions_in_sql_statement(self, conditions: str):
        separator = "GROUP BY"
        if self._sql_stmt.find(separator) == -1:
            separator = "ORDER BY"

        command = self._sql_stmt
        right_stmt = ""

        if separator in self._sql_stmt:
            list_sql_stmt = self._sql_stmt.split(separator, maxsplit=1)
            command = f"{list_sql_stmt[0]}"
            right_stmt = f"{separator}{list_sql_stmt[1]} "

        if not self._sql_stmt.endswith(" "):
            conditions = f" {conditions}"
        if not conditions.endswith(" "):
            conditions = f"{conditions} "

        self._sql_stmt = f"{command}{conditions}{right_stmt}"

    def with_limit_offset(self, limit: int, offset: int) -> Query:
        """
        Adds limit and offset to a SQL statement.
        """

        self.with_parameter("limit", limit)
        self.with_parameter("offset", offset)
        self._sql_stmt = f"{self._sql_stmt} LIMIT :limit OFFSET :offset"

        return self

    def with_filters(self, **args):
        """
        Adds filter parameters to the sql statement.
        """
        if len(args) == 0:
            return

        condition = "AND" if self._has_where_clause else "WHERE"
        for i, key in enumerate(args.keys()):
            bind = self._clean_parameter(key)

            condition = f"{condition} {key} = :{bind}" if i == 0 else f"{condition} AND {key} = :{bind}"

            self.with_parameter(bind, args[key])

        self._inject_conditions_in_sql_statement(condition)

        return self

import hashlib
import lzma
import os
import pickle  # nosec
from collections import UserDict
from copy import deepcopy
from typing import Any, Dict, Literal


class MemoryCache(UserDict[str, object]):
    def __setitem__(self, key: str, item: object) -> None:
        return super().__setitem__(key, deepcopy(item))


class FileCache(MemoryCache):
    # ! not all dunder methods are implemented
    def __init__(self, dict=None, /, **kwargs):
        self.folder = _default_cache_folder
        super().__init__(dict, **kwargs)

    @staticmethod
    def _dump_binary(v: object) -> bytes:
        return lzma.compress(pickle.dumps(v))  # nosec

    @staticmethod
    def _load_binary(b: bytes) -> object:
        return pickle.loads(lzma.decompress(b))  # nosec

    def __contains__(self, key: object) -> bool:
        return super().__contains__(key) or os.path.isfile(os.path.join(self.folder, str(key)))

    def __setitem__(self, key: str, item: object) -> None:
        if not os.path.exists(self.folder):
            os.makedirs(self.folder, exist_ok=True)
        file_path = os.path.join(self.folder, key)
        with open(file_path, "wb") as f:
            f.write(self._dump_binary(item))
        return super().__setitem__(key, item)

    def __getitem__(self, key: str) -> object:
        try:
            return super().__getitem__(key)
        except KeyError:
            with open(os.path.join(self.folder, key), "rb") as f:
                v = self._load_binary(f.read())
                super().__setitem__(key, v)
                return v

    def __delitem__(self, key: str):
        filepath = os.path.join(self.folder, key)
        if os.path.isfile(filepath):
            os.remove(filepath)
        return super().__delitem__(key)

    def clear(self) -> None:
        for filepath in os.listdir(self.folder):
            try:
                os.remove(filepath)
            except FileNotFoundError:
                continue
        return super().clear()


_default_cache_folder = ".dev_cache"


_memory_cache = MemoryCache()
_file_cache = FileCache()


_caches: Dict[str, UserDict[str, Any]] = {"memory": _memory_cache, "file": _file_cache}


def _function_cache_hash(func, *args, **kwargs):
    hash_obj = hashlib.sha256()
    hash_obj.update(func.__name__.encode("utf-8"))
    hash_obj.update(pickle.dumps(args))
    hash_obj.update(pickle.dumps(kwargs))
    return hash_obj.hexdigest()


def set_cache_folder(folder: str):
    global _file_cache  # noqa: F824
    _file_cache.folder = folder


def clear_cache(storage: Literal["memory", "file"]):
    global _caches  # noqa: F824
    _caches[storage].clear()


def cache(storage: Literal["memory", "file"] = "memory"):
    """Caching decorator, capable of storing cache in RAM or Disk.

    Args:
        storage (Literal[&quot;memory&quot;, &quot;file&quot;], optional): Cache storage type. Defaults to "memory".
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            _cache = _caches[storage]
            cache_hash = _function_cache_hash(func, *args, **kwargs)

            if cache_hash in _cache:
                return _cache[cache_hash]

            retval = func(*args, **kwargs)

            _cache[cache_hash] = retval

            return retval

        return wrapper

    # allows using @cache instead of @cache()
    if callable(storage):
        return decorator(storage)

    return decorator

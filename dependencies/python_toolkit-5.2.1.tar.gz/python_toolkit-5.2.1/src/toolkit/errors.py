from typing import Dict

error_messages: Dict[int, str] = {
    # Technical Errors: Events
    10000: "Emitted event is not an instance of a domain event",
    # Technical Errors: Factories
    10100: "Could not build a non service instance",
    10101: "Could not find service in registered services",
    10102: "Service is already registered",
    # Technical Errors: Pagination
    10200: "Requested non existing page",
    # Domain Errors
    20000: "Unspecified error",
    20001: "Error, end date must be greater than start date",
}


class ErrorBase(Exception):
    """
    Base class for all errors.
    """

    message: str = "Unspecified error"
    code: int = 0

    def __init__(self, message=None):
        if not self.code:
            raise Exception("Base errors need to have a code")

        if not message:
            try:
                self.message = error_messages[self.code]
            except KeyError:
                # Fall back to unspecified error
                pass
        else:
            self.message = message

        super().__init__(self.message)


class ErrorDomain(ErrorBase):
    """
    An Error of the domain is something that is happening due to the violation
    of the policies of the system.
    """

    code: int = 20000

from enum import Enum, unique
from typing import Union


@unique
class Order(Enum):
    ASC = "ASC"
    DESC = "DESC"


class Ordering:
    default_ordering: str

    def __init__(self, *, ordering_value: Union[str, None] = None):
        self.ordering_value = str(ordering_value) if ordering_value else ""

        if hasattr(self, "default_ordering") and self.default_ordering and not ordering_value:
            self.ordering_value = self.default_ordering

    def __str__(self) -> str:
        return self.ordering_value

    @property
    def field(self) -> str:
        if not self.ordering_value:
            return ""

        if self.ordering_value == "-":
            return self.ordering_value

        if self.ordering_value.startswith("-"):
            return self.ordering_value.replace("-", "", 1)

        return self.ordering_value

    @property
    def order(self) -> Order:
        if not self.ordering_value:
            return Order.ASC

        if self.ordering_value == "-":
            return Order.ASC

        if self.ordering_value.startswith("-"):
            return Order.DESC

        return Order.ASC

"""REN Market Information SOAP client.

.. deprecated:: 5.9.0
    This SOAP client is deprecated and will be removed in a future version.
    Use :class:`toolkit.clients.rest.ren.RenClient` instead.

Provides a client for accessing REN (Redes Energéticas Nacionais) Market Information
Web Service for Portuguese electricity market data. See docs/RenClient.md for detailed
documentation and examples.
"""

from __future__ import annotations

import warnings
from typing import Any

from toolkit.logging import Logger
from toolkit.soap_client import BaseSOAPClient

DEFAULT_WSDL_URL = "https://ws-mercado.ren.pt/MarketInfoService.asmx?WSDL"


class RenClient(BaseSOAPClient):
    """SOAP client for REN Market Information service.

    Provides access to Portuguese electricity market data from REN (Redes Energéticas
    Nacionais), the Portuguese transmission system operator. Handles automatic XML
    parsing and Portuguese market data structures.

    See docs/RenClient.md for detailed usage examples and data structure documentation.
    """

    def __init__(
        self,
        wsdl_url: str = DEFAULT_WSDL_URL,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the REN Market Information client.

        Args:
            wsdl_url: URL to REN's WSDL service. Defaults to the official REN endpoint.
            logger: Optional logger for debugging and monitoring SOAP requests/responses.
            **kwargs: Additional arguments passed to the underlying zeep.Client.
        """
        warnings.warn(
            "RenClient (SOAP) is deprecated, use toolkit.clients.rest.ren.RenClient instead",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(wsdl_url, logger=logger, **kwargs)

    def get_market_price(self, start_day: str, end_day: str) -> dict[str, Any]:
        """Get market price data for a specified date range.

        Retrieves Portuguese electricity market pricing data from REN for the
        specified date range. Each day contains 24 hourly periods with pricing
        information for different market sessions.

        Args:
            start_day: Start date in YYYY-MM-DD format (e.g., "2023-10-01")
            end_day: End date in YYYY-MM-DD format (e.g., "2023-10-01")

        Returns:
            Dictionary containing parsed market price data. See docs/RenClient.md
            for detailed data structure documentation.

        Raises:
            SOAPFaultException: If the REN service returns an error
            SOAPTransportException: If there are network/transport issues
        """
        warnings.warn(
            "RenClient.get_market_price (SOAP) is deprecated, \
            use toolkit.clients.rest.ren.RenClient.get_market_price instead",
            DeprecationWarning,
            stacklevel=2,
        )
        result = self._request(
            "GetInfoForTimeFrameByInfoType", StartDay=start_day, EndDay=end_day, InfoType="GetMarketPrice"
        )
        return self._parse_xml_string_to_dict(result)

    def get_imbalances_price(self, start_day: str, end_day: str) -> dict[str, Any]:
        """Get imbalance price data for a specified date range.

        Retrieves Portuguese electricity market imbalance pricing data from REN for the
        specified date range. Imbalance prices are used to settle deviations between
        scheduled and actual electricity consumption/production.

        Args:
            start_day: Start date in YYYY-MM-DD format (e.g., "2023-10-01")
            end_day: End date in YYYY-MM-DD format (e.g., "2023-10-01")

        Returns:
            Dictionary containing parsed imbalance price data. See docs/RenClient.md
            for detailed data structure documentation.

        Raises:
            SOAPFaultException: If the REN service returns an error
            SOAPTransportException: If there are network/transport issues

        Note:
            Starting from 2025-04-01, data is returned with 15-minute intervals.
            Before that date, hourly intervals are used.
        """
        warnings.warn(
            "RenClient.get_imbalances_price (SOAP) is deprecated, \
            use toolkit.clients.rest.ren.RenClient.get_imbalances_price instead",
            DeprecationWarning,
            stacklevel=2,
        )
        result = self._request(
            "GetInfoForTimeFrameByInfoType", StartDay=start_day, EndDay=end_day, InfoType="GetImbalancePrice"
        )
        return self._parse_xml_string_to_dict(result)

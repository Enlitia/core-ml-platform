"""
The Database module contains all the logic to handle database connections.To
 use this module you have to define a 'databases' entry in the settings class.
 Each database should have its own alias. If no alias is passed, it uses the 'default'.
 For each alias you can define a connection string. Here you can find examples on how to define the
 connection string:
    https://docs.sqlalchemy.org/en/20/core/engines.html#database-urls

Settings example:
    ...
    ...
    class Settings(BaseSettings):
        databases: Dict[str, str] = {
            "default": "mysql://root:password@127.0.0.1:33308/write_db",
            "read_model": "mysql://root:password@127.0.0.1:33308/rmodel",
        }
    ...
    ...


Following the previous example, to access any database by it's alias:
    ...
    ...
    from toolkit.database import database

    # To use the default alias, just use the object imported
    _ = database

    # To use a specific alias call the using method
    database.using("read_model")
    ...
    ...



"""

from __future__ import annotations

import contextlib
import time
from functools import wraps
from typing import Any, Callable, Dict, Final, List, Optional, TypeVar, overload

from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import declarative_base, sessionmaker
from typing_extensions import ParamSpec

from toolkit.configuration import configuration


class DatabaseConfigurationError(Exception):
    pass


DEFAULT_ALIAS: Final = "default"


class DatabaseFactory:
    @property
    def _aliases(self) -> List[str]:
        return configuration.settings.databases.keys()

    def _make_database(self, alias: str) -> _Database:
        d = _Database(configuration.settings, alias=alias)
        d._create_engine()  # noqa
        return d

    def build(self, alias: str):
        return self._make_database(alias)


class Database:
    _dbs: Dict[str, _Database]

    def __init__(self):
        self._dbs = dict()

    def _build_database_if_not_exists(self, alias: str):
        if alias not in self._dbs:
            self._dbs[alias] = DatabaseFactory().build(alias)

    def session(self, alias: str = DEFAULT_ALIAS):
        self._build_database_if_not_exists(alias)
        return self.using(alias).session()  # type: ignore

    # @property
    # def engine(self):
    #     self._build_database_if_not_exists()
    #     return self.using(alias).engine  # type: ignore

    def using(self, database_alias: str = DEFAULT_ALIAS):
        try:
            self._build_database_if_not_exists(database_alias)
            return self._dbs[database_alias]
        except KeyError:
            raise KeyError(f"unknown database with alias '{database_alias}'")


database = Database()


class _Database:
    def __init__(self, settings, alias=None):
        self._Session = None
        self._engine = None
        self.alias = alias
        if not self.alias:
            self.alias = DEFAULT_ALIAS
        try:
            self._connection_string = settings.databases[self.alias]
        except AttributeError:
            raise DatabaseConfigurationError(
                f"module '{settings.__module__}' does not contain a database configuration"
            )
        except KeyError:
            raise DatabaseConfigurationError(
                f"module '{settings.__module__}' does not contain a configuration for database '{self.alias}'"
            )

        self._session_configured = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.dispose()

    def dispose(self):
        """
        Disconnects from the database and frees resources being used
        """
        # More info: SQLAlchemy 1.4
        # https://docs.sqlalchemy.org/en/20/core/connections.html#engine-disposal
        # "Within test suites or multi-tenancy scenarios where many ad-hoc,
        #  short-lived Engine objects may be created and disposed."
        #
        self._engine.dispose()  # type: ignore

    @property
    def engine(self):
        if not self._engine:
            self._create_engine()
        return self._engine

    @property
    def session(self):
        """
        Creates a new Session class bound to a specific engine.
        """
        # https://docs.sqlalchemy.org/en/20/orm/session_basics.html#using-a-sessionmaker
        if not self._session_configured:
            self._Session = sessionmaker()
            self._Session.configure(bind=self.engine)
            self._session_configured = True

        return self._Session

    def _create_engine(self):
        try:
            echo_sql = configuration.settings.echo_sql and configuration.settings.debug
        except AttributeError:
            # Applications without these settings will keep behaving the same way
            echo_sql = False

        self._engine = create_engine(  # type: ignore
            self._connection_string,
            # https://docs.sqlalchemy.org/en/20/dialects/mysql.html#connection-timeouts-and-disconnects
            pool_recycle=3600,
            # https://docs.sqlalchemy.org/en/20/core/engines.html#sqlalchemy.create_engine.params.future
            future=True,
            # https://docs.sqlalchemy.org/en/20/core/engines.html#sqlalchemy.create_engine.params.echo
            echo=echo_sql,
        )

        dialect_name = self._engine.dialect.name
        if dialect_name == "oracle":
            test_statement = "SELECT 1 FROM DUAL"
        else:
            test_statement = "SELECT 1"

        # Make sure a connection to the database exists.
        with self.session() as session:
            max_attempts = range(4)
            for attempt in max_attempts:
                try:
                    session.execute(text(test_statement))
                    return
                except OperationalError as e:  # pragma: no cover
                    print(f"failed to connect to database '{self.alias}' , retrying ...: {str(e)}")  # pragma: no cover
                    time.sleep(2 * attempt)  # pragma: no cover
                    continue  # pragma: no cover

            raise Exception(f"failed to connect to database '{self.alias}'")

    # @staticmethod
    # def using(database_alias) -> _Database:
    #     # Using bounded method, because it helps with the static analyses.
    #     try:
    #         return _dbs[database_alias]
    #     except KeyError:
    #         raise KeyError(f"unknown database with alias '{database_alias}'")


# SQLAlchemy declarative base: https://docs.sqlalchemy.org/en/20/orm/mapping_api.html#sqlalchemy.orm.declarative_base
DataModelBase: Final = declarative_base()


class TransactionalDatabase:
    def __init__(self, database_instance: Database) -> None:
        self._database: Database = database_instance

    @classmethod
    def using(cls, database_alias) -> TransactionalDatabase:
        return cls(database.using(database_alias))  # type: ignore

    @contextlib.contextmanager
    def __call__(self):
        session = self._database.session()
        with session.begin():
            yield session


transaction = TransactionalDatabase(database)

P = ParamSpec("P")
T = TypeVar("T")


@overload
def inject_session(alias: Callable[P, T]) -> Callable[P, T]: ...


@overload
def inject_session(alias: Optional[str] = None) -> Callable[[Callable[P, T]], Callable[P, T]]: ...


def inject_session(alias=None):
    """Looks for a `session` keyword argument and injects it into the function if it is not passed by the caller.

    Useful for when launching callables that require a session in different threads, opening a session per thread.

    Args:
        alias (Optional[str], optional): Database alias. If not passed uses default.

    Returns:
        Callable[[F], F]: Decorated func.
    """

    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> Any:
            if "session" in kwargs and kwargs["session"] is not None:
                return func(*args, **kwargs)
            else:
                db = database
                if alias:
                    db = database.using(alias)
                with db.session() as session:
                    return func(*args, **kwargs, session=session)

        return wrapper  # type: ignore

    # allows using @inject_session instead of @inject_session()
    if callable(alias):
        return decorator(alias)

    return decorator

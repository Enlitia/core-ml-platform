"""REST client implementations."""

from toolkit.http_client import (
    APIKeyHTTPClient,
    BaseHTTPClient,
    HTTPAPIError,
    HTTPClientError,
    HTTPRequestError,
)

from .converge import ConvergeApiClient
from .edp_su import (
    EDPSUAPIClient,
    EDPSUAPIError,
    EDPSUEndpoints,
    EDPSUMarket,
    EDPSURequestError,
)
from .erg import (
    DeviceDataRequest,
    DeviceMeasureRequest,
    ErgApiClient,
    ErgAPIError,
    ErgApiPath,
    ErgError,
    ErgRequestError,
    GetAdvancedDataByDateFilter,
    GetDevicesFilter,
    GetForecastBody,
    GetMeasuresFilter,
    GetMeterObservationsBody,
    GetOutagesBody,
)
from .eva import (
    EvaAPIError,
    EvaClient,
    EvaError,
    EvaRequestError,
    EvaValidationError,
    PowerMeteoForecastParams,
)

try:
    from .omie import OMIEClient, OMIEDataError, OMIERegion, OMIEValidationError, PriceRegion
except ImportError:  # optional heavy deps (e.g. pandas)
    OMIEClient = None  # type: ignore[assignment,misc]
    OMIEDataError = None  # type: ignore[assignment,misc]
    OMIERegion = None  # type: ignore[assignment,misc]
    OMIEValidationError = None  # type: ignore[assignment,misc]
    PriceRegion = None  # type: ignore[assignment,misc]
from .ren import DEFAULT_HEADERS as REN_DEFAULT_HEADERS
from .ren import RenAPIError, RenClient, RenEndpoint, RenError, RenRequestError
from .solcast import (
    ForecastRadiationParams,
    LiveRadiationParams,
    RadiationAndWeatherParams,
    SolcastAPIError,
    SolcastClient,
    SolcastError,
    SolcastRequestError,
    SolcastResource,
    SolcastValidationError,
)

__all__ = [
    "REN_DEFAULT_HEADERS",
    "APIKeyHTTPClient",
    "BaseHTTPClient",
    "ConvergeApiClient",
    "DeviceDataRequest",
    "DeviceMeasureRequest",
    "EDPSUAPIClient",
    "EDPSUAPIError",
    "EDPSUEndpoints",
    "EDPSUMarket",
    "EDPSURequestError",
    "ErgAPIError",
    "ErgApiClient",
    "ErgApiPath",
    "ErgError",
    "ErgRequestError",
    "EvaAPIError",
    "EvaClient",
    "EvaError",
    "EvaRequestError",
    "EvaValidationError",
    "ForecastRadiationParams",
    "GetAdvancedDataByDateFilter",
    "GetDevicesFilter",
    "GetForecastBody",
    "GetMeasuresFilter",
    "GetMeterObservationsBody",
    "GetOutagesBody",
    "HTTPAPIError",
    "HTTPClientError",
    "HTTPRequestError",
    "LiveRadiationParams",
    # OMIE exports are available only if optional deps import cleanly
    "OMIEClient",
    "OMIEDataError",
    "OMIERegion",
    "OMIEValidationError",
    "PowerMeteoForecastParams",
    "PriceRegion",
    "RadiationAndWeatherParams",
    "RenAPIError",
    "RenClient",
    "RenEndpoint",
    "RenError",
    "RenRequestError",
    "SolcastAPIError",
    "SolcastClient",
    "SolcastError",
    "SolcastRequestError",
    "SolcastResource",
    "SolcastValidationError",
]

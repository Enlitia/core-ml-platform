def assert_sparse_matrix_equal(a, b):
    """
    Assert that two sparse matrices are equal.

    The assertion passes if the number of nonzero elements in (a != b) is zero,
    meaning all elements are equal.

    Args:
        a: First sparse matrix.
        b: Second sparse matrix.

    Raises:
        AssertionError: If the matrices are not equal.
    """
    assert (a != b).nnz == 0

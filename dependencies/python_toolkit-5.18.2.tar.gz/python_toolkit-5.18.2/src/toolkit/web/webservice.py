import inspect
import typing
import warnings
from enum import Enum
from typing import Any, Final, Union

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from makefun import wraps

from toolkit.application.services import (
    ApplicationService,
    Command,
    IPresenter,
    ServiceFactory,
    ServiceResult,
)
from toolkit.data.query import DatabaseSession
from toolkit.database import database
from toolkit.errors import ErrorDomain
from toolkit.logging import get_logger
from toolkit.views import ErrorValidation, View, ViewFactory
from toolkit.web.http import status
from toolkit.web.http.methods import GET, POST, HTTPMethod, http_methods
from toolkit.web.ordering import Ordering
from toolkit.web.pagination import ErrorPagination, PageBasePagination
from toolkit.web.responses import json_http_500_server_error
from toolkit.web.timezoner import Timezoner

logger = get_logger(__name__)

app: Final = FastAPI()


# Default endpoints
@app.get(
    "/health",
    tags=["healthcheck"],
    summary="Perform a Health Check",
    response_description="Return HTTP Status Code 200 (OK)",
    status_code=status.HTTP_200_OK,
)
async def health():
    """Health check endpoint.

    This endpoint is used to check the health of the service.
    It returns a 200 OK response if the service is healthy.

    Returns:
        JSONResponse: A JSON response with a status of "ok".
    """
    return JSONResponse(status_code=status.HTTP_200_OK, content={"status": "ok"})


def _with_session(view_instance, session: DatabaseSession):
    setattr(view_instance, "_db_session", session)  # noqa: B010


class MixinViewWithSession:
    """
    Adds a session to a View.
    """

    _db_session = None

    def with_session(self, session: DatabaseSession):
        """
        Manually adds a session to the object that uses this mixin.
        """
        _with_session(self, session)


class MixinOrderedView:
    """
    Adds Ordering to a view
    """

    ordering: Ordering

    def with_ordering(self, ordering: Ordering):
        self.ordering = ordering


class MixinPaginatedView:
    """
    Adds Pagination to a View
    """

    pagination: PageBasePagination

    @property
    def total_results(self) -> int:
        """
        Views that want to be paginated must return the total number of results available.
        """
        raise NotImplementedError()

    def with_pagination(self, pagination):
        self.pagination = pagination


class BaseWebService:
    http_method: HTTPMethod
    url: str
    request_object: Any

    def __init__(self, *, mandatory_attrs=None):
        self._base_response: dict = {"data": [], "errors": []}
        _base_mandatory_attrs = ["http_method", "url", *mandatory_attrs] if mandatory_attrs else []
        self._validate_mandatory_attributes_declaration(_base_mandatory_attrs)

    def _validate_mandatory_attributes_declaration(self, mandatory_attributes: list[str]):
        """
        Checks if the mandatory attributes are declared.
        """
        missing_attrs = [attr for attr in mandatory_attributes if not hasattr(self, attr)]
        msg = f"{self.__class__.__name__} is missing '{', '.join(missing_attrs)}' attributes"
        assert not missing_attrs, msg  # nosec
        assert self.http_method in http_methods, f"'{self.http_method}' is not a valid http method"  # nosec

    def pre_execute(self, **kwargs):
        """
        Logic to be executed before the executed method.

        This is the recommended place to create instances and do validations
        needed for the service to run.
        """
        pass

    def execute(self, **kwargs):
        try:
            self.pre_execute(**kwargs)
            data = self.call_service(**kwargs)
            return JSONResponse(status_code=status.HTTP_200_OK, content=self.post_execute(data))
        except ErrorValidation as e:
            for error in e.args:
                self._base_response["errors"].append({"message": error})
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content=self._base_response)
        except ErrorDomain as e:
            self._base_response["errors"].append({"message": str(e)})
            return JSONResponse(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, content=self._base_response)
        except Exception as e:
            logger.critical("unhandled error", error=str(e))
            return json_http_500_server_error

    def call_service(self, **_) -> typing.Any:
        """
        Override this method with the code need for your application to return
        data.
        """
        raise NotImplementedError()

    def post_execute(self, data):
        """
        Logic to be executed after getting the view data.
        Extend this logic to do some operation after executing the view and
        before answering to the request.
        """

        response_data = {"data": data, "errors": []}
        return response_data


ViewClass = type[View]
OrderingClass = type[Ordering]
PaginationClass = type[PageBasePagination]
TimezonerClass = type[Timezoner]


class QueryWebService(BaseWebService):
    """
    A web service that does not change the observable behaviour of the system
    when called.
    """

    http_method: HTTPMethod = GET
    view: ViewClass
    ordering_class: OrderingClass
    pagination_class: PaginationClass
    timezoner_class: TimezonerClass
    view_instance: View

    def __init__(self) -> None:
        super().__init__(mandatory_attrs=["view"])
        self.pagination_instance = None
        assert self.http_method == GET, f"Invalid http method '{self.http_method}'"  # nosec

    @property
    def _has_pagination(self) -> bool:
        return hasattr(self, "pagination_class") and self.pagination_class is not None

    @property
    def _has_ordering(self) -> bool:
        has_ordering = hasattr(self, "ordering_class") and self.ordering_class is not None
        return has_ordering

    @property
    def _has_timezone(self) -> bool:
        has_timezone = hasattr(self, "timezoner_class") and self.timezoner_class is not None
        return has_timezone

    def pre_execute(self, **kwargs):
        """
        Logic to be executed before getting the view data.
        By default, it creates the instance of the view and does validations on
        the input data.
        Extend this logic to do some operation before of after the view
        instantiation and validation.
        """
        super().pre_execute()

        self.view_instance = ViewFactory().build(self.view, **kwargs)
        if self._has_pagination:
            # Check if the View needs a session. If it needs, assume it needs a
            # session to calculate the total results
            if hasattr(self.view_instance, "_db_session"):
                with database.session() as session:
                    _with_session(self.view_instance, session)
                    total_results = self.view_instance.total_results  # type: ignore
            else:
                total_results = self.view_instance.total_results  # type: ignore

            # Create the pagination instance and inject it in the View
            page: int | None = kwargs.get("page")
            page_size: int | None = kwargs.get("page_size")
            self.pagination_instance = self.pagination_class(total_results, page, page_size=page_size)  # type: ignore
            self.view_instance.with_pagination(self.pagination_instance)  # type: ignore

        if self._has_ordering:
            ordering = self.ordering_class(ordering_value=kwargs.get("ordering"))
            self.view_instance.with_ordering(ordering)  # type: ignore

        if self._has_timezone:
            timezoner = self.timezoner_class(timezone=kwargs.get("timezone"))
            self.view_instance.with_timezone(timezoner)  # type: ignore

    def execute(self, **kwargs):
        # NOTE: Overrides execute to provide handling of pagination errors.
        try:
            self.pre_execute(**kwargs)
            data = self.call_service(**kwargs)
            return self.post_execute(data)
        except ErrorPagination as e:
            self._base_response["errors"].append({"message": str(e)})
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content=self._base_response)
        except ErrorValidation as e:
            for error in e.args:
                self._base_response["errors"].append({"message": error})
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content=self._base_response)
        except ErrorDomain as e:
            self._base_response["errors"].append({"message": str(e)})
            return JSONResponse(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, content=self._base_response)
        except Exception as e:
            logger.critical("unhandled error", error=str(e))
            return json_http_500_server_error

    def call_service(self, **_) -> typing.Any:
        """
        Asks the view for the data and returns it in an HTTP response.
        """
        if hasattr(self.view_instance, "_db_session"):
            with database.session() as session:
                _with_session(self.view_instance, session)
                data = self.view_instance.data
        else:
            data = self.view_instance.data
        return data

    def post_execute(self, data):
        response_data = super().post_execute(data)
        if not self._has_pagination:
            return response_data

        current_path = self.request_object.url.path

        response_data = {**response_data, **self.pagination_instance.data}  # type: ignore
        response_data["next"] = f"{current_path}{response_data['next']}" if response_data["next"] else None
        response_data["previous"] = f"{current_path}{response_data['previous']}" if response_data["previous"] else None
        return response_data


def WebService():
    """
    Deprecated, use toolkit.web.webservice.QueryWebService instead
    """
    warnings.warn("WebService is deprecated, use QueryWebService instead", DeprecationWarning, 2)
    return QueryWebService()


ApplicationServiceClass = type[ApplicationService]


class APIServicePresenter(IPresenter):
    def present(self, value: ServiceResult) -> None:
        """
        Transforms the objects generated by the application service into data
        structures understood by the API.
        """
        pass

    @property
    def data(self) -> typing.Any:
        raise NotImplementedError("Override this method to return to return your data")


class CommandWebService(BaseWebService):
    application_service_class: ApplicationServiceClass
    command: type[Command]
    http_method: HTTPMethod = POST

    presenter: type[APIServicePresenter]

    _command_instance: Command
    _service_instance = ApplicationService

    def __init__(self):
        super().__init__(mandatory_attrs=["application_service_class", "command"])
        assert self.http_method == POST, f"Invalid http method '{self.http_method}'"  # nosec

    def pre_execute(self, **kwargs):
        """
        Creates all the necessary objects needed for the web service to execute.
        """
        super().pre_execute()
        self._service_instance = ServiceFactory().build(self.application_service_class)
        self._command_instance = self.command()

        if hasattr(self, "presenter"):
            setattr(self._service_instance, "presenter", self.presenter())  # noqa: B010

    def execute(self, **kwargs):
        try:
            self.pre_execute(**kwargs)
            data = self.call_service(**kwargs)
            post_execute_data = self.post_execute(data)
            status_code = status.HTTP_201_CREATED
            if data == {}:
                status_code = status.HTTP_204_NO_CONTENT
            return JSONResponse(status_code=status_code, content=post_execute_data)
        except ErrorValidation as e:
            for error in e.args:
                self._base_response["errors"].append({"message": error})
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content=self._base_response)
        except ErrorDomain as e:
            self._base_response["errors"].append({"message": str(e)})
            return JSONResponse(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, content=self._base_response)
        except Exception as e:
            logger.critical("unhandled error", error=str(e))
            return json_http_500_server_error

    def call_service(self, **_) -> typing.Any:
        """
        Executes the application service.
        """
        self._service_instance.execute(self._command_instance)  # type: ignore
        if hasattr(self, "presenter"):
            return self._service_instance.presenter.data  # type: ignore
        return {}


def register_route(
    application,
    web_service: typing.Union[BaseWebService, QueryWebService, CommandWebService],
    tags: list[Union[str, Enum]] | None = None,
):
    """
    Register a new endpoint in the chosen app.

    Arguments:
        application: An instance of FastAPI
        web_service: An instance of QueryWebService
        tags: API Tags to identify subsets of endpoints
    """
    http_method: HTTPMethod = web_service.http_method
    if not tags:
        tags = _extract_tag_from_url(web_service.url)

    # so we can have access to the request object,
    # we take the given execute function and prepend it with the request object argument
    # creating a new function we can use as the route handler
    # fastapi will then populate the 'req' with the request object so we can use it
    @wraps(
        web_service.execute,
        prepend_args=inspect.Parameter(name="req", annotation=Request, kind=inspect.Parameter.POSITIONAL_OR_KEYWORD),
    )
    def main_execute(req: Request, *args, **kwargs):
        web_service.request_object = req
        return web_service.execute(*args, **kwargs)

    application.router.add_api_route(web_service.url, main_execute, methods=[str(http_method)], tags=tags)


def _extract_tag_from_url(url):
    """
    Extracts tags from the url.
    Assumes the url is in the format: /api/1/namespace/collection
    """
    try:
        tags = [url.split("/")[3]]
    except IndexError:
        tags = None
    return tags

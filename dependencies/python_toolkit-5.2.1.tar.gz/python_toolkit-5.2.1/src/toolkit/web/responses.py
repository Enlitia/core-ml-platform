from fastapi.responses import JSONResponse

from toolkit.web.http import status

JSON_HTTP_501_NOT_IMPLEMENTED = JSONResponse(
    status_code=status.HTTP_501_NOT_IMPLEMENTED,
    content={"data": [], "errors": []},
)

json_http_500_server_error = JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={})

base_http_response = {"data": {"headers": [], "values": []}, "errors": []}

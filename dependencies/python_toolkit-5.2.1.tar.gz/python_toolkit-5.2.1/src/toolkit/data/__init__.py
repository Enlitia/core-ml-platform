"""
Utilities to handle data and data related operations.
"""

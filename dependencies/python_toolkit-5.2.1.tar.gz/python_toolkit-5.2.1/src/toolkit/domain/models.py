from dataclasses import dataclass
from datetime import datetime


@dataclass
class MainModel:
    """
    General model with common fields that can be used to initialize other models
    """

    created_by: int = 0
    updated_by: int = 0
    created_at: datetime = datetime.now()


@dataclass
class Message:
    """
    General message to be used in logger and notifications
    """

    host: str
    system: str
    component: str
    environment: str
    message: str = ""

    def __str__(self) -> str:
        return (
            f"host: {self.host},   \n"
            f"system: {self.system},   \n"
            f"component: {self.component},   \n"
            f"environment: {self.environment},   \n"
            f"message: {self.message}"
        )

    def set_message(self, message: str):
        self.message = message
        return self

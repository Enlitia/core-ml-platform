"""SFTP client implementation."""

import os
import posixpath
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from io import BytesIO
from pathlib import Path

import paramiko
from paramiko import AuthenticationException, SSHException

from toolkit.file_transfer import (
    BaseFileTransferClient,
    FileTransferAuthenticationError,
    FileTransferConfig,
    FileTransferConnectionError,
    FileTransferOperationError,
)
from toolkit.logging import FileTransferLabels, Logger


@dataclass
class SFTPConfig(FileTransferConfig):
    """Configuration for SFTP connections."""

    port: int = 22
    private_key_path: str | None = None

    def __post_init__(self):
        """Set port to 22 for SFTP if port is default 21."""
        if self.port == 21:
            self.port = 22


class SFTPClient(BaseFileTransferClient):
    """SFTP client implementation.

    Implements SFTP over SSH with password and key-based authentication.
    Supports secure file transfers and remote command execution.

    Authentication:
        - Password: Uses username/password
        - Key-based: Uses private_key_path (password as passphrase)
        - Auto-selection based on configuration

    Note: Uses paramiko library and AutoAddPolicy for host keys.
    """

    config: SFTPConfig  # Override parent type annotation
    _connection: paramiko.SFTPClient | None = None  # Override parent type annotation

    def __init__(self, config: SFTPConfig, logger: Logger | None = None):
        """Initialize SFTP client."""
        super().__init__(config, logger)
        self._ssh_client: paramiko.SSHClient | None = None

    def connect(self) -> None:
        """Establish SFTP connection over SSH.

        Supports both key-based and password authentication:
        - If private_key_path is provided and file exists: uses key authentication
        - Otherwise: uses password authentication

        Host keys are automatically accepted (AutoAddPolicy) for automated
        connections. In production, consider implementing proper host key
        verification.

        Raises:
            FileTransferAuthenticationError: If SSH authentication fails
            FileTransferConnectionError: If SSH/SFTP connection cannot be established
        """
        ft = FileTransferLabels
        try:
            self._ssh_client = paramiko.SSHClient()
            self._ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # nosec B507 - Required for automated SFTP connections

            # Authentication
            auth_kwargs = {
                "hostname": self.config.host,
                "port": self.config.port,
                "username": self.config.username,
                "timeout": self.config.timeout,
            }

            if self.config.private_key_path and os.path.exists(self.config.private_key_path):
                # Key-based authentication
                auth_kwargs["key_filename"] = self.config.private_key_path
                if self.config.password:
                    auth_kwargs["passphrase"] = self.config.password
            else:
                # Password authentication
                auth_kwargs["password"] = self.config.password

            self._ssh_client.connect(**auth_kwargs)  # type: ignore[arg-type]
            self._connection = self._ssh_client.open_sftp()

            self._logger.info(
                "connected", action=ft.CONNECT.completed, step=ft.CONNECT, host=self.config.host, port=self.config.port
            )

        except AuthenticationException as e:
            self._logger.error(
                "authentication failed",
                action=ft.CONNECT.failed,
                step=ft.CONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferAuthenticationError(f"SFTP authentication failed: {e}", e) from e
        except SSHException as e:
            self._logger.error(
                "SSH connection failed",
                action=ft.CONNECT.failed,
                step=ft.CONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferConnectionError(f"SSH connection failed: {e}", e) from e
        except Exception as e:
            self._logger.error(
                "connection failed",
                action=ft.CONNECT.failed,
                step=ft.CONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferConnectionError(f"SFTP connection failed: {e}", e) from e

    @property
    def connection(self) -> paramiko.SFTPClient:
        """Get the SFTP connection."""
        if self._connection is None:
            raise FileTransferOperationError("Not connected to server")
        return self._connection  # type: ignore[return-value]

    def disconnect(self) -> None:
        """Close SFTP and SSH connections."""
        try:
            if self._connection:
                self._connection.close()
                self._connection = None

            if self._ssh_client:
                self._ssh_client.close()
                self._ssh_client = None

            self._logger.debug(
                "disconnected", action=FileTransferLabels.DISCONNECT.completed, step=FileTransferLabels.DISCONNECT
            )

        except Exception as e:
            self._logger.warning(
                "disconnect error",
                action=FileTransferLabels.DISCONNECT.failed,
                step=FileTransferLabels.DISCONNECT,
                error_type=type(e).__name__,
                error_message=str(e),
            )

    def list_directory(self, path: str = "") -> list[str]:
        """List files and directories in the specified path."""
        resolved_path = self._resolve_path(path)
        try:
            return self.connection.listdir(resolved_path)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to list directory '{resolved_path}': {e}", e) from e

    def download_file(self, remote_path: str, local_path: str) -> None:
        """Download a file from the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            self.connection.get(resolved_remote_path, local_path)
            self._logger.debug(
                "file downloaded",
                action=FileTransferLabels.DOWNLOAD.completed,
                step=FileTransferLabels.DOWNLOAD,
                remote_path=resolved_remote_path,
                local_path=local_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to download '{resolved_remote_path}': {e}", e) from e

    def upload_file(self, local_path: str, remote_path: str) -> None:
        """Upload a file to the remote server."""
        if not os.path.exists(local_path):
            raise FileTransferOperationError(f"Local file does not exist: {local_path}")

        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.put(local_path, resolved_remote_path)
            self._logger.debug(
                "file uploaded",
                action=FileTransferLabels.UPLOAD.completed,
                step=FileTransferLabels.UPLOAD,
                local_path=local_path,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to upload '{local_path}': {e}", e) from e

    def upload_file_obj(self, file_obj: BytesIO, remote_path: str) -> None:
        """Upload from a file-like object to the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            file_obj.seek(0)  # Reset to beginning for consistent uploads
            self.connection.putfo(file_obj, resolved_remote_path)
            self._logger.debug(
                "file object uploaded",
                action=FileTransferLabels.UPLOAD.completed,
                step=FileTransferLabels.UPLOAD,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to upload to '{resolved_remote_path}': {e}", e) from e

    def delete_file(self, remote_path: str) -> None:
        """Delete a file on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.remove(resolved_remote_path)
            self._logger.debug(
                "file deleted",
                action=FileTransferLabels.DELETE.completed,
                step=FileTransferLabels.DELETE,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to delete '{resolved_remote_path}': {e}", e) from e

    def create_directory(self, remote_path: str) -> None:
        """Create a directory on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.mkdir(resolved_remote_path)
            self._logger.debug(
                "directory created",
                action=FileTransferLabels.MKDIR.completed,
                step=FileTransferLabels.MKDIR,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to create directory '{resolved_remote_path}': {e}", e) from e

    def remove_directory(self, remote_path: str) -> None:
        """Remove a directory on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.rmdir(resolved_remote_path)
            self._logger.debug(
                "directory removed",
                action=FileTransferLabels.RMDIR.completed,
                step=FileTransferLabels.RMDIR,
                remote_path=resolved_remote_path,
            )
        except Exception as e:
            raise FileTransferOperationError(f"Failed to remove directory '{resolved_remote_path}': {e}", e) from e

    def file_exists(self, remote_path: str) -> bool:
        """Check if a file exists on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.stat(resolved_remote_path)
            return True
        except FileNotFoundError:
            return False
        except Exception as e:
            raise FileTransferOperationError(f"Failed to check if file exists '{resolved_remote_path}': {e}", e) from e

    def get_file_size(self, remote_path: str) -> int:
        """Get the size of a file on the remote server."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            stat_result = self.connection.stat(resolved_remote_path)
            if stat_result.st_size is None:
                raise FileTransferOperationError(f"Could not determine size of '{resolved_remote_path}'")
            return int(stat_result.st_size)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to get file size '{resolved_remote_path}': {e}", e) from e

    def get_file_fo(self, remote_path: str, file_obj: BytesIO) -> None:
        """Get a file-like object for a remote file."""
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            self.connection.getfo(resolved_remote_path, file_obj)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to read file '{resolved_remote_path}': {e}", e) from e

    @contextmanager
    def change_directory(self, remote_path: str) -> Generator[None, None, None]:
        """Context manager to temporarily change to a different directory.

        Changes to the specified directory and automatically returns to the
        original directory when exiting the context.

        Args:
            remote_path: Path to the directory to change to

        Yields:
            None (for use in with statements)

        Raises:
            FileTransferOperationError: If directory change fails

        Example:
            with client.change_directory("/tmp"):
                # Operations here are performed in /tmp
                client.upload_file("local.txt", "remote.txt")
            # Automatically returns to original directory
        """
        resolved_remote_path = self._resolve_path(remote_path)
        try:
            original_path = self.connection.getcwd() or "/"
            self.connection.chdir(resolved_remote_path)
            try:
                yield
            finally:
                self.connection.chdir(original_path)
        except Exception as e:
            raise FileTransferOperationError(f"Failed to change directory to '{resolved_remote_path}': {e}", e) from e

    def archive_file(
        self,
        source_file_path: str,
        destination_folder: str = "/Processed/",
        filename: str | None = None,
    ) -> str:
        """Archive a file with timestamp using server-side rename.

        Moves file directly on the server using SFTP rename (no data transfer).
        Creates destination folder if it doesn't exist.

        Args:
            source_file_path: Full path to source file (e.g., '/Availability/data.csv')
            destination_folder: Destination folder. Defaults to '/Processed/'
            filename: Optional filename base. If not provided, uses source filename.

        Returns:
            Full path to the archived file

        Raises:
            FileTransferOperationError: If unable to archive file

        Example:
            >>> client.archive_file("/Availability/template.csv")
            '/Processed/template_2026-02-25_14-30-45.csv'
        """
        resolved_source = self._resolve_path(source_file_path)

        # Validate source exists
        if not self.file_exists(source_file_path):
            raise FileTransferOperationError(f"Source file does not exist: {resolved_source}")

        # Use source filename if not provided
        if filename is None:
            filename = posixpath.basename(source_file_path)

        # Generate timestamped filename
        timestamp = datetime.now(UTC).strftime("%Y-%m-%d_%H-%M-%S")

        # Handle file extensions (including compound ones like .tar.gz)
        if "." in filename:
            parts = filename.split(".")
            if len(parts) > 2 and parts[-2] == "tar":
                # Compound extension like .tar.gz
                name = ".".join(parts[:-2])
                extension = ".".join(parts[-2:])
            else:
                # Simple extension
                name = ".".join(parts[:-1])
                extension = parts[-1]
            timestamped_filename = f"{name}_{timestamp}.{extension}"
        else:
            timestamped_filename = f"{filename}_{timestamp}"

        # Build destination path
        resolved_destination_folder = self._resolve_path(destination_folder)
        destination_path = posixpath.join(resolved_destination_folder, timestamped_filename)

        try:
            # Create destination folder if needed
            try:
                self.connection.stat(resolved_destination_folder)
            except FileNotFoundError:
                self._create_directory_recursive(resolved_destination_folder)

            # Move file on server (no data transfer)
            self.connection.rename(resolved_source, destination_path)
            self._logger.info(
                "file archived",
                action=FileTransferLabels.ARCHIVE.completed,
                step=FileTransferLabels.ARCHIVE,
                source=resolved_source,
                destination=destination_path,
            )

            return destination_path

        except Exception as e:
            self._logger.error(
                "file archive failed",
                action=FileTransferLabels.ARCHIVE.failed,
                step=FileTransferLabels.ARCHIVE,
                source=resolved_source,
                destination=destination_path,
                error_type=type(e).__name__,
                error_message=str(e),
            )
            raise FileTransferOperationError(
                f"Unable to archive file from {resolved_source} to {destination_path}: {e}"
            ) from e

    def _create_directory_recursive(self, remote_path: str) -> None:
        """Create directory recursively (like mkdir -p).

        Args:
            remote_path: Remote directory path to create
        """
        try:
            self.connection.stat(remote_path)
            return  # Already exists
        except FileNotFoundError:
            # Create parent first
            parent = posixpath.dirname(remote_path)
            if parent and parent != "/":
                self._create_directory_recursive(parent)
            # Create this directory
            self.connection.mkdir(remote_path)
            self._logger.debug(
                "directory created",
                action=FileTransferLabels.MKDIR.completed,
                step=FileTransferLabels.MKDIR,
                remote_path=remote_path,
            )

    def execute_command(self, command: str) -> str:
        """Execute SSH command on remote server - SFTP-specific method.

        This method allows executing shell commands on the remote server
        through the SSH connection. This is an SFTP-specific feature not
        available with regular FTP.

        Args:
            command: Shell command to execute on remote server

        Returns:
            Command output as string

        Raises:
            FileTransferOperationError: If not connected to SSH server or command fails

        Example:
            output = client.execute_command("ls -la /tmp")
            print(output)
        """
        if not self._ssh_client:
            raise FileTransferOperationError("Not connected to SSH server")

        try:
            _stdin, stdout, stderr = self._ssh_client.exec_command(command)  # nosec B601 - Command input is controlled by caller
            output = stdout.read().decode()
            error = stderr.read().decode()

            if error:
                raise FileTransferOperationError(f"Command failed: {error}")

            return output
        except Exception as e:
            raise FileTransferOperationError(f"Failed to execute command '{command}': {e}", e) from e

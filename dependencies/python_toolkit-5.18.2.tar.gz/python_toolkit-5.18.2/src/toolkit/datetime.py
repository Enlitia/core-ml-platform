from collections.abc import Iterator
from datetime import UTC, date, datetime, timedelta
from typing import Protocol, TypeVar, Union
from zoneinfo import ZoneInfo

from dateutil import tz


class _datetime_like(Protocol):
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int


def ensure_py_datetime(dt: _datetime_like) -> datetime:
    """Transform any "datetimish" type into a Python datetime object

    Args:
        dt (_datetime_like): input datetime

    Returns:
        datetime: same as `dt` but a Python datetime object
    """
    return datetime(
        dt.year,
        dt.month,
        dt.day,
        dt.hour,
        dt.minute,
        dt.second,
    )


def zeroed_to_hour(dt: _datetime_like) -> datetime:
    """Returns `dt` with all fields smaller than the hour zeroed

    Args:
        dt (_datetime_like): input datetime

    Returns:
        datetime: zeroed `dt`
    """
    return datetime(dt.year, dt.month, dt.day, dt.hour)


T = TypeVar("T", datetime, date)


def time_window_batches[T: (datetime, date)](start: T, end: T, delta: timedelta) -> Iterator[tuple[T, T]]:
    """Iterates through subsequent (start,end) pairs, from `start` to `end` (inclusive),
    with a maximum timedelta of `delta`

    Args:
        start (datetime or date T): start of time window
        end (datetime or date T): end of time window
        delta (timedelta): "batch" window timedelta

    Raises:
        ValueError: If end < start

    Yields:
        Iterator[Tuple[T, T]]: Iterator of (start,end) tuple pairs
    """
    if end < start:
        raise ValueError("end < start")

    if start + delta == start:
        raise ValueError("delta is too small")

    if end - start < delta:
        yield start, end
        return

    current = next_window = start
    while True:
        next_window = min(current + delta, end)
        yield current, next_window
        current = next_window
        if current == end:
            break


def ensure_timezone(dt: datetime, tz: str = "UTC") -> datetime:
    """Ensure datetime has timezone information."""
    return dt if dt.tzinfo else dt.replace(tzinfo=ZoneInfo(tz))


def zero_time(dt: datetime, tz: str = "UTC") -> datetime:
    """Zero out the time portion of a datetime object.

    Args:
        dt: The datetime object to modify

    Returns:
        datetime: A new datetime with hours, minutes, seconds, and microseconds set to zero
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=ZoneInfo(tz))

    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def zero_hour(dt: datetime, tz: str = "UTC") -> datetime:
    """Zero out the time portion of a datetime object, excluding hour.

    Args:
        dt: The datetime object to modify

    Returns:
        datetime: A new datetime with minutes, seconds, and microseconds set to zero
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=ZoneInfo(tz))

    return dt.replace(minute=0, second=0, microsecond=0)


def zero_minute(dt: datetime, tz: str = "UTC") -> datetime:
    """Zero out the time portion of a datetime object, excluding hour and minute.

    Args:
        dt: The datetime object to modify

    Returns:
        datetime: A new datetime with minutes, seconds, and microseconds set to zero
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=ZoneInfo(tz))

    return dt.replace(second=0, microsecond=0)


def define_start_timestamp(tz: str = "UTC") -> datetime:
    """Define start timestamp for data retrieval.

    This method sets timestamp_start based on:
    1. Daily operation: fetch last 7 days of data
    2. Biannual operation (Jan and Jul): fetch last 365 days of data

    Returns:
        datetime: The calculated start timestamp with time set to UTC
    """
    now = datetime.now(ZoneInfo(tz))

    is_biannual_run = now.month in [1, 7] and now.day == 1

    if is_biannual_run:
        return zero_time(now - timedelta(days=365), tz)
    else:  # daily run
        return zero_time(now - timedelta(days=7), tz)


def convert_datetime_timezone(
    dt: Union[datetime, str], from_timezone: str = "UTC", to_timezone: str = "UTC"
) -> datetime:
    """
    Convert a datetime object or string from one timezone to another.

    Args:
        dt: The datetime object or ISO format string to convert
        from_timezone: Source timezone name (e.g., "UTC", "Europe/London")
        to_timezone: Target timezone name (e.g., "UTC", "America/New_York")

    Returns:
        A datetime object in the target timezone

    Raises:
        ValueError: If the datetime string format is invalid
        ZoneInfoNotFoundError: If timezone name is invalid
    """
    # If input is a string, convert to datetime
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))

    # If dt is naive (no timezone info), assume it's in from_timezone
    if dt.tzinfo is None:
        source_tz = ZoneInfo(from_timezone)
        dt = dt.replace(tzinfo=source_tz)

    # Convert to the target timezone
    target_tz = ZoneInfo(to_timezone)
    converted_dt = dt.astimezone(target_tz)

    # If converting to UTC, return naive datetime
    if to_timezone == "UTC":
        return converted_dt.replace(tzinfo=None)

    return converted_dt


def localize_with_dst_handling(dt: datetime, timezone_str: str, prefer_earlier: bool = True) -> datetime:
    """
    Safely localize a naive datetime to the given timezone, handling DST changes.

    - If time is ambiguous (e.g. during DST fall-back), pick earlier/later using `prefer_earlier`.
    - If time does not exist (e.g. during spring-forward), shift forward by 1 hour.

    Returns timezone-aware UTC datetime.
    """
    if dt.tzinfo is not None:
        raise ValueError("Datetime must be naive")

    zi = ZoneInfo(timezone_str)

    # Attach timezone naively
    dt_local = dt.replace(tzinfo=zi)

    # Check for nonexistent or ambiguous time using dateutil
    # because zoneinfo does not raise on ambiguous times
    is_ambiguous = tz.datetime_ambiguous(dt, zi)
    if is_ambiguous:
        if not prefer_earlier:
            # If we want the later one, add 1 hour
            dt_local = (dt + timedelta(hours=1)).replace(tzinfo=zi)

    elif not tz.datetime_exists(dt, zi):
        # Nonexistent time (spring-forward gap), shift forward
        dt_local = (dt + timedelta(hours=1)).replace(tzinfo=zi)

    # Convert to UTC
    return dt_local.astimezone(ZoneInfo("UTC"))


def nearest_available_date(dt: datetime | None) -> datetime | None:
    """Find the nearest past available date hour from [0, 6, 12, 18] and return zeroed datetime.

    Args:
        dt: The datetime object to find nearest past forecast hour for

    Returns:
        datetime: A new datetime with the nearest past available date hour and all other time components zeroed
    """
    if dt is None:
        return None

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)

    # Available forecast hours
    forecast_hours = [0, 6, 12, 18]
    current_hour = dt.hour

    # Find the most recent forecast hour that is <= current hour
    past_hours = [h for h in forecast_hours if h <= current_hour]
    nearest_hour = max(past_hours)

    return zero_hour(dt.replace(hour=nearest_hour))


def get_expected_quarter_hourly_count(local_date: date, timezone_str: str) -> int:
    """
    Calculate expected number of quarter-hourly values for a day in a timezone.

    Accounts for DST transitions:
    - Normal day: 24 hours = 96 quarter-hourly values
    - Spring forward (DST starts): 23 hours = 92 values
    - Fall back (DST ends): 25 hours = 100 values

    Args:
        local_date: The date to check (in the specified timezone)
        timezone_str: Timezone name (e.g., "Europe/Madrid", "America/New_York")

    Returns:
        Expected number of quarter-hourly values: 92, 96, or 100
    """
    tz = ZoneInfo(timezone_str)

    # Start and end of the day in local time
    day_start = datetime.combine(local_date, datetime.min.time()).replace(
        tzinfo=tz
    )  # This make sures that the day_start is timezone-aware and starts at 00:00 local time
    day_end = day_start + timedelta(days=1)

    # Calculate actual duration by converting to UTC
    # IMPORTANT: We must convert to UTC to get the true elapsed time.
    # When calculating duration in local time, Python gives the mathematical difference (always 24h),
    # not the actual elapsed time. UTC has no DST, so it gives us the real duration:
    # - Spring forward (DST starts): 23 hours (clocks jump ahead, hour is skipped)
    # - Fall back (DST ends): 25 hours (clocks fall back, hour is repeated)
    # - Normal day: 24 hours
    duration = day_end.astimezone(ZoneInfo("UTC")) - day_start.astimezone(ZoneInfo("UTC"))
    hours = duration.total_seconds() / 3600

    return int(hours * 4)  # 4 quarters per hour

import typing
from enum import Enum, unique


@unique
class HTTPMethod(str, Enum):
    GET = "GET"
    OPTIONS = "OPTIONS"
    HEAD = "HEAD"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"

    def __str__(self) -> str:
        return str(self.value)


GET = HTTPMethod.GET
OPTIONS = HTTPMethod.OPTIONS
HEAD = HTTPMethod.HEAD
POST = HTTPMethod.POST
PUT = HTTPMethod.PUT
PATCH = HTTPMethod.PATCH
DELETE = HTTPMethod.DELETE

http_methods: typing.Final = [method for method in HTTPMethod]

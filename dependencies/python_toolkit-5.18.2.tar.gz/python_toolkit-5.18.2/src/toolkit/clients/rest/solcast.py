"""Solcast API client for solar irradiance and weather data.

Provides a client for interacting with the Solcast API, which offers
high-resolution solar irradiance forecasts and live measurements for any location
worldwide.

See docs/clients/rest/SolcastClient.md for comprehensive documentation.
"""

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, ClassVar

import httpx

from toolkit.http_client import BearerTokenHTTPClient
from toolkit.logging import Logger, get_logger

logger = get_logger(__name__)

DEFAULT_SOLCAST_BASE_URL = "https://api.solcast.com.au"

# API limits
MIN_TIME_WINDOW_HOURS = 1
MAX_LIVE_TIME_WINDOW_HOURS = 168
MAX_FORECAST_TIME_WINDOW_HOURS = 336
VALID_PERIODS = (5, 10, 15, 20, 30, 60)
VALID_ARRAY_TYPES = ("fixed", "horizontal_single_axis")


class SolcastApiPath(StrEnum):
    """Solcast API endpoint paths."""

    LIVE = "/data/live"
    FORECAST = "/data/forecast"


class SolcastResource(StrEnum):
    """Solcast resource names appended to /data/(live|forecast)/."""

    RADIATION_AND_WEATHER = "radiation_and_weather"


class SolcastError(Exception):
    """Base exception for Solcast API errors."""

    pass


class SolcastAPIError(SolcastError):
    """Exception raised when Solcast API returns an error response."""

    def __init__(self, status_code: int, url: str, message: str = ""):
        self.status_code = status_code
        self.url = url
        self.message = message or f"API request failed with status {status_code} for {url}"
        super().__init__(self.message)


class SolcastRequestError(SolcastError):
    """Exception raised when there's a problem making the request to Solcast."""

    def __init__(self, message: str, original_exception: Exception):
        self.original_exception = original_exception
        super().__init__(f"Request failed: {message}")


class SolcastValidationError(SolcastError):
    """Exception for input validation errors."""

    pass


@dataclass
class RadiationAndWeatherParams:
    """Parameters for Solcast irradiance + weather requests.

    Attributes:
        latitude: Location latitude in decimal degrees (-90 to 90).
        longitude: Location longitude in decimal degrees (-180 to 180).
        output_parameters: Comma-separated list of parameters to retrieve.
        period: Data interval in minutes (5, 10, 15, 30, 60). Optional.
        tilt: Solar panel tilt angle in degrees (0=horizontal, 90=vertical).
        azimuth: Panel azimuth in degrees (0=north, 90=east, 180=south, 270=west).
        array_type: Solar array type ('fixed', 'single_axis', 'dual_axis').
        time_window_hour: Hours of data to retrieve (range depends on endpoint).
    """

    MAX_TIME_WINDOW_HOURS: ClassVar[int] = MAX_LIVE_TIME_WINDOW_HOURS

    latitude: float
    longitude: float
    output_parameters: str
    period: int | None = None
    tilt: int | None = None
    azimuth: int | None = None
    array_type: str | None = None
    time_window_hour: int = 1

    def __post_init__(self) -> None:
        self._validate_coordinates()
        self._validate_time_window()
        self._validate_period()
        self._validate_array_type()

    def _validate_coordinates(self) -> None:
        if not (-90 <= self.latitude <= 90):
            raise SolcastValidationError(f"Latitude must be between -90 and 90, got {self.latitude}")
        if not (-180 <= self.longitude <= 180):
            raise SolcastValidationError(f"Longitude must be between -180 and 180, got {self.longitude}")

    def _validate_time_window(self) -> None:
        if not (MIN_TIME_WINDOW_HOURS <= self.time_window_hour <= self.MAX_TIME_WINDOW_HOURS):
            raise SolcastValidationError(
                f"time_window_hour must be between {MIN_TIME_WINDOW_HOURS} and "
                f"{self.MAX_TIME_WINDOW_HOURS}, got {self.time_window_hour}"
            )

    def _validate_period(self) -> None:
        if self.period is not None and self.period not in VALID_PERIODS:
            raise SolcastValidationError(f"period must be one of {VALID_PERIODS}, got {self.period}")

    def _validate_array_type(self) -> None:
        if self.array_type is not None and self.array_type not in VALID_ARRAY_TYPES:
            raise SolcastValidationError(f"array_type must be one of {VALID_ARRAY_TYPES}, got {self.array_type}")

    def to_query_params(self) -> dict[str, Any]:
        """Build query parameters dict for API request."""
        params: dict[str, Any] = {
            "latitude": self.latitude,
            "longitude": self.longitude,
            "output_parameters": self.output_parameters,
            "format": "json",
            "hours": self.time_window_hour,
        }
        if self.period is not None:
            params["period"] = f"PT{self.period}M"
        if self.tilt is not None:
            params["tilt"] = self.tilt
        if self.azimuth is not None:
            params["azimuth"] = self.azimuth
        if self.array_type is not None:
            params["array_type"] = self.array_type
        return params


@dataclass
class LiveRadiationParams(RadiationAndWeatherParams):
    """Parameters for get_live_radiation_and_weather.

    Default output_parameters and time_window_hour for live data.
    """

    MAX_TIME_WINDOW_HOURS: ClassVar[int] = MAX_LIVE_TIME_WINDOW_HOURS
    output_parameters: str = "air_temp,dni,ghi"
    time_window_hour: int = 48


@dataclass
class ForecastRadiationParams(RadiationAndWeatherParams):
    """Parameters for get_forecast_radiation_and_weather.

    Default output_parameters and time_window_hour for forecast data.
    """

    MAX_TIME_WINDOW_HOURS: ClassVar[int] = MAX_FORECAST_TIME_WINDOW_HOURS
    output_parameters: str = "air_temp,dni,ghi"
    time_window_hour: int = 48


class SolcastClient(BearerTokenHTTPClient):
    """HTTP client for Solcast's solar irradiance and weather API.

    Provides access to live radiation/weather measurements and forecast data.
    Use LiveRadiationParams for live data, ForecastRadiationParams for forecasts.
    """

    def __init__(
        self,
        token: str,
        base_url: str = DEFAULT_SOLCAST_BASE_URL,
        logger: Logger | None = None,
        **kwargs,
    ) -> None:
        """Initialize the Solcast API client."""
        self._logger = logger or get_logger(__name__)
        super().__init__(base_url, token, logger=self._logger, **kwargs)

    def _handle_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Convert HTTP errors to Solcast-specific exceptions."""
        return SolcastAPIError(exc.response.status_code, str(exc.request.url))

    def _handle_request_error(self, exc: httpx.RequestError) -> Exception:
        """Convert request errors to Solcast-specific exceptions."""
        return SolcastRequestError(str(exc), exc)

    def get_live_radiation_and_weather(self, params: LiveRadiationParams) -> dict[str, Any]:
        """Get live solar irradiance and weather measurements from Solcast.

        Args:
            params: LiveRadiationParams with latitude, longitude, and optional settings.

        Returns:
            Raw API response dict with 'estimated_actuals' list.
        """
        return self.get_live_data(SolcastResource.RADIATION_AND_WEATHER, params)

    def get_forecast_radiation_and_weather(self, params: ForecastRadiationParams) -> dict[str, Any]:
        """Get solar irradiance and weather forecasts from Solcast.

        Args:
            params: ForecastRadiationParams with latitude, longitude, and optional settings.

        Returns:
            Raw API response dict with 'forecasts' list.
        """
        return self.get_forecast_data(SolcastResource.RADIATION_AND_WEATHER, params)

    def get_live_data(self, resource: str | SolcastResource, params: LiveRadiationParams) -> dict[str, Any]:
        """GET live endpoint data for a given resource.

        Example resource: "radiation_and_weather" (yields /data/live/radiation_and_weather)
        """
        query_params = params.to_query_params()
        path = f"{SolcastApiPath.LIVE}/{resource.lstrip('/')}"
        return self.get(path, params=query_params)

    def get_forecast_data(self, resource: str | SolcastResource, params: ForecastRadiationParams) -> dict[str, Any]:
        """GET forecast endpoint data for a given resource.

        Example resource: "radiation_and_weather" (yields /data/forecast/radiation_and_weather)
        """
        query_params = params.to_query_params()
        path = f"{SolcastApiPath.FORECAST}/{resource.lstrip('/')}"
        return self.get(path, params=query_params)

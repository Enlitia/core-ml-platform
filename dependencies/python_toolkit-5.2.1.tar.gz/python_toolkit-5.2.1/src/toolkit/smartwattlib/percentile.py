class Percentile:
    def __init__(self, lower_bound: int = 20, upper_bound: int = 80):
        if lower_bound < 0:
            raise ValueError(f"invalid lower bound percentile {lower_bound}")
        if upper_bound > 100:
            raise ValueError(f"invalid upper bound percentile {upper_bound}")
        if upper_bound < lower_bound:
            raise ValueError(f"Invalid percentile interval '{lower_bound}-{upper_bound}'")

import datetime as dt

from toolkit.utils.omiedata.DataImport.omie_data_importer_from_responses import (
    OMIEDataImporterFromResponses,
)
from toolkit.utils.omiedata.Downloaders.adjustment_price_downloader import (
    AdjustmentPriceDownloader,
)
from toolkit.utils.omiedata.FileReaders.adjustment_price_file_reader import (
    AdjustmentPriceFileReader,
)


class OMIEAdjustmentPriceFileImporter(OMIEDataImporterFromResponses):
    def __init__(self, date_ini: dt.date, date_end: dt.date):
        super().__init__(
            date_ini=date_ini,
            date_end=date_end,
            file_downloader=AdjustmentPriceDownloader(),
            file_reader=AdjustmentPriceFileReader(),
        )
